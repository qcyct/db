create procedure mat_settlesummary(
v_projectorg in varchar2 default '' ,
v_billtypeInv in varchar2,
v_transtypeAdj in varchar2,
v_startdate in varchar2,
v_enddate in varchar2) is
cursor cc is     select c.fname_l2 contractCostType,a.fpartbid SUPPLIERID,b.fname_l2 SUPPLIERNAME, a.fid CONTRACTID,a.fname CONTRACTNAME,a.foriginalamount Foriginalamount ,a.cfytaxrate taxRate
from T_EC_ContractBill a
left outer join T_BD_Supplier b on b.fid=a.fpartbid
left outer join CT_BAS_ContractCostType c on c.fid=a.fcontractcosttypeid
where a.fprojectorgid=v_projectorg
and a.fcontractclass='2'--材料购销合同
and a.fcontractstatus in ('3','6','10')--批准执行签订
and a.fbizdate<=to_date(v_enddate,'yyyyMMdd')
order by c.fnumber asc,b.fname_l2 asc;

tt cc%rowtype;
v_startperiod date;
v_endperiod date;
per_matInAmount number(28,10);--本期入库
tot_matInAmount number(28,10);--入库累计
per_matBalAmount number(28,10);--本期对账
tot_matBalAmount number(28,10);--累计对账
tot_matUnBalAmount  number(28,10);--累计未对账
per_matInvAmount number(28,10);--本期供应商开票
tot_matInvAmount number(28,10);--累计供应商开票
tot_matUninvAmount  number(28,10);--累计供应商未开票
per_accInvAmount  number(28,10);--本期勾兑发票
tot_accInvAmount number(28,10);--累计勾兑发票
matAccDif  number(28,10);--未勾兑发票
per_applyPayAmount  number(28,10);--本期申请付款
tot_applyPayAmount  number(28,10);--累计申请付款
per_payAmount  number(28,10);--本期付款
tot_payAmount  number(28,10);--累计付款
tot_UnpayAmount  number(28,10);--累计未付款

begin
  DELETE FROM matsettlesum_temp;
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;
  per_matInAmount:= 0;--本期入库
  tot_matInAmount:= 0;--入库累计
  per_matBalAmount:= 0;--本期对账
  tot_matBalAmount:= 0;--累计对账
  tot_matUnBalAmount:= 0;--累计未对账
  per_matInvAmount:= 0;--本期供应商开票
  tot_matInvAmount:= 0;--累计供应商开票
  tot_matUninvAmount:= 0;--累计供应商未开票
  per_accInvAmount:= 0;--本期勾兑发票
  tot_accInvAmount:= 0;--累计勾兑发票
  matAccDif:= 0;--未勾兑发票
  per_applyPayAmount:= 0;--本期申请付款
  tot_applyPayAmount:= 0;--累计申请付款
  per_payAmount:= 0;--本期付款
  tot_payAmount:= 0;--累计付款
  tot_UnpayAmount:= 0;--累计未付款
  if v_startdate is not null then
    v_startperiod := to_date(v_startdate,'yyyyMMdd');
  end if;
  if v_enddate is not null then
    v_endperiod := to_date(v_enddate,'yyyyMMdd')+1;
  end if;

         --本期入库
         mat_settlesummary_matInAmount(v_projectorg,tt.CONTRACTID,v_billtypeInv,v_transtypeAdj,v_startperiod,v_endperiod,per_matInAmount);
         --累计入库
         mat_settlesummary_matInAmount(v_projectorg,tt.CONTRACTID,v_billtypeInv,v_transtypeAdj,null,v_endperiod,tot_matInAmount);
         --本期对账
         mat_settlesummary_matBalAmount(v_projectorg,tt.CONTRACTID,v_startperiod,v_endperiod,per_matBalAmount);
         --累计对账
         mat_settlesummary_matBalAmount(v_projectorg,tt.CONTRACTID,null,v_endperiod,tot_matBalAmount);
         tot_matInAmount:= nvl(tot_matInAmount,0);--入库累计
         tot_matBalAmount:= nvl(tot_matBalAmount,0);--累计对账
         --累计未对账 = 累计入库-累计已对账
         tot_matUnBalAmount:= tot_matInAmount - tot_matBalAmount;
         --本期供应商开票
         mat_settlesummary_matInvAmount(v_projectorg,tt.CONTRACTID,v_startperiod,v_endperiod,per_matInvAmount);
         --累计供应商开票
         mat_settlesummary_matInvAmount(v_projectorg,tt.CONTRACTID,null,v_endperiod,tot_matInvAmount);
         tot_matInvAmount:= nvl(tot_matInvAmount,0);--累计供应商开票
         --累计供应商未开票 = 累计对账-累计开票
         tot_matUninvAmount:= tot_matBalAmount-tot_matInvAmount;
         --本期勾兑发票
         mat_settlesummary_accInvAmount(v_projectorg,tt.CONTRACTID,v_startperiod,v_endperiod,per_accInvAmount);
         --累计勾兑发票
         mat_settlesummary_accInvAmount(v_projectorg,tt.CONTRACTID,null,v_endperiod,tot_accInvAmount);
         --未勾兑发票 = 累计供应商开票-累计勾兑发票
         tot_accInvAmount:= nvl(tot_accInvAmount,0);
         matAccDif:= tot_matInvAmount-tot_accInvAmount;
         --本期申请付款
         mat_settlesummary_appPayAmount(v_projectorg,tt.CONTRACTID,v_startperiod,v_endperiod,per_applyPayAmount);
         --累计申请付款
         mat_settlesummary_appPayAmount(v_projectorg,tt.CONTRACTID,null,v_endperiod,tot_applyPayAmount);
         --本期付款
         mat_settlesummary_payAmount(v_projectorg,tt.CONTRACTID,v_startperiod,v_endperiod,per_payAmount);
         --累计付款
         mat_settlesummary_payAmount(v_projectorg,tt.CONTRACTID,null,v_endperiod,tot_payAmount);
         --累计未付款 = 累计对账 -累计付款
         tot_UnpayAmount:= tot_matBalAmount-tot_payAmount;

    per_matInAmount:= nvl(per_matInAmount,0);--本期入库
    tot_matInAmount:= nvl(tot_matInAmount,0);--入库累计
    per_matBalAmount:= nvl(per_matBalAmount,0);--本期对账
    tot_matBalAmount:= nvl(tot_matBalAmount,0);--累计对账
    tot_matUnBalAmount:= nvl(tot_matUnBalAmount,0);--累计未对账
    per_matInvAmount:= nvl(per_matInvAmount,0);--本期供应商开票
    tot_matInvAmount:= nvl(tot_matInvAmount,0);--累计供应商开票
    tot_matUninvAmount:= nvl(tot_matUninvAmount,0);--累计供应商未开票
    per_accInvAmount:= nvl(per_accInvAmount,0);--本期勾兑发票
    tot_accInvAmount:= nvl(tot_accInvAmount,0);--累计勾兑发票
    matAccDif:= nvl(matAccDif,0);--未勾兑发票
    per_applyPayAmount:= nvl(per_applyPayAmount,0);--本期申请付款
    tot_applyPayAmount:= nvl(tot_applyPayAmount,0);--累计申请付款
    per_payAmount:= nvl(per_payAmount,0);--本期付款
    tot_payAmount:= nvl(tot_payAmount,0);--累计付款
    tot_UnpayAmount:= nvl(tot_UnpayAmount,0);--累计未付款


  insert into matsettlesum_temp(supplier,contract,originalamount,matInAmountPer,matInAmountTot,matBalAmountPer,matBalAmountTot,matUnBalAmountTot,matinvAmountPer,matinvAmountTot,matUninvAmountTot,accInvAmountPer,accInvAmountTot,matAccDif,payAmountPer,payAmountTot,Unpayamount,SUPPLIERID,CONTRACTID,Applypayamountper,Applypayamounttot)
  values (tt.SUPPLIERNAME,tt.CONTRACTNAME,tt.Foriginalamount,per_matInAmount,tot_matInAmount,per_matBalAmount,tot_matBalAmount,tot_matUnBalAmount,per_matInvAmount,tot_matInvAmount,tot_matUninvAmount,per_accInvAmount,tot_accInvAmount,matAccDif,per_payAmount,tot_payAmount,tot_UnpayAmount,tt.SUPPLIERID,tt.CONTRACTID,per_applyPayAmount,tot_applyPayAmount);

  end loop;
  close cc;
end mat_settlesummary;
/

