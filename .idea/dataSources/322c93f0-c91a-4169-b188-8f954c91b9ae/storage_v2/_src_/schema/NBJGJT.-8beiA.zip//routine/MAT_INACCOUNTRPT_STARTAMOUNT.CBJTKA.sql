create procedure mat_inaccountrpt_startAmount(
v_projectorg in varchar2 default '' ,
v_billtypeInv in varchar2,
v_billtypeAdj in varchar2,
v_transtypeAdj in varchar2,
v_contract in varchar2,
v_supplier in varchar2,
v_startperiod in NUMBER default 0,
v_matid in varchar2,
v_startqty out NUMBER ,
v_startprice out NUMBER,
v_startamount out NUMBER) is

TYPE cc_type is REF CURSOR ;
cc cc_type;
v_insql varchar2(2000);
v_adjsql varchar2(2000);
v_totsql varchar2(4000);


begin
  v_insql:= 'SELECT   sum(ENTRYS.FQty)  ENTRYSQTY,sum(ENTRYS.FAmount)  ENTRYSAMOUNT
                   FROM T_EC_MaterialInvBill  PURINWAREHSBILL
                   LEFT OUTER JOIN T_EC_MaterialInvBillEntry  ENTRYS ON PURINWAREHSBILL.FID = ENTRYS.FParentID
                   LEFT OUTER JOIN T_BD_Period  PERIOD ON PURINWAREHSBILL.FPeriodID = PERIOD.FID
                   LEFT OUTER JOIN T_EC_ContractBill  CONTRACT ON PURINWAREHSBILL.FContractID = CONTRACT.FID
                   LEFT OUTER JOIN T_BD_Supplier  PROVIDER ON PURINWAREHSBILL.FProviderID = PROVIDER.FID
                   LEFT OUTER JOIN T_ORG_Transport  PROJECTORG ON PURINWAREHSBILL.FProjectOrgID = PROJECTORG.FID
                   LEFT OUTER JOIN T_EC_TransactionType  TRANSTYPE ON PURINWAREHSBILL.FTransTypeID = TRANSTYPE.FID
                   LEFT OUTER JOIN T_EC_ResourceItem  MATERIAL ON ENTRYS.FMaterialID = MATERIAL.FID
                   LEFT OUTER JOIN T_EC_BillType  BILLTYPE ON TRANSTYPE.FBillTypeID = BILLTYPE.FID
                   WHERE PURINWAREHSBILL.FBillSate = 03 and PURINWAREHSBILL.Fprojectorgid = '''||v_projectorg||'''' ;
  v_insql:=v_insql||' and BILLTYPE.FID ='''||v_billtypeInv||'''';
  v_insql:=v_insql||' and MATERIAL.fid='''||v_matid||'''';
  v_insql:=v_insql||' and PERIOD.Fnumber<'''||v_startperiod||'''';

  v_adjsql:='SELECT  sum(ENTRYS.CFQty)  ENTRYSQTY,sum(ENTRYS.CFAmount)  ENTRYSAMOUNT
                   FROM CT_INV_InvAdjust  INVADJUST
                   LEFT OUTER JOIN CT_INV_InvAdjustEntry  ENTRYS ON INVADJUST.FID = ENTRYS.FParentID
                   LEFT OUTER JOIN T_ORG_Transport  PROJECTORG ON INVADJUST.CFProjectOrgID = PROJECTORG.FID
                   LEFT OUTER JOIN T_EC_TransactionType  TRANSTYPE ON INVADJUST.CFTransTypeID = TRANSTYPE.FID
                   LEFT OUTER JOIN T_BD_Period  PERIOD ON INVADJUST.CFPeriodID = PERIOD.FID
                   LEFT OUTER JOIN T_BD_Supplier  SUPPLIER ON INVADJUST.CFSupplierID = SUPPLIER.FID
                   LEFT OUTER JOIN T_EC_ContractBill  CONTRACT ON INVADJUST.CFContractID = CONTRACT.FID
                   LEFT OUTER JOIN T_EC_BillType  BILLTYPE ON TRANSTYPE.FBillTypeID = BILLTYPE.FID
                   LEFT OUTER JOIN T_EC_ResourceItem  MATERIAL ON ENTRYS.CFMaterialID = MATERIAL.FID
                   WHERE INVADJUST.CFBillSate = 03 and INVADJUST.Cfprojectorgid='''||v_projectorg||'''';
  v_adjsql:=v_adjsql||' and BILLTYPE.FID ='''||v_billtypeAdj||'''';
  v_adjsql:=v_adjsql||' and TRANSTYPE.FID ='''||v_transtypeAdj||'''';
  v_adjsql:=v_adjsql||' and MATERIAL.fid='''||v_matid||'''';
  v_adjsql:=v_adjsql||' and PERIOD.Fnumber<'''||v_startperiod||'''';

  if v_contract is not null then
     v_insql:= v_insql||' and PURINWAREHSBILL.Fcontractid ='''||v_contract||'''';
     v_adjsql:= v_adjsql||' and INVADJUST.Cfcontractid='''||v_contract||'''';
  end if;
  if v_supplier is not null then
     v_insql:= v_insql||' and PURINWAREHSBILL.FProviderID ='''||v_supplier||'''';
     v_adjsql:= v_adjsql||' and SUPPLIER.FID='''||v_contract||'''';
  end if;

  v_totsql:= 'select sum(ENTRYSQTY),sum(ENTRYSAMOUNT) from ( '||v_insql||'';
  v_totsql:= v_totsql||' union all '||v_adjsql||'';
  v_totsql:= v_totsql||' ) ';
  --dbms_output.put_line(v_totsql);
  open cc for v_totsql;
  loop
  fetch cc into v_startqty,v_startamount;
  exit when cc% notfound;

  end loop;
  v_startqty:=nvl(v_startqty,0);
  v_startamount:=nvl(v_startamount,0);
  if v_startqty=0 then
     v_startprice:=0;
  else
     v_startprice:= round(v_startamount/v_startqty,2);
  end if;
  close cc;
end mat_inaccountrpt_startAmount;
/

