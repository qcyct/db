create procedure ProjCapPlan_Sub_Mat(
v_projectorg in varchar2 default '' ,
v_startperiod in date,
v_endperiod in date) is
cursor cc is    select c.fname_l2 contractCostType,a.fpartbid supplierID,b.fname_l2 supplierName, a.fid contractID,a.fname contractName,a.foriginalamount contractAmount ,a.cfytaxrate taxRate,substr(a.fpaymentterms,0,400) paymentterms
from T_EC_ContractBill a
left outer join T_BD_Supplier b on b.fid=a.fpartbid
left outer join CT_BAS_ContractCostType c on c.fid=a.fcontractcosttypeid
left outer join T_BAS_ContractCostTypeTREE d on d.fid= c.ftreeid
where a.fprojectorgid=v_projectorg
and d.fnumber ='04' --专业分包拆分合同  材料合同拆分
and a.fcontractclass='2'-- 合同类型 购销合同
and a.fcontractattribute='0' --合同性质  原始合同
and a.fcontractstatus in ('3','6','10') --合同状态 批准 签订 执行
order by c.fnumber asc;

tt cc%rowtype;
v_paypercent number(28,10);--付款比例

per_matBalAmount number(28,10);--本期对账
tot_matBalAmount number(28,10);--累计对账

tot_payAmount  number(28,10);--累计付款
tot_unPayAmount number(28,10);--累计未付
v_seqNum integer;
begin
  select count(*)+1 into v_seqNum FROM  ProjCapPlan_temp;
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;

  per_matBalAmount:= 0;--本期对账
  tot_matBalAmount:= 0;--累计对账
  tot_payAmount:=0;--累计付款
  tot_unPayAmount:=0;--累计未付

   --本期对账
   mat_settlesummary_matBalAmount(v_projectorg,tt.CONTRACTID,v_startperiod,v_endperiod,per_matBalAmount);

   --累计对账
   mat_settlesummary_matBalAmount(v_projectorg,tt.CONTRACTID,null,v_endperiod,tot_matBalAmount);

   --累计付款
   mat_settlesummary_payAmount(v_projectorg,tt.CONTRACTID,null,v_endperiod,tot_payAmount);

   --累计未付 = 累计对账-累计已付
    tot_unPayAmount:= tot_matBalAmount-tot_payAmount;

   --付款比例  = 累计付款/累计对账
   if tot_matBalAmount>0 then
      v_paypercent:= round(tot_payAmount/tot_matBalAmount,2);
   else
      v_paypercent:= 0;
   end if;
   per_matBalAmount:= nvl(per_matBalAmount,0);--本期对账
   tot_matBalAmount:= nvl(tot_matBalAmount,0);--累计对账
   tot_payAmount:= nvl(tot_payAmount,0);--累计付款
   tot_unPayAmount:= nvl(tot_unPayAmount,0);--累计未付

   insert into ProjCapPlan_temp(contractCostType,supplierName,supplierID,contractID,contractName,contractAmount,taxRate,permatBalAmount,totmatBalAmount,totpayAmount,totunPayAmount,paypercent,paymentterms,Countsign,Seqnum )
   values(tt.contractcosttype,tt.suppliername,tt.supplierid,tt.contractid,tt.contractname,tt.contractamount,tt.taxRate,per_matBalAmount,tot_matBalAmount,tot_payAmount,tot_unPayAmount,v_paypercent,tt.paymentterms,'4',v_seqNum);
   v_seqNum:=v_seqNum+1;
  end loop;
  close cc;

end ProjCapPlan_Sub_Mat;
/

