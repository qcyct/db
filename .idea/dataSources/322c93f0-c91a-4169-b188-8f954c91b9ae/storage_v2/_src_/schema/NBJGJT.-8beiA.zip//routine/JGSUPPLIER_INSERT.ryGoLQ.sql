create procedure JGSupplier_Insert is
cursor cc is    select a.cfsuppliername ,a.cfcorpcreditcode,a.cfmaster,a.cfmasteridcard,a.cfregaddress,a.cflinkman,a.cflinkmanidcard,a.cfcontacttell,a.cfmailaddr,
a.cffaxnum,a.cfaccountbank,a.cfaccount,a.cfsuppliertype,a.cfsuppliertypenumber,a.cfsuppliertypetreeid,a.cfcorpnature,a.cftaxpayertype,a.cfjgcostaccountid,a.cfcreatedepid  from jgsupplier_temp2 a;

tt cc%rowtype;
v_seqnum integer;
i integer;
v_number varchar2(44);
begin
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;
    select count(*) into i from CT_SUP_JGSupplier  where Cfcorpcreditcode like '%'||tt.Cfcorpcreditcode||'%' ;
    if i=0 then
       select  cfseqnumber+1 into v_seqnum  from CT_SPB_JGSupplierCustomerSeq   where  cfcssgrouptreeid=tt.cfsuppliertypetreeid ;
       v_number:= tt.cfsuppliertypenumber||'-'||lpad(v_seqnum,6,'0');
       update CT_SPB_JGSupplierCustomerSeq  set cfseqnumber=cfseqnumber+1   where cfcssgrouptreeid=tt.Cfsuppliertypetreeid ;

       insert into CT_SUP_JGSupplier (fid,FNumber,Cfsuppliername,Cfcorpcreditcode,Cfmaster,Cfmasteridcard,Cfregaddress,
                                      Cflinkman,Cflinkmanidcard,Cfcontacttell,cfmailaddr,Cffaxnum,Cfaccountbank,Cfaccount,
                                      Cfsuppliertype,Cfsuppliertypenumber,Cfsuppliertypetreeid,Cfcorpnature,Cftaxpayertype,
                                      Fcreatorid,Fcreatetime,Fbizdate,Cfbillstate,Fcontrolunitid,Cfjgcostaccountid,Cfcreatedepid  )
       values (newbosid('D9314E30'),v_number,tt.cfsuppliername,tt.cfcorpcreditcode,tt.cfmaster,tt.cfmasteridcard,tt.Cfregaddress,
              tt.Cflinkman,tt.Cflinkmanidcard,tt.Cfcontacttell,tt.cfmailaddr,tt.Cffaxnum,tt.Cfaccountbank,tt.cfaccount,
              tt.Cfsuppliertype,tt.Cfsuppliertypenumber,tt.Cfsuppliertypetreeid,tt.Cfcorpnature,tt.Cftaxpayertype,
              '256c221a-0106-1000-e000-10d7c0a813f413B7DE7F',systimestamp,sysdate,'02','00000000-0000-0000-0000-000000000000CCE7AED4',
              tt.cfjgcostaccountid,tt.cfcreatedepid);
    end if;


  end loop;
  close cc;
end JGSupplier_Insert;
/

