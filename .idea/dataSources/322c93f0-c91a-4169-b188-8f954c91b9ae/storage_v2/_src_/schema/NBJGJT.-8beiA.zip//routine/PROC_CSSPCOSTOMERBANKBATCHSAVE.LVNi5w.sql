create procedure proc_csspCostomerBankBatchSave(
v_csspID in varchar2, 
v_bank in varchar2, 
v_bankAccount in varchar2
) 
is
--1、查询所有客商财务卡片信息；T_BD_SupplierCompanyInfo T_BD_CustomerCompanyInfo
cursor cc is   select FID from T_BD_CustomerCompanyInfo where  FEffectedStatus = 2 and  FUsingStatus = 0 and FCustomerID = v_csspID ;

tt cc%rowtype;
i integer;
begin 
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;
  
  --查询 供应商财务银行 ,如果不存在 就添加，存在跳过
  select count(fid) into i from T_BD_CustomerCompanyBank where FCustomerCompanyInfoID = tt.fid and FBankAccount = v_bankAccount ;
  if i=0 then
    insert into T_BD_CustomerCompanyBank(fid,FSeq,FCustomerCompanyInfoID,FBank,FBankAccount,FBankAddress)  values (newbosid('18D45F6B'),1,tt.fid,v_bank,v_bankAccount ,'') ;
  end if;

  end loop;
  close cc;
end proc_csspCostomerBankBatchSave;
/

