create trigger PEREMAILUPDATETRIGGER
    before update of FEMAIL
    on T_BD_PERSON
    for each row
BEGIN
   :new.FLastUpdateTime:=sysdate;     
END;
/

