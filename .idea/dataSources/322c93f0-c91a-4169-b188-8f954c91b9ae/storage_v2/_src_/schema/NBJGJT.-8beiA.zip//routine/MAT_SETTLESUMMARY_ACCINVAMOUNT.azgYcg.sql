create procedure mat_settlesummary_accInvAmount(
v_projectorg in varchar2 default '' ,
v_contractID in varchar2,
v_startperiod in date,
v_endperiod in date,
v_accInvAmount out NUMBER) as
i integer;
begin
  if v_startperiod is null then --发票勾兑累计
      select count(*) into i
      from CT_II_InvoiceCheckBill InvoiceCheckBill
      where InvoiceCheckBill.Cfcfcontractid0=v_contractID
            and InvoiceCheckBill.cfprojectorgid=v_projectorg
            and InvoiceCheckBill.cfbillsate in ('03','04','05','06','10')
            and InvoiceCheckBill.fbizdate<v_endperiod ;

      if i>0 then
      select sum(InvoiceCheckBill.cforiginalamount) into v_accInvAmount
      from CT_II_InvoiceCheckBill InvoiceCheckBill
      where InvoiceCheckBill.Cfcfcontractid0=v_contractID
            and InvoiceCheckBill.cfprojectorgid=v_projectorg
            and InvoiceCheckBill.cfbillsate in ('03','04','05','06','10')
            and InvoiceCheckBill.fbizdate<v_endperiod ;
      end if;

  else    --当期
      select count(*) into i
      from CT_II_InvoiceCheckBill InvoiceCheckBill
      where InvoiceCheckBill.Cfcfcontractid0=v_contractID
            and InvoiceCheckBill.cfprojectorgid=v_projectorg
            and InvoiceCheckBill.cfbillsate in ('03','04','05','06','10')
            and InvoiceCheckBill.fbizdate>=v_startperiod
            and InvoiceCheckBill.fbizdate<v_endperiod ;

      if i>0 then
      select sum(InvoiceCheckBill.cforiginalamount) into v_accInvAmount
      from CT_II_InvoiceCheckBill InvoiceCheckBill
      where InvoiceCheckBill.Cfcfcontractid0=v_contractID
            and InvoiceCheckBill.cfprojectorgid=v_projectorg
            and InvoiceCheckBill.cfbillsate in ('03','04','05','06','10')
            and InvoiceCheckBill.fbizdate>=v_startperiod
            and InvoiceCheckBill.fbizdate<v_endperiod ;
      end if;
  end if;
end mat_settlesummary_accInvAmount;
/

