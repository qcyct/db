create view XXHREPORT as
SELECT A.FNUMBER 项目编号,A.FNAME_L2 名称,B.counts 近5日入库数,C.counts 当月25号对账数,D.counts 本月零星记录,E.counts 本月其他费用记录 FROM T_ORG_BaseUnit A LEFT JOIN 
(
--近五日
SELECT b.fnumber,b.fname_l2,count(a.fid) counts FROM T_EC_MaterialInvBill A 
left join T_ORG_BaseUnit b on b.fid=a.FprojectOrgID
WHERE A.FprojectOrgID in ('ECZPxMlXQf+/gUdcEgMOFcznrtQ=', 'JG+9sI4JTVOL6llNdzl2jMznrtQ=', 'TG0ki3KKQ0Oc9T0wrvc8ZcznrtQ=', 'ZWHOOPrMTh6UvMPWox8C3MznrtQ=', 'f0lJiEsIQPyLDjNv+khYZ8znrtQ=', 'mbUAAAA+fx/M567U', 'mbUAAAA9ufDM567U', 'mbUAAAAQ8G/M567U', 'mbUAAAASkrXM567U', 'mbUAAAAgqSzM567U', 'mbUAAAAhkgfM567U', 'mbUAAAAsC+HM567U', 'mbUAAAAx9lvM567U', 'mbUAAAAzG2/M567U', 'mbUAAABCA9bM567U', 'uQcQIQUVTxuBcDHKTTF9rsznrtQ=', 'xfW12kZyQDen+W1vyi4RccznrtQ=')
and a.FBILLSATE='03'
and to_char(A.FCREATETIME,'yyyy-MM-dd')>=SYSDATE - 5
group by b.fnumber,b.fname_l2
) B ON A.FNUMBER=B.FNUMBER
LEFT JOIN (
--当月25号对账数
SELECT  b.fnumber,b.fname_l2,count(a.fid) counts FROM  CT_SET_MTBalanceBill a
left join T_ORG_BaseUnit b on b.fid=a.CFPROJECTORGID
WHERE A.CFPROJECTORGID in ('ECZPxMlXQf+/gUdcEgMOFcznrtQ=', 'JG+9sI4JTVOL6llNdzl2jMznrtQ=', 'TG0ki3KKQ0Oc9T0wrvc8ZcznrtQ=', 'ZWHOOPrMTh6UvMPWox8C3MznrtQ=', 'f0lJiEsIQPyLDjNv+khYZ8znrtQ=', 'mbUAAAA+fx/M567U', 'mbUAAAA9ufDM567U', 'mbUAAAAQ8G/M567U', 'mbUAAAASkrXM567U', 'mbUAAAAgqSzM567U', 'mbUAAAAhkgfM567U', 'mbUAAAAsC+HM567U', 'mbUAAAAx9lvM567U', 'mbUAAAAzG2/M567U', 'mbUAAABCA9bM567U', 'uQcQIQUVTxuBcDHKTTF9rsznrtQ=', 'xfW12kZyQDen+W1vyi4RccznrtQ=')
and a.CFBillSate='03'
and to_char(A.FCREATETIME,'yyyy-MM-dd')>=trunc(sysdate,'mm') 
AND to_char(A.FCREATETIME,'yyyy-MM-dd')<=trunc(sysdate,'mm')+24
group by b.fnumber,b.fname_l2
) C ON A.FNUMBER=C.fnumber
LEFT JOIN (
--本月零星
SELECT b.fnumber,b.fname_l2,count(a.fid) counts FROM CT_INV_SporadicMatReg A 
left join T_ORG_BaseUnit b on b.fid=a.CFPROJECTORGID
WHERE A.CFPROJECTORGID in ('ECZPxMlXQf+/gUdcEgMOFcznrtQ=', 'JG+9sI4JTVOL6llNdzl2jMznrtQ=', 'TG0ki3KKQ0Oc9T0wrvc8ZcznrtQ=', 'ZWHOOPrMTh6UvMPWox8C3MznrtQ=', 'f0lJiEsIQPyLDjNv+khYZ8znrtQ=', 'mbUAAAA+fx/M567U', 'mbUAAAA9ufDM567U', 'mbUAAAAQ8G/M567U', 'mbUAAAASkrXM567U', 'mbUAAAAgqSzM567U', 'mbUAAAAhkgfM567U', 'mbUAAAAsC+HM567U', 'mbUAAAAx9lvM567U', 'mbUAAAAzG2/M567U', 'mbUAAABCA9bM567U', 'uQcQIQUVTxuBcDHKTTF9rsznrtQ=', 'xfW12kZyQDen+W1vyi4RccznrtQ=')
and a.CFBillState='03'
and to_char(A.FCREATETIME,'yyyy-MM')=to_char(SYSDATE,'yyyy-MM')
group by b.fnumber,b.fname_l2
) D ON D.FNUMBER=A.FNUMBER
LEFT JOIN (
--本月其他费用
SELECT b.fnumber,b.fname_l2,count(a.fid) counts FROM CT_INV_OtherCostReg A 
left join T_ORG_BaseUnit b on b.fid=a.CFPROJECTORGID
WHERE A.CFPROJECTORGID in ('ECZPxMlXQf+/gUdcEgMOFcznrtQ=', 'JG+9sI4JTVOL6llNdzl2jMznrtQ=', 'TG0ki3KKQ0Oc9T0wrvc8ZcznrtQ=', 'ZWHOOPrMTh6UvMPWox8C3MznrtQ=', 'f0lJiEsIQPyLDjNv+khYZ8znrtQ=', 'mbUAAAA+fx/M567U', 'mbUAAAA9ufDM567U', 'mbUAAAAQ8G/M567U', 'mbUAAAASkrXM567U', 'mbUAAAAgqSzM567U', 'mbUAAAAhkgfM567U', 'mbUAAAAsC+HM567U', 'mbUAAAAx9lvM567U', 'mbUAAAAzG2/M567U', 'mbUAAABCA9bM567U', 'uQcQIQUVTxuBcDHKTTF9rsznrtQ=', 'xfW12kZyQDen+W1vyi4RccznrtQ=')
and a.CFBillState='03'
and to_char(A.FCREATETIME,'yyyy-MM')=to_char(SYSDATE,'yyyy-MM')
group by b.fnumber,b.fname_l2
) E ON E.FNUMBER=A.FNUMBER
WHERE A.FID IN  ('ECZPxMlXQf+/gUdcEgMOFcznrtQ=', 'JG+9sI4JTVOL6llNdzl2jMznrtQ=', 'TG0ki3KKQ0Oc9T0wrvc8ZcznrtQ=', 'ZWHOOPrMTh6UvMPWox8C3MznrtQ=', 'f0lJiEsIQPyLDjNv+khYZ8znrtQ=', 'mbUAAAA+fx/M567U', 'mbUAAAA9ufDM567U', 'mbUAAAAQ8G/M567U', 'mbUAAAASkrXM567U', 'mbUAAAAgqSzM567U', 'mbUAAAAhkgfM567U', 'mbUAAAAsC+HM567U', 'mbUAAAAx9lvM567U', 'mbUAAAAzG2/M567U', 'mbUAAABCA9bM567U', 'uQcQIQUVTxuBcDHKTTF9rsznrtQ=', 'xfW12kZyQDen+W1vyi4RccznrtQ=')
order by a.fnumber
/

