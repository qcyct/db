create PROCEDURE GetResultSetNew(sql1     IN VARCHAR2,
                                            sql2     IN VARCHAR2,
                                            sql3     IN VARCHAR2,
                                            sql4     IN VARCHAR2,
                                            sql5     IN VARCHAR2,
                                            sql6     IN VARCHAR2,
                                            sql7     IN VARCHAR2,
                                            sql8     IN VARCHAR2,
                                            sql9     IN VARCHAR2,
                                            sql10    IN VARCHAR2,
                                            p_CURSOR out GetResultSetPACKAGE.ResultSet_CURSOR) IS

BEGIN

  OPEN p_CURSOR FOR sql1 || sql2 || sql3 || sql4 || sql5 || sql6 || sql7 || sql8 || sql9|| sql10;

END GetResultSetNew;


/

