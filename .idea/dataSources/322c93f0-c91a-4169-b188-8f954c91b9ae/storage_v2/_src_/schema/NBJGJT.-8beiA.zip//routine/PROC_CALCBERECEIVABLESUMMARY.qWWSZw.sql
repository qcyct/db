create procedure proc_calcBEReceivableSummary
(
isProjectOrg in varchar2 default '1',
baseUnitID in varchar2 default '' ,
startDate in varchar2 default '',
endDate in varchar2 default ''
)
as
begin 
--清空缓存表
delete from T_BE_BEReceivableSummaryTemp ;
--1 根据项目组织过滤,通过组织获取对应的资金项目，通过资金项目过滤

if isProjectOrg = '1' then --根据单项目过滤

  insert into T_BE_BEReceivableSummaryTemp (COLUMN1,COLUMN2,COLUMN3,COLUMN4,COLUMN5,COLUMN6,COLUMN7,COLUMN8,COLUMN9,COLUMN10,COLUMN11,COLUMN12,COLUMN13,COLUMN14,COLUMN15,COLUMN16,COLUMN17,COLUMN18,COLUMN19,COLUMN20,COLUMN21,COLUMN22,COLUMN23,COLUMN24,COLUMN25,COLUMN26)
  select pro.fName_l2,org.fname_l2 ,

  nvl(init.init工程款,0) 工程款,nvl(init.init往来款,0) 往来款,nvl(init.init其他收入,0) init其他收入,
  nvl(init.init工程款,0) + nvl(init.init往来款,0) + nvl(init.init其他收入,0)  期初小计,
  
  nvl(actRec.R工程款,0),nvl(actRec.R往来款,0),nvl(actRec.R其他收入,0),
  nvl(actRec.R工程款,0)+ nvl(actRec.R往来款,0)+nvl(actRec.R其他收入,0) 本期小计,

  nvl(actPay.P材料费,0),nvl(actPay.P人工费,0),nvl(actPay.P分包费,0),nvl(actPay.P机械费,0),nvl(rebill.billamt ,0) 票据到期 ,nvl(actPay.P财务费用 ,0),nvl(actPay.P经营管理费用 ,0),nvl(actPay.P往来款,0),nvl(actPay.P其他支出,0),nvl(discont.billamt,0) 票据贴现,
  nvl(actPay.P材料费,0)+nvl(actPay.P人工费,0)+nvl(actPay.P分包费,0)+ nvl(actPay.P机械费,0) + nvl(rebill.billamt ,0)+nvl(actPay.P财务费用 ,0)+nvl(actPay.P经营管理费用 ,0)+nvl(actPay.P往来款,0)+nvl(actPay.P其他支出,0)+nvl(discont.billamt,0)  本期支出小计,
  0,0,0,0,0

  from T_BD_Project pro
  left join (
       /*查询本期收款*/
    select actRec.* from (
      select a.FProjectID,b.fname_l2 name,nvl(a.FBillAmt,0) ACTRECAMT --c.fname_l2 company
        from T_NT_ReceivableBill a
        left join T_CAS_FeeType b on b.fid = a.CFSFLBID
        --left join  T_ORG_Company c on c.fid = a.FCompanyID
        --left join T_BD_Project d on d.fid = a.FProjectID
        where 1=1
        and a.FProjectID = baseUnitID
        and TO_CHAR(A.FTakeDate, 'YYYY-MM-DD') >= startDate -- startDate
        and TO_CHAR(A.FTakeDate, 'YYYY-MM-DD') <= endDate-- endDate
      )
        pivot (
        SUM(ACTRECAMT) for name in ('工程款' R工程款,'往来款' R往来款,'其他收入' R其他收入)
        ) actRec 
  ) actRec on actRec.FProjectID = pro.fid
left join (
      select pay.* from (
         select a.FProjectID,b.fname_l2 name,nvl(a.FLocalAmount,0) ACTRECAMT --c.fname_l2 company
         from T_NT_EndorsementBill a
         left join T_CAS_FeeType b on b.fid = a.CFSFLB2ID
         --left join  T_ORG_Company c on c.fid = a.FCompanyID
          --left join T_BD_Project d on d.fid = a.FProjectID
          where 1=1
          and a.FProjectID = baseUnitID
          and TO_CHAR(A.FEndorseDate, 'YYYY-MM-DD') >= startDate -- startDate
          and TO_CHAR(A.FEndorseDate, 'YYYY-MM-DD') <= endDate-- endDate
      )
      pivot (
        SUM(ACTRECAMT) for name in ('材料费' P材料费,'工人费' P人工费,'分包费' P分包费,'机械费' P机械费,'财务费用' P财务费用,'经营管理费用' P经营管理费用 ,'往来款' P往来款,'其他支出' P其他支出)
      ) pay
    ) actPay on  actPay.FProjectID = pro.fid --actRec. FProjectID = actPay.FProjectID and

left join (
--应收票据到期时间内的收款状态汇总
select FProjectId, sum(FBillAmt) billamt from  T_NT_ReceivableBill bill 
	where  1=1 
	  and FBillState=4
	  and TO_CHAR(bill.FExpiredDate, 'YYYY-MM-DD') >= startDate -- startDate
	  and TO_CHAR(bill.FExpiredDate, 'YYYY-MM-DD') <= endDate-- endDate
	group by FProjectId 
) rebill on rebill.FProjectId = pro.fid


--票据贴现,应收票据贴现查询中本月贴现的票据金额合计。
left join (
select FProjectId,sum(FBillAmt) billamt from  T_NT_ReceivableBill bill 
	where  1=1
	  and FBillState=3
	  and TO_CHAR(bill.FTransferDate, 'YYYY-MM-DD') >= startDate -- startDate
	  and TO_CHAR(bill.FTransferDate, 'YYYY-MM-DD') <= endDate-- endDate
	group by FProjectId
)
discont on discont.FProjectId = pro.fid
   
left join 
(            
/*条件1：收票日期《开始日期，登记状态 应收票据

条件2.1：
	1、收票日期《开始日期，（可不考虑状态：不等于登记状态）； 且    
	2、关联背书单，背书日期在期间内，（应收票据，FTransferDate 在期间内的 对内及对外背书）
	
条件2.2：
	1、收票日期《开始日期，（可不考虑状态：不等于登记状态）； 且    
	2、关联贴现单，贴现日期在期间内， （应收票据，FTransferDate 在期间内的 贴现状态）
	
条件2.3：
	1、收票日期《开始日期，（可不考虑状态：不等于登记状态）； 且    
	2、票据到期日在期间内 收款状态金额	
	
期初：条件1 + 条件2.1 + 2.2 + 2.3

保存=0,登记=1,审批=8,对内背书=7,对外背书=2,贴现=3,收款=4,作废=9,转贷款=10,入池质押=11,入池托管=12
*/
select FProjectID,sum(nvl(INIT工程款,0)) INIT工程款,sum(nvl(init往来款,0)) init往来款,sum(nvl(init其他收入,0)) init其他收入 
from (
	select actRec.* from (
          select a.FProjectID,b.fname_l2 name,nvl(a.FBillAmt,0) ACTRECAMT --c.fname_l2 company
            from T_NT_ReceivableBill a
            left join T_CAS_FeeType b on b.fid = a.CFSFLBID
            --left join  T_ORG_Company c on c.fid = a.FCompanyID
            --left join T_BD_Project d on d.fid = a.FProjectID
            where a.FBillState=1 --登记
            and a.FProjectID = baseUnitID
            and TO_CHAR(A.FTakeDate, 'YYYY-MM-DD') < startDate-- endDate
          )
            pivot (
            SUM(ACTRECAMT) for name in ('工程款' init工程款,'往来款' init往来款,'其他收入' init其他收入)
            ) actRec
	union all            
	select actRec.* from (
	          select a.FProjectID,b.fname_l2 name,nvl(a.FBillAmt,0) ACTRECAMT --c.fname_l2 company
	            from T_NT_ReceivableBill a
	            left join T_CAS_FeeType b on b.fid = a.CFSFLBID
	            --left join  T_ORG_Company c on c.fid = a.FCompanyID
	            --left join T_BD_Project d on d.fid = a.FProjectID
	            where a.FBillState in (2,3,7) --对内背书=7,对外背书=2,贴现=3, 条件2.1、2.2合并
	            and a.FProjectID = baseUnitID
	            and TO_CHAR(A.FTakeDate, 'YYYY-MM-DD') < startDate-- endDate
	            and TO_CHAR(a.FTransferDate, 'YYYY-MM-DD') >= startDate -- startDate
		  				and TO_CHAR(a.FTransferDate, 'YYYY-MM-DD') <= endDate-- endDate
	          )
	            pivot (
	            SUM(ACTRECAMT) for name in ('工程款' init工程款,'往来款' init往来款,'其他收入' init其他收入)
	            ) actRec     
	union all            
	select actRec.* from (
	          select a.FProjectID,b.fname_l2 name,nvl(a.FBillAmt,0) ACTRECAMT --c.fname_l2 company
	            from T_NT_ReceivableBill a
	            left join T_CAS_FeeType b on b.fid = a.CFSFLBID
	            --left join  T_ORG_Company c on c.fid = a.FCompanyID
	            --left join T_BD_Project d on d.fid = a.FProjectID
	            where a.FBillState = 4 --收款 条件2.3
	            and a.FProjectID = baseUnitID
	            and TO_CHAR(A.FTakeDate, 'YYYY-MM-DD') < startDate-- endDate
		  				and TO_CHAR(a.FExpiredDate, 'YYYY-MM-DD') >= startDate -- startDate
		  				and TO_CHAR(a.FExpiredDate, 'YYYY-MM-DD') <= endDate-- endDate
	          )
	            pivot (
	            SUM(ACTRECAMT) for name in ('工程款' init工程款,'往来款' init往来款,'其他收入' init其他收入)
	            ) actRec                    
) init group by FProjectID                  
)     init on init.FProjectID = pro.fid

  left join T_ORG_Company org on org.fid = pro.FCompanyID
     
  where pro.fid = baseUnitID   ;

elsif isProjectOrg = '0' then --根据财务组织过滤项目，再关联初始化数据 

insert into T_BE_BEReceivableSummaryTemp (COLUMN1,COLUMN2,COLUMN3,COLUMN4,COLUMN5,COLUMN6,COLUMN7,COLUMN8,COLUMN9,COLUMN10,COLUMN11,COLUMN12,COLUMN13,COLUMN14,COLUMN15,COLUMN16,COLUMN17,COLUMN18,COLUMN19,COLUMN20,COLUMN21,COLUMN22,COLUMN23,COLUMN24,COLUMN25,COLUMN26)
select pro.projectname,org.fname_l2 company ,
  nvl(init.init工程款,0) 工程款,nvl(init.init往来款,0) 往来款,nvl(init.init其他收入,0) init其他收入,
  nvl(init.init工程款,0) + nvl(init.init往来款,0) + nvl(init.init其他收入,0)  期初小计,
  
  nvl(actRec.R工程款,0),nvl(actRec.R往来款,0),nvl(actRec.R其他收入,0),
  nvl(actRec.R工程款,0)+ nvl(actRec.R往来款,0)+nvl(actRec.R其他收入,0) 本期小计,
  
  nvl(actPay.P材料费,0),nvl(actPay.P人工费,0),nvl(actPay.P分包费,0),nvl(actPay.P机械费,0),nvl(rebill.billamt ,0) 票据到期,nvl(actPay.P财务费用 ,0),nvl(actPay.P经营管理费用 ,0),nvl(actPay.P往来款,0),nvl(actPay.P其他支出,0),nvl(discont.billamt,0) 票据贴现,
  nvl(actPay.P材料费,0)+nvl(actPay.P人工费,0)+nvl(actPay.P分包费,0)+nvl(actPay.P机械费,0) + nvl(rebill.billamt ,0)+nvl(actPay.P财务费用 ,0)+nvl(actPay.P经营管理费用 ,0)+nvl(actPay.P往来款,0)+nvl(actPay.P其他支出,0)+nvl(discont.billamt,0)  本期支出小计,
  0,0,0,0,0
from (
  select distinct b.fid FCompanyID,b.fname_l2 company,a.FProjectID,c.FNAME_L2 projectname from T_NT_ReceivableBill a 
    left join t_org_company b on a.FCompanyID = b.fid
    left join T_BD_Project c on a.FProjectID  = c.fid
    where a.FProjectID is not null 
    and a.FCompanyID = baseUnitID
  union 
    select distinct b.fid companyId,b.fname_l2,a.FProjectID,c.FNAME_L2 from T_NT_EndorsementBill a 
    left join t_org_company b on a.FCompanyID = b.fid
    left join T_BD_Project c on a.FProjectID  = c.fid
    where a.FProjectID is not null 
    and a.FCompanyID = baseUnitID
) pro
left join (
      /*查询本期收款*/
      select rec.* from (
      select d.fname_l2 projectname,b.fname_l2 name,nvl(a.FBillAmt,0) ACTRECAMT --c.fname_l2 company
      from T_NT_ReceivableBill a
      left join T_CAS_FeeType b on b.fid = a.CFSFLBID
      --left join  T_ORG_Company c on c.fid = a.FCompanyID
      left join T_BD_Project d on d.fid = a.FProjectID
      where 1=1
      and a.FCompanyID = baseUnitID
      and TO_CHAR(A.FTakeDate, 'YYYY-MM-DD') >= startDate -- startDate
      and TO_CHAR(A.FTakeDate, 'YYYY-MM-DD') <= endDate-- endDate
      )
      pivot (
       SUM(ACTRECAMT) for name in ('工程款' R工程款,'往来款' R往来款,'其他收入' R其他收入)
      ) rec 
    )
    actRec on actRec.projectname = pro.projectname 
    /*出去：背书单，背书日期+财务组织*/
    left join (
      select pay.* from (
          select d.fname_l2 projectname,b.fname_l2 name,nvl(a.FLocalAmount,0) actPayAmt 
          from T_NT_EndorsementBill a
          left join T_CAS_FeeType b on b.fid = a.CFSFLB2ID
          --left join  T_ORG_Company c on c.fid = a.FCompanyID
          left join T_BD_Project d on d.fid = a.FProjectID
          where 1=1
          and a.FCompanyID = baseUnitID
          and TO_CHAR(A.FEndorseDate, 'YYYY-MM-DD') >= startDate -- startDate
          and TO_CHAR(A.FEndorseDate, 'YYYY-MM-DD') <= endDate-- endDate
      )
      pivot (
      SUM(actPayAmt) for name in ('材料费' P材料费,'工人费' P人工费,'分包费' P分包费,'机械费' P机械费,'财务费用' P财务费用,'经营管理费用' P经营管理费用 ,'往来款' P往来款,'其他支出' P其他支出)
      ) pay
    ) actPay on  actPay.projectname = pro.projectname  --actRec. FProjectID = actPay.FProjectID and
    
left join (
--应收票据到期时间内的收款状态汇总
select d.fname_l2 projectname, sum(FBillAmt) billamt from  T_NT_ReceivableBill bill
left join T_BD_Project d on d.fid = bill.FProjectID 
	where  bill.FCompanyID = baseUnitID
	  and FBillState=4
	  and TO_CHAR(bill.FExpiredDate, 'YYYY-MM-DD') >= startDate -- startDate
	  and TO_CHAR(bill.FExpiredDate, 'YYYY-MM-DD') <= endDate-- endDate
	group by d.fname_l2 
) rebill on rebill.projectname = pro.projectname

--票据贴现,应收票据贴现查询中本月贴现的票据金额合计。
left join (
select d.fname_l2 projectname,sum(FBillAmt) billamt from  T_NT_ReceivableBill bill 
	left join T_BD_Project d on d.fid = bill.FProjectID 
	where  bill.FCompanyID = baseUnitID
	  and FBillState=3
	  and TO_CHAR(bill.FTransferDate, 'YYYY-MM-DD') >= startDate -- startDate
	  and TO_CHAR(bill.FTransferDate, 'YYYY-MM-DD') <= endDate-- endDate
	group by d.fname_l2 
)
discont on discont.projectname = pro.projectname

 left join 
(
/*条件1：收票日期《开始日期，登记状态 应收票据

条件2.1：
	1、收票日期《开始日期，（可不考虑状态：不等于登记状态）； 且    
	2、关联背书单，背书日期在期间内，（应收票据，FTransferDate 在期间内的 对内及对外背书）
	
条件2.2：
	1、收票日期《开始日期，（可不考虑状态：不等于登记状态）； 且    
	2、关联贴现单，贴现日期在期间内， （应收票据，FTransferDate 在期间内的 贴现状态）
	
条件2.3：
	1、收票日期《开始日期，（可不考虑状态：不等于登记状态）； 且    
	2、票据到期日在期间内 收款状态金额	
	
期初：条件1 + 条件2.1 + 2.2 + 2.3

保存=0,登记=1,审批=8,对内背书=7,对外背书=2,贴现=3,收款=4,作废=9,转贷款=10,入池质押=11,入池托管=12
*/
select projectname,sum(nvl(INIT工程款,0)) INIT工程款,sum(nvl(init往来款,0)) init往来款,sum(nvl(init其他收入,0)) init其他收入 
from (
	select actRec.* from (
	          select d.fname_l2 projectname,b.fname_l2 name,nvl(a.FBillAmt,0) ACTRECAMT --c.fname_l2 company
	            from T_NT_ReceivableBill a
	            left join T_CAS_FeeType b on b.fid = a.CFSFLBID
	            --left join  T_ORG_Company c on c.fid = a.FCompanyID
	            left join T_BD_Project d on d.fid = a.FProjectID
	            where a.FBillState=1 --登记
	            and a.FCompanyID = baseUnitID
	            and TO_CHAR(A.FTakeDate, 'YYYY-MM-DD') < startDate-- endDate
	          )
	            pivot (
	            SUM(ACTRECAMT) for name in ('工程款' init工程款,'往来款' init往来款,'其他收入' init其他收入)
	            ) actRec
	union all            
	select actRec.* from (
	          select d.fname_l2 projectname,b.fname_l2 name,nvl(a.FBillAmt,0) ACTRECAMT --c.fname_l2 company
	            from T_NT_ReceivableBill a
	            left join T_CAS_FeeType b on b.fid = a.CFSFLBID
	            --left join  T_ORG_Company c on c.fid = a.FCompanyID
	            left join T_BD_Project d on d.fid = a.FProjectID
	            where a.FBillState in (2,3,7) --对内背书=7,对外背书=2,贴现=3, 条件2.1、2.2合并
	            and a.FCompanyID = baseUnitID
	            and TO_CHAR(A.FTakeDate, 'YYYY-MM-DD') < startDate-- endDate
	            and TO_CHAR(a.FTransferDate, 'YYYY-MM-DD') >= startDate -- startDate
		  				--and TO_CHAR(a.FTransferDate, 'YYYY-MM-DD') <= endDate-- endDate
	          )
	            pivot (
	            SUM(ACTRECAMT) for name in ('工程款' init工程款,'往来款' init往来款,'其他收入' init其他收入)
	            ) actRec     
	union all            
	select actRec.* from (
	          select d.fname_l2 projectname,b.fname_l2 name,nvl(a.FBillAmt,0) ACTRECAMT --c.fname_l2 company
	            from T_NT_ReceivableBill a
	            left join T_CAS_FeeType b on b.fid = a.CFSFLBID
	            --left join  T_ORG_Company c on c.fid = a.FCompanyID
	            left join T_BD_Project d on d.fid = a.FProjectID
	            where a.FBillState = 4 --收款 条件2.3
	            and a.FCompanyID = baseUnitID
	            and TO_CHAR(A.FTakeDate, 'YYYY-MM-DD') < startDate-- endDate
		  				and TO_CHAR(a.FExpiredDate, 'YYYY-MM-DD') >= startDate -- startDate
		  				--and TO_CHAR(a.FExpiredDate, 'YYYY-MM-DD') <= endDate-- endDate
	          )
	            pivot (
	            SUM(ACTRECAMT) for name in ('工程款' init工程款,'往来款' init往来款,'其他收入' init其他收入)
	            ) actRec                    
) init group by projectname        
) init on init.projectname = pro.projectname
   
left join T_BD_Project dbpro on dbpro.fid = pro.FProjectID
left join T_ORG_Company org on org.fid = dbpro.FCompanyID
    --where FProjectID = 'mbUAAACu+una3gXu'
where pro.FCompanyID = baseUnitID   ;

end if;

--计算期末余额

update T_BE_BEReceivableSummaryTemp set
COLUMN22 = (COLUMN3 + COLUMN7 ) -  (COLUMN11 + COLUMN12 + COLUMN13 + COLUMN14 + COLUMN15 + COLUMN16 + COLUMN17 ) ,--D1=A1+B1-C1-C2-C3-C4-C5-C6-C7
COLUMN23 = (COLUMN4 + COLUMN8) - COLUMN18 ,--D2=A2+B2-C8 
COLUMN24 = (COLUMN5 + COLUMN9) - COLUMN19 ,--D3=A3+B3-C9 
COLUMN25 = 0 - COLUMN20--D4=-C10
;
update T_BE_BEReceivableSummaryTemp set COLUMN26 = (COLUMN22 + COLUMN23 + COLUMN24 + COLUMN25) ;

commit;
end proc_calcBEReceivableSummary;
/

