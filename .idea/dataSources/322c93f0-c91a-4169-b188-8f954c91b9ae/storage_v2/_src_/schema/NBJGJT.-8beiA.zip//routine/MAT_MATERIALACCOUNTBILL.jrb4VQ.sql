create procedure mat_MaterialAccountBill(
v_projectorg in varchar2 default '' ,
v_costtypeID  in varchar2,
v_contractID  in varchar2,
v_mtbalIDset in varchar2,
v_billtypeInv in varchar2,
v_transtypeAdj in varchar2,
v_billtypeAdj in varchar2 ) is

cursor cc is    select
b.cfmaterialname materialName,b.cfmaterialid materialID,
b.cfunit unit,b.cftaxrate taxRate,sum(b.cfqty) perQty,sum(b.cfamount) perTotamount
from ct_set_mtbalancebill a,ct_set_mtbalancebillentry b
where a.fid=b.fparentid
and a.fid in (select regexp_substr(v_mtbalIDset,'[^,]+',1,rownum)net_code  from dual  connect by rownum <= (length(v_mtbalIDset) - length(REGEXP_REPLACE(v_mtbalIDset, ',','')) + 1))
group by b.cfmaterialname,b.cfmaterialid,b.cfunit,b.cftaxrate
order by b.cfmaterialname;

tt cc%rowtype;
qd_qty number(28,10);--清单数量
qd_price number(28,10);--清单单价
per_qty number(28,10);--本次数量
per_price number(28,10);--本次单价
per_tax number(28,10);--本次税金
per_amount number(28,10);--本次不含税金额
tot_qty number(28,10);--累计数量
tot_amount number(28,10);--累计金额
tot_tax number(28,10);--累计税金
tot_taxInAmount number(28,10);--累计含税金额
rk_qty number(28,10);--累计入库数量
rk_amount number(28,10);--累计入库金额
i integer;

begin
  delete  from MaterialAccount_temp;
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;

  qd_qty:= 0;
  qd_price:= 0;
  per_qty:= nvl(tt.Perqty,0);
  per_price:= 0;
  per_amount:= round(tt.Pertotamount*100/(100+tt.taxrate),3);
  per_tax:= tt.Pertotamount-per_amount;
  tot_qty:= 0;
  tot_amount:= 0;
  tot_tax:= 0;
  tot_taxInAmount:= 0;
  rk_qty:= 0;
  rk_amount:= 0;

  if per_qty>0  then
    per_price:= round(per_amount/per_qty,3);
  end if;


    --项目全供应商累计入库
    select sum(qty),sum(amount) into rk_qty,rk_amount
    from (
         select   sum(ENTRYS.Fqty) qty, sum(ENTRYS.Famount) amount
         from T_EC_MaterialInvBill  PURINWAREHSBILL
         LEFT OUTER JOIN T_EC_MaterialInvBillEntry  ENTRYS  ON PURINWAREHSBILL.FID = ENTRYS.FParentID
         LEFT OUTER JOIN T_EC_TransactionType  TRANSTYPE ON PURINWAREHSBILL.FTransTypeID = TRANSTYPE.FID
         LEFT OUTER JOIN T_EC_BillType  BILLTYPE ON TRANSTYPE.FBillTypeID = BILLTYPE.FID
         where PURINWAREHSBILL.FBillSate = '03'
               and PURINWAREHSBILL.Fprojectorgid = v_projectorg
               and BILLTYPE.FID = v_billtypeInv   --v_billtypeInv
               and ENTRYS.Fmaterialid= tt.Materialid
         union
         select sum(adjENTRYS.Cfqty) qty, sum(adjENTRYS.Cfamount) amount
         from CT_INV_InvAdjust  INVADJUST
         LEFT OUTER JOIN CT_INV_InvAdjustEntry  adjENTRYS ON INVADJUST.FID = adjENTRYS.FParentID
         LEFT OUTER JOIN T_EC_TransactionType  TRANSTYPE ON INVADJUST.CFTransTypeID = TRANSTYPE.FID
         LEFT OUTER JOIN T_EC_BillType  BILLTYPE ON TRANSTYPE.FBillTypeID = BILLTYPE.FID
         where INVADJUST.CFBillSate = '03'
               and INVADJUST.Cfprojectorgid = v_projectorg
               and TRANSTYPE.FID = v_transtypeAdj --v_transtypeAdj
               and BILLTYPE.FID = v_billtypeAdj  --v_billtypeAdj
               and adjENTRYS.Cfmaterialid= tt.Materialid
          )  ;

    --清单
    select count(*) into i
    from CT_SET_ProjCostBugetListBill f,CT_SET_ProjCBLBE g
           where f.fid=g.fparentid
             and f.cfprojectorgid=v_projectorg
             and f.cfcontractcosttype=v_costtypeID
             and g.cfmaterialid=tt.Materialid;

    if i>0 then
    select g.cfqdqty,g.cfqdprice into qd_qty,qd_price
           from CT_SET_ProjCostBugetListBill f,CT_SET_ProjCBLBE g
           where f.fid=g.fparentid
             and f.cfprojectorgid=v_projectorg
             and f.cfcontractcosttype=v_costtypeID
             and g.cfmaterialid=tt.Materialid;
    end if;

    --累计
    select count(*) into i
    from CT_SET_MaterialAccountBill h,CT_SET_MaterialABE j
           where h.fid=j.fparentid
           and h.cfprojectorgid=v_projectorg
           and h.cfcontractid=v_contractID
           and j.cfmaterialid=tt.Materialid
           and h.cfbillstate in ('03','04','05','10');

    if i>0 then
    select sum(j.cfperqty+j.cfinitqty),sum(j.cfperamount+j.cfinitamount),sum(j.cfpertax+j.cfinittax),sum(j.cfpertaxinamount+j.cfinittaxinamount)  into tot_qty,tot_amount,tot_tax,tot_taxInAmount
           from CT_SET_MaterialAccountBill h,CT_SET_MaterialABE j
           where h.fid=j.fparentid
           and h.cfprojectorgid=v_projectorg
           and h.cfcontractid=v_contractID
           and j.cfmaterialid=tt.Materialid
           and h.cfbillstate in ('03','04','05','10')
           group by  j.cfmaterialid;
    end if;


   insert into MaterialAccount_temp(materialid,Unit,Qdqty,Qdprice,Perqty,Perprice,Peramount,Pertax,Pertaxinamount,Totqty,Totamount,Tottax,Tottaxinamount,Matinsum,Matinamountsum)
   values(tt.Materialid,tt.unit,qd_qty,qd_price,per_qty,per_price,per_amount,per_tax,tt.perTotamount,tot_qty+per_qty,tot_amount+per_amount,tot_tax+per_tax,tot_taxInAmount+tt.perTotamount,rk_qty,rk_amount);

  end loop;
  close cc;
end mat_MaterialAccountBill;
/

