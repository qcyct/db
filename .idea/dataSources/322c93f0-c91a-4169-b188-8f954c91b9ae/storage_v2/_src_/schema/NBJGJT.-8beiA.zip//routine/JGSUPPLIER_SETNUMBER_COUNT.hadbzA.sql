create procedure JGSupplier_SetNumber_count(
v_csspgroupID in varchar2 ) is
cursor cc is    select a.fid ,a.fnumber,a.cfsuppliername,a.cfsuppliertypetreeid,a.cfsuppliertypenumber,a.cfsuppliertype from CT_SUP_JGSupplier  a
where a.cfsuppliertypetreeid=v_csspgroupID order by a.cfsuppliertypenumber,a.fnumber;

tt cc%rowtype;
v_seqnum integer;
v_number varchar2(44);
begin
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;

    select b.cfseqnumber+1 into v_seqnum from CT_SPB_JGSupplierCustomerSeq  b  where  b.cfcssgrouptreeid=v_csspgroupID;
    v_number:= lpad(v_seqnum,6,'0');
    
    update CT_SUP_JGSupplier c set c.fnumber=c.cfsuppliertypenumber||'-'||v_number where c.fid=tt.fid;

    update  CT_SPB_JGSupplierCustomerSeq  b set b.cfseqnumber=b.cfseqnumber+1 where  b.cfcssgrouptreeid=v_csspgroupID;
  end loop;
  close cc;
end JGSupplier_SetNumber_count;
/

