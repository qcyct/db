create procedure NkyKCProjectDetail_Main(
v_startdate in varchar2,
v_enddate in varchar2) is
cursor cc is    select c.fname_l2 projectMGType,
a.cfprojectclass  projectClass ,
a.fnumber  proProjectNumber,b.cfmainprojectname mainProjectName,b.cfprovince||b.cfcity projectAddr,
d.cfcustomername customerName,a.cfsignperson signPerson,e.fnumber Contractnumber, e.cfcontractamount Contractamount,
--f.fbizdate  drsDate,f.cftecleader  tecLeader,f.cfregisterperson  registerPerson,  
a.cfworkload workLoad ,a.cfstartdate  startDate,
a.cfenddate  endDate,
a.Cftotticketamount totticketamount,a.Cftotreceiveamount totreceiveamount,a.Cftotpayamount totpayamount,
a.cfcontractnubmerid contractid,a.fid proprojectid,a.cftotothercostamout totothercostamout
from   CT_KC_NkyProProject a 
left outer join ct_kc_nkymainproject b on a.cfmainprojectid=b.fid
left outer join CT_NKY_NkyProjectType c on c.fid=b.cfprojectmgtypeid
left outer join CT_NKY_NkyCustomer d on d.fid=b.cfnkycustomerid
left outer join CT_KC_NkyOwnerContract e on e.fid=a.cfcontractnubmerid
--left outer join CT_KC_DrawingStampManage f on f.cfproprojectnumber=a.fid
where 
a.cfbillstate='03'
--and e.cfbillstate='03'
--and f.cfbillstate='03'
and a.fbizdate>=to_date(v_startdate,'yyyyMMdd')
and a.fbizdate<to_date(v_enddate,'yyyyMMdd')+1
order by b.cfmainprojectname,a.fcreatetime desc;

tt cc%rowtype;
v_drsDate timestamp(6);
v_tecLeader NVARCHAR2(50);
v_registerPerson NVARCHAR2(50);
v_receivePoint NVARCHAR2(1600);

v_seqNum integer;
i  integer;
begin
  DELETE FROM  NkyKCProjectDetail_temp;
  v_seqNum:= 1;
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;
   --业主合同收款节点
   v_receivePoint:='';
   if tt.contractid is not null then
      NkyKCProjectDetail_recPoint(tt.contractid,v_receivePoint);   
   end if;  
   --获取最新的出图章日期
   select count(*) into i from CT_KC_DrawingStampManage f where f.cfproprojectnumber=tt.proprojectid  and f.cfbillstate='03';
   if i>0 then
      select f.fbizdate, nvl(f.cftecleader,''),nvl(f.cfregisterperson,'') into v_drsDate,v_tecLeader,v_registerPerson
          from CT_KC_DrawingStampManage f 
          where f.cfproprojectnumber=tt.proprojectid  and f.cfbillstate='03' and rownum=1 ;
   else
     v_drsDate:=null;
     v_tecLeader:='';
     v_registerPerson:='';
   end if;
   
     
   --提款明细项目
   if tt.projectClass='01' then
     NkyKCProjectDetail_01(tt.Proprojectnumber,v_seqNum,tt.projectmgtype,tt.Projectclass,tt.Mainprojectname,tt.Projectaddr,tt.Customername,tt.Signperson,tt.Contractnumber,
                tt.Contractamount,v_drsDate,v_tecLeader,v_registerPerson,tt.Workload,tt.Startdate,tt.Enddate,tt.totticketamount,tt.totreceiveamount,tt.totpayamount,v_receivePoint,tt.proprojectid,tt.totothercostamout  );
   else
     NkyKCProjectDetail_00(tt.Proprojectnumber,v_seqNum,tt.projectmgtype,tt.Projectclass,tt.Mainprojectname,tt.Projectaddr,tt.Customername,tt.Signperson,tt.Contractnumber,
                tt.Contractamount,v_drsDate,v_tecLeader,v_registerPerson,tt.Workload,tt.Startdate,tt.Enddate,tt.totticketamount,tt.totreceiveamount,tt.totpayamount,v_receivePoint,tt.proprojectid,tt.totothercostamout   );
   end if;
   v_seqNum:=v_seqNum+1;
   

  end loop;
  close cc;

end NkyKCProjectDetail_Main;
/

