create procedure proc_calcBgData 
(
billID in varchar2 default '' ,
projectID in varchar2 default '' ,
proCostStructureID in varchar2 default ''
)
as
begin

--清空缓存表
delete from T_CS_BgDataSchema where fkey = billID and FPROJECTID = projectID  and FPROCOSTSTRUCTUREID = proCostStructureID;

--先用层次查询查出树形结构，要想统计一个节点下的汇总，需要用到connect_by_root，同一个节点下的connect_by_root是一样的，然后再group by。
insert into T_CS_BgDataSchema ( fid,FKEY,FPROJECTID,FPROJECTORGID,FPROCOSTSTRUCTUREID,FProCostAccountID,FNumber,FName,flevel,FISLEAF,FLongNumber,FBgValue,FBizActual,FBgBalance,fbgQty)
with temp as (
  select a.FPROCOSTACCOUNTID,b.fnumber,b.rootid,b.flongnumber,b.fisleaf,nvl(a.FBGVALUE,0) bgvalue,nvl(a.FBIZACTUAL,0) BIZACTUAL,nvl(a.FBGBALANCE,0) BGBALANCE,nvl(a.fbgQty,0) bgQty from t_cs_bgdata a
  
  left join (
      select b.fid,connect_by_root(b.fid) rootid,b.fnumber,b.flongnumber,b.fisleaf
      from T_CS_PROCOSTACCOUNT b 
      left join T_CS_PROCOSTACCOUNT c on c.fid = b.cfparentid
      start with b.FPROJECTID = projectID
      connect by prior b.fid = b.CFPARENTID
      order by b.flongnumber
  )  b on b.fid = a.FPROCOSTACCOUNTID
  where a.FPROJECTID = projectID  
  and a.FPROCOSTSTRUCTUREID = proCostStructureID
  and a.fparentid = billID
  order by b.flongnumber
),temp1 as (select rootid,sum(bgvalue) bgvalue,sum(BIZACTUAL) BIZACTUAL,sum(BGBALANCE) BGBALANCE,sum(bgQty) bgQty from temp where fisleaf <> 0 group by rootid),
temp3 as ( ----加上temp3纯粹是为了阅读方便
  select d.fid,
  cast(lpad(' ', level * 2 - 1) || d.fname_l2 as varchar2(500)) fname,d.fnumber,d.flevel,d.FISLEAF,d.FPROJECTORGID,
  d.flongnumber
  from T_CS_PROCOSTACCOUNT d
  start with d.CFPARENTID is null
  connect by prior d.fid = d.CFPARENTID
)
select newbosid('168E44B9') newid,billID,projectID,t3.FPROJECTORGID,proCostStructureID, t3.fid,t3.fnumber,t3.fname,t3.flevel,t3.FISLEAF,t3.FLongNumber,t1.bgvalue ,t1.BIZACTUAL,t1.BGBALANCE,t1.bgqty
from temp1 t1
left join temp3 t3 on t1.rootid = t3.fid
order by t3.flongnumber
;

--关联更新预算数据，只更新父节点
UPDATE T_CS_BGDATA a
  set  (FBGVALUE,FBIZACTUAL,FBGBALANCE,fbgQty) = 
      (select b.FBGVALUE,b.FBIZACTUAL,b.FBGBALANCE,b.fbgQty
        from T_CS_BgDataSchema b
        where b.FPROCOSTACCOUNTID = a.FPROCOSTACCOUNTID)
  where exists (select 1
    from T_CS_BgDataSchema b
    where b.FPROCOSTACCOUNTID = a.FPROCOSTACCOUNTID and b.fisleaf=0
  )
  and a.FPROJECTID = projectID
  and a.FPROCOSTSTRUCTUREID = proCostStructureID
  and a.FPARENTID = billID
  ;
--清空缓存表
delete from T_CS_BgDataSchema where fkey = billID and FPROJECTID = projectID  and FPROCOSTSTRUCTUREID = proCostStructureID;
commit;
end proc_calcBgData;
/

