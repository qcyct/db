create procedure MaterialStock_in(
v_projectorg in varchar2 default '' ,
v_fid in varchar2,
v_creatorid in varchar2) is
cursor cc is   select a.fid sourcebillid ,b.fid sourceentryid,a.fnumber billnumber,a.fname billname, b.fmaterialid  materialid,b.fqty qty,b.fprice price,b.famount amount,a.fbizdate bizdate
from t_Ec_Materialinvbillentry b,t_Ec_Materialinvbill  a
where a.fid=b.fparentid  and b.fparentid=v_fid;--根据入库单ID 获取分录明细

tt cc%rowtype;
v_count integer;
v_msfid varchar2(44);
v_msqty number(28,10);--库存数量
v_totqty number(28,10);
--v_msprice number(28,10);--库存单价
v_totrice number(28,10);
v_msamount number(28,10);--库存金额
v_totamount number(28,10);
v_qtysum number(28,10);--累计入库数量
v_pricesum number(28,10);--累计入库均价
v_amountsum number(28,10);--累计入库金额

begin
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;

  v_totrice:=0;

  --判断该物料是否已存在
  select count(c.fid) into v_count from CT_INV_MaterialStock c where c.cfprojectorgid=v_projectorg and c.cfmaterialid=tt.materialid  ;
  if v_count=1  then --存在：更新 表头
     select c.fid ,c.Cfinventoryqty,c.Cfinventoryamount into v_msfid,v_msqty,v_msamount  from CT_INV_MaterialStock c where c.cfprojectorgid=v_projectorg and c.cfmaterialid=tt.materialid  ;
     v_totqty:=v_msqty+tt.qty;
     v_totamount:=v_msamount+tt.amount;
     v_totqty:=nvl(v_totqty,0);
     v_totamount:=nvl(v_totamount,0);
     if v_totqty>0 then
       v_totrice:=round(v_totamount/v_totqty,6);
     else
       v_totrice:= 0;
     end if;
     update  CT_INV_MaterialStock c set c.Cfinventoryqty=v_totqty ,c.Cfinventoryprice=v_totrice ,c.Cfinventoryamount=v_totamount  where c.fid=v_msfid  ;
  elsif v_count=0 then  -- 不存在：插入 表头
     v_msfid:=newbosid('F5860031');
     insert into CT_INV_MaterialStock(Fid,Fnumber,Cfprojectorgid,Cfmaterialid,Cfinventoryqty,Cfinventoryprice,Cfinventoryamount,Fcreatetime,Fcreatorid,Fbizdate)
                           values (v_msfid,v_msfid,v_projectorg,tt.materialid,tt.qty,tt.price,tt.amount,systimestamp,v_creatorid,sysdate  );
  else
    dbms_output.put_line('不存在该情况');
  end if;

  if v_msfid is not null then  -- 插入分录
     insert into Ct_Inv_Materialstockentry(Fid,Fparentid,Cfsourcebillid,Cfsourceentryid,Cfbillnumber,Cfbillname,Cfbilltype,Cfqty,Cfprice,Cfamount,Cfbizdate)
                   values(newbosid('E5D78EC1'),v_msfid,tt.sourcebillid,tt.sourceentryid,tt.billnumber,tt.billname,'02',tt.qty,tt.price,tt.amount,tt.bizdate );
     -- 计算分录 中的累计入库数据  入库：02
     select sum(d.Cfqty),sum(d.Cfamount) into v_qtysum,v_amountsum  from Ct_Inv_Materialstockentry d where d.fparentid=v_msfid and d.Cfbilltype='02';
         v_qtysum:=nvl(v_qtysum,0);
         v_pricesum:=nvl(v_pricesum,0);
         v_amountsum:=nvl(v_amountsum,0);
         if v_qtysum>0 then
            v_pricesum:=round(v_amountsum/v_qtysum,6);
         end if;
      update  CT_INV_MaterialStock c set c.cfinvqtysum=v_qtysum,c.cfinvpricesum=v_pricesum,c.cfinvamountsum=v_amountsum  where c.fid=v_msfid  ;
  end if;



  end loop;
  close cc;

end MaterialStock_in;
/

