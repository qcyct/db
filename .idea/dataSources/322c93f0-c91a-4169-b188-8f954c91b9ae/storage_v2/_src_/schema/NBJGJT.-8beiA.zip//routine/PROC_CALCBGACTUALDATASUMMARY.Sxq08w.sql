create procedure proc_calcBgActualDataSummary 
(
billID in varchar2 default '' ,
projectID in varchar2 default '' ,
startDate in varchar2 default '',
endDate in varchar2 default ''
)
as
proCostStructureID nvarchar2(44);
CURSOR cur_Stru IS SELECT * FROM T_CS_PROCOSTSTRUCTURE where FPROJECTID = projectID and FISLEAF =1 and CFISENABLED =1;

begin

FOR stru_row IN cur_Stru
loop
 proc_calcBgActualData(billID,projectID,stru_row.fid,startDate,endDate,0);
 --dbms_output.put_line(stru_row.fid); 
end loop;
commit;
end proc_calcBgActualDataSummary;
/

