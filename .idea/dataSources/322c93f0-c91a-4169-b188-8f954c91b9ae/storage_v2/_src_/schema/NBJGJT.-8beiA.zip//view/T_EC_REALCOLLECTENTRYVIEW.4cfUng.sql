create view T_EC_REALCOLLECTENTRYVIEW as
SELECT 1 FISINIT, entry.FBillID, entry.FNumber, entry.FName, entry.FContractAmount, entry.FCostAmount, entry.FProfitAmount, entry.FProfitRate, entry.FDescription, entry.FSeq, entry.FID, entry.FIsItem FROM T_EC_InitCollectEntry ENTRY INNER JOIN T_EC_InItCollectBill BILL ON bill.FID = entry.FBillID INNER JOIN T_EC_SystemControlEntry SCENTTRY ON scEnttry.FProjectID = bill.FProjectID WHERE ((bill.FBillSate = '03' AND scEnttry.FIsCloseInit = 1) AND scEnttry.FType = '60') UNION ALL SELECT 0 FISINIT, entry.FBillID, entry.FNumber, entry.FName, entry.FContractAmount, entry.FCostAmount, entry.FProfitAmount, entry.FProfitRate, entry.FDescription, entry.FSeq, entry.FID, entry.FIsItem FROM T_EC_RealCollectEntry ENTRY
/

