create procedure JGSupllier_Contract  is
cursor cc is     select a.cfmainspid,a.fid jgspid from ct_sup_jgsupplier a
where a.cfbillstate='03'
order by a.fnumber asc;

tt cc%rowtype;


begin
  DELETE FROM  ct_sup_jgsupplierentry;
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;
        
   JGSupllier_Contract_all(tt.cfmainspid,tt.jgspid);

  end loop;
  close cc;

end JGSupllier_Contract;
/

