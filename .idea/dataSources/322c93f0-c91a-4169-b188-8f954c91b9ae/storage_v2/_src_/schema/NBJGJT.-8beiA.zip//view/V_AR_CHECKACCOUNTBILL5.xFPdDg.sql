create view V_AR_CHECKACCOUNTBILL5 as
SELECT bill.fbilldate FBILLDATE, bill.fcompanyid FCOMPANYID, bill.fasstacttypeid FASSTACTTYPEID, bill.fasstactid FASSTACTID, bill.fcurrencyid FCURRENCYID, bill.fpersonid FPERSONID, bill.fadminorgunitid FADMINORGUNITID, billentry.fid FENTRYID, 1 FDIRECTION, billentry.FRecievePayAmount FDAMOUNT, billentry.FRecievePayAmountLocal FDAMOUNTLOCAL, billentry.FRecievePayAmount FCAMOUNT, billentry.FRecievePayAmountLocal FCAMOUNTLOCAL FROM t_ar_otherbill BILL INNER JOIN t_ar_otherbillentry BILLENTRY ON bill.fid = billentry.fparentid WHERE ((bill.ffivouchered = 1 AND bill.fistransbill = 0) AND bill.FIsBizBill = 1)
/

