create procedure mat_settlesummary_matInAmount(
v_projectorg in varchar2 default '' ,
v_contractID in varchar2,
v_billtypeInv in varchar2,
v_transtypeAdj in varchar2,
v_startperiod in date ,
v_endperiod in date ,
v_matInAmount out NUMBER) as

begin
  v_matInAmount:=0;
  if v_startperiod is null then
     --入库累计
     select sum(amount) into v_matInAmount from (
         select sum(f.famount) amount from T_EC_MaterialInvBill d
         left outer join T_EC_MaterialInvBillEntry f on d.fid=f.fparentid
         left outer join T_EC_TransactionType a on a.fid=d.ftranstypeid
         left outer join T_EC_BillType b on b.fid=a.fbilltypeid
         where d.fcontractid=v_contractID
         and d.fprojectorgid=v_projectorg
         and b.fid=v_billtypeInv
         and d.fbillsate='03'
         and d.fbizdate<v_endperiod
         union all
         select sum(h.cfamount) amount from CT_INV_InvAdjust g
         left outer join CT_INV_InvAdjustEntry h on g.fid= h.fparentid
         where g.cfcontractid=v_contractID
         and g.cfprojectorgid=v_projectorg
         and g.cftranstypeid=v_transtypeAdj
         and g.cfbillsate='03'
         and g.fbizdate<v_endperiod
         );

  else    --当期
      --本期入库
     select sum(amount) into v_matInAmount from (
         select sum(f.famount) amount from T_EC_MaterialInvBill d
         left outer join T_EC_MaterialInvBillEntry f on d.fid=f.fparentid
         left outer join T_EC_TransactionType a on a.fid=d.ftranstypeid
         left outer join T_EC_BillType b on b.fid=a.fbilltypeid
         where d.fcontractid=v_contractID
         and d.fprojectorgid=v_projectorg
         and b.fid=v_billtypeInv
         and d.fbillsate='03'
         and d.fbizdate>=v_startperiod
         and d.fbizdate<v_endperiod
         union all
         select sum(h.cfamount) amount from CT_INV_InvAdjust g
         left outer join CT_INV_InvAdjustEntry h on g.fid= h.fparentid
         where g.cfcontractid=v_contractID
         and g.cfprojectorgid=v_projectorg
         and g.cftranstypeid=v_transtypeAdj
         and g.cfbillsate='03'
         and g.fbizdate>=v_startperiod
         and g.fbizdate<v_endperiod
         );
  end if;
       Exception
         when NO_DATA_FOUND then
            v_matInAmount:= 0;
end mat_settlesummary_matInAmount;
/

