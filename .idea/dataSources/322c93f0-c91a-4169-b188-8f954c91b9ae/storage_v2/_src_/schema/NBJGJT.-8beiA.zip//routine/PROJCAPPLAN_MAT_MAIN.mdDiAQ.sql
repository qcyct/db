create procedure ProjCapPlan_Mat_Main(
v_projectorg in varchar2 default '' ,
v_billtypeInv in varchar2,
v_transtypeAdj in varchar2,
v_startdate in varchar2,
v_enddate in varchar2) is
cursor cc is    select c.fname_l2 contractCostType,a.fpartbid supplierID,b.fname_l2 supplierName, a.fid contractID,a.fname contractName,a.foriginalamount contractAmount ,a.cfytaxrate taxRate,substr(a.fpaymentterms,0,400) paymentterms
from T_EC_ContractBill a
left outer join T_BD_Supplier b on b.fid=a.fpartbid
left outer join CT_BAS_ContractCostType c on c.fid=a.fcontractcosttypeid
left outer join T_BAS_ContractCostTypeTREE d on d.fid= c.ftreeid
where a.fprojectorgid=v_projectorg
and d.fnumber !='04' --非专业分包拆分合同
and a.fcontractclass='2'-- 合同类型 购销合同
and a.fcontractattribute='0' --合同性质  原始合同
and a.fcontractstatus in ('3','6','10') --合同状态 批准 签订 执行
order by c.fnumber asc;

tt cc%rowtype;
v_paypercent number(28,10);--付款比例
v_startperiod date;
v_endperiod date;
per_matInAmount number(28,10);--本期入库
tot_matInAmount number(28,10);--入库累计
per_matBalAmount number(28,10);--本期对账
tot_matBalAmount number(28,10);--累计对账
tot_InvAmount number(28,10);--累计开票
tot_mabAmount  number(28,10);--累计入账
tot_payAmount  number(28,10);--累计付款
tot_unPayAmount number(28,10);--累计未付
v_seqNum integer;
begin
  DELETE FROM  ProjCapPlan_temp;
  v_seqNum:= 1;
  --插入第一行 类型 1、材料
  insert into ProjCapPlan_temp(contractCostType,Seqnum,Countsign) values ('1.材料',v_seqNum,'c1');
  v_seqNum:=v_seqNum+1;
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;
  per_matInAmount:= 0;--本期入库
  tot_matInAmount:= 0;--入库累计
  per_matBalAmount:= 0;--本期对账
  tot_matBalAmount:= 0;--累计对账
  tot_InvAmount:=0;--累计开票
  tot_mabAmount:=0;--累计入账
  tot_payAmount:=0;--累计付款
  tot_unPayAmount:=0;--累计未付

  if v_startdate is not null then
    v_startperiod := to_date(v_startdate,'yyyyMMdd');
  end if;
  if v_enddate is not null then
    v_endperiod := to_date(v_enddate,'yyyyMMdd')+1;
  end if;

  --本期入库
   mat_settlesummary_matInAmount(v_projectorg,tt.CONTRACTID,v_billtypeInv,v_transtypeAdj,v_startperiod,v_endperiod,per_matInAmount);
   --入库累计
   mat_settlesummary_matInAmount(v_projectorg,tt.CONTRACTID,v_billtypeInv,v_transtypeAdj,null,v_endperiod,tot_matInAmount);

   --本期对账
   mat_settlesummary_matBalAmount(v_projectorg,tt.CONTRACTID,v_startperiod,v_endperiod,per_matBalAmount);

   --累计对账
   mat_settlesummary_matBalAmount(v_projectorg,tt.CONTRACTID,null,v_endperiod,tot_matBalAmount);

   -- 累计获得发票
   mat_settlesummary_matInvAmount(v_projectorg,tt.CONTRACTID,null,v_endperiod,tot_InvAmount);

   -- 累计入账
   select sum(mab.Cfpertaxinamountsum) into tot_mabAmount  from CT_SET_MaterialAccountBill  mab
          where mab.cfprojectorgid=v_projectorg
          and mab.cfcontractid=tt.contractID
          and mab.cfbillstate in ('03','04','05','10')
          and mab.fbizdate<v_endperiod;
   --累计付款
   mat_settlesummary_payAmount(v_projectorg,tt.CONTRACTID,null,v_endperiod,tot_payAmount);

   --累计未付 = 累计对账-累计已付
    tot_unPayAmount:= tot_matBalAmount-tot_payAmount;

   --付款比例  = 累计付款/累计对账
   if tot_matBalAmount>0 then
      v_paypercent:= round(tot_payAmount/tot_matBalAmount,2);
   else
      v_paypercent:= 0;
   end if;
   per_matInAmount:=nvl(per_matInAmount,0);--本期入库
   tot_matInAmount:= nvl(tot_matInAmount,0);--入库累计
   per_matBalAmount:= nvl(per_matBalAmount,0);--本期对账
   tot_matBalAmount:= nvl(tot_matBalAmount,0);--累计对账
   tot_InvAmount:= nvl(tot_InvAmount,0);--累计开票
   tot_mabAmount:= nvl(tot_mabAmount,0);--累计入账
   tot_payAmount:= nvl(tot_payAmount,0);--累计付款
   tot_unPayAmount:= nvl(tot_unPayAmount,0);--累计未付

   insert into ProjCapPlan_temp(contractCostType,supplierName,supplierID,contractID,contractName,contractAmount,taxRate,permatInAmount,totmatInAmount,permatBalAmount,totmatBalAmount,totInvAmount,totmabAmount,totpayAmount,totunPayAmount,paypercent,paymentterms,Countsign,Seqnum )
   values(tt.contractcosttype,tt.suppliername,tt.supplierid,tt.contractid,tt.contractname,tt.contractamount,tt.taxrate,per_matInAmount,tot_matInAmount,per_matBalAmount,tot_matBalAmount,tot_InvAmount,tot_mabAmount,tot_payAmount,tot_unPayAmount,v_paypercent,tt.paymentterms,'1',v_seqNum);
   v_seqNum:=v_seqNum+1;
   --运输合同 有主合同
   ProjCapPlan_Trans_Materal(v_projectorg,tt.contractID,v_startperiod,v_endperiod);
  end loop;
  close cc;
  --运输合同 无主合同
   ProjCapPlan_Trans_Main(v_projectorg,v_startperiod,v_endperiod);
  --零星材料
   ProjCapPlan_Sporadic(v_projectorg,v_startperiod,v_endperiod);

  select count(*)+1 into v_seqNum FROM  ProjCapPlan_temp;
  --插入最后一行 小计
  insert into ProjCapPlan_temp(contractCostType,contractAmount,permatInAmount,totmatInAmount,permatBalAmount,totmatBalAmount,totInvAmount,totpayAmount,totunPayAmount,Countsign,Seqnum)
              select  '小计', sum(a.contractamount) contractAmount,sum(a.permatinamount) permatInAmount,sum(a.Totmatinamount) totmatInAmount,
                      sum(a.totmatbalamount) permatBalAmount,sum(a.Totmatbalamount) totmatBalAmount,
                      sum(a.Totinvamount) totInvAmount,sum(a.Totpayamount) totpayAmount,sum(a.Totunpayamount) totunPayAmount,'c1',v_seqNum
                      from ProjCapPlan_temp a where a.countsign='1';
end ProjCapPlan_Mat_Main;
/

