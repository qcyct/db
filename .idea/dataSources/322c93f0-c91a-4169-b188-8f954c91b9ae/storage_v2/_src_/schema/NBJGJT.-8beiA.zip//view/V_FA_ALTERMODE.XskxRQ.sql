create view V_FA_ALTERMODE as
SELECT FID, FName_L1, FName_L2, FName_L3, FNumber, FLevel, FLongNumber, FControlUnitID, FParentID FROM T_FA_AlterMode
/

