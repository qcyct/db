create procedure mat_inaccountrpt(
v_projectorg in varchar2 default '' ,
v_billtypeInv in varchar2,
v_billtypeAdj in varchar2,
v_transtypeAdj in varchar2,
v_contract in varchar2,
v_supplier in varchar2,
v_startMatNumber in varchar2,
v_endMatNumber in varchar2,
v_startperiod in NUMBER default 0,
v_endperiod in NUMBER default 0) is

TYPE cc_type is REF CURSOR ;
cc cc_type;
v_matsql varchar2(2000);
v_MATERIALID varchar2(44);
v_MATERIALNUMBER nvarchar2(255);
v_MATERIALNAME nvarchar2(255);
v_MEASUREUNITNAME nvarchar2(255);
v_startqty number(28,10);
v_startamount number(28,10);
v_startprice number(28,10);
v_serino integer;

begin
  delete  from matInAccountRpt_temp;
  v_matsql:= 'SELECT distinct
                     MATERIAL.FID  MATERIALID, MATERIAL.Fnumber  MATERIALNUMBER, MATERIAL.FName_l2  MATERIALNAME, MEASUREUNIT.FName_l2  MEASUREUNITNAME
              FROM T_EC_MaterialInvBill  PURINWAREHSBILL
              LEFT OUTER JOIN T_EC_MaterialInvBillEntry  ENTRYS ON PURINWAREHSBILL.FID = ENTRYS.FParentID
              LEFT OUTER JOIN T_BD_Period  PERIOD ON PURINWAREHSBILL.FPeriodID = PERIOD.FID
              LEFT OUTER JOIN T_ORG_Transport  PROJECTORG ON PURINWAREHSBILL.FProjectOrgID = PROJECTORG.FID
              LEFT OUTER JOIN T_EC_TransactionType  TRANSTYPE ON PURINWAREHSBILL.FTransTypeID = TRANSTYPE.FID
              LEFT OUTER JOIN T_BD_MeasureUnit  MEASUREUNIT ON ENTRYS.FMeasureUnitID = MEASUREUNIT.FID
              LEFT OUTER JOIN T_EC_ResourceItem  MATERIAL ON ENTRYS.FMaterialID = MATERIAL.FID
              LEFT OUTER JOIN T_EC_BillType  BILLTYPE ON TRANSTYPE.FBillTypeID = BILLTYPE.FID
              WHERE PURINWAREHSBILL.FBillSate = 03  and PURINWAREHSBILL.Fprojectorgid = '''||v_projectorg||'''' ;
  v_matsql:= v_matsql||'and BILLTYPE.FID = '''||v_billtypeInv||'''';
  if v_contract is not null then
     v_matsql:= v_matsql||' and PURINWAREHSBILL.Fcontractid ='''||v_contract||'''';
  end if;
  if v_supplier is not null then
     v_matsql:= v_matsql||' and PURINWAREHSBILL.FProviderID ='''||v_supplier||'''';
  end if;
  if v_startMatNumber is not null then
     v_matsql:= v_matsql||' and MATERIAL.Fnumber>='''||v_startMatNumber||'''';
  end if;
  if v_endMatNumber is not null then
     v_matsql:= v_matsql||' and MATERIAL.Fnumber<='''||v_endMatNumber||'''';
  end if;
  v_matsql:= v_matsql||' ORDER BY MATERIALNUMBER ASC';
  v_serino:=0;
  open cc for v_matsql;
  loop
  fetch cc into v_MATERIALID,v_MATERIALNUMBER,v_MATERIALNAME,v_MEASUREUNITNAME;
  exit when cc% notfound;
   --插入物料期初数
       mat_inaccountrpt_startAmount(v_projectorg,v_billtypeInv,v_billtypeAdj,v_transtypeAdj,v_contract,v_supplier,v_startperiod,v_MATERIALID,v_startqty,v_startprice ,v_startamount);
       insert into matInAccountRpt_temp(serino,MATERIALID,MATERIALNUMBER,Materialname,Measureunitname,Periodnumber,Entrysqty,Entrysprice,Entrysamount)
       values (v_serino,v_MATERIALID,v_MATERIALNUMBER,v_MATERIALNAME,v_MEASUREUNITNAME,'期初数',v_startqty,v_startprice,v_startamount);
       v_serino:=v_serino+1;
   --插入本期合计+期末合计
       mat_inaccountrpt_perAmount(v_projectorg,v_billtypeInv,v_billtypeAdj,v_transtypeAdj,v_contract,v_supplier,v_startperiod,v_endperiod,v_MATERIALID,v_MATERIALNUMBER,v_MATERIALNAME,v_MEASUREUNITNAME,v_startqty ,v_startamount,v_serino);
  end loop;
  close cc;
end mat_inaccountrpt;
/

