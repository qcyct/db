create view V_FA_CAT as
SELECT FID, FName_L1, FName_L2, FName_L3, FNumber, FControlUnitID, FLongNumber, FLevel, FParentID FROM T_FA_Cat
/

