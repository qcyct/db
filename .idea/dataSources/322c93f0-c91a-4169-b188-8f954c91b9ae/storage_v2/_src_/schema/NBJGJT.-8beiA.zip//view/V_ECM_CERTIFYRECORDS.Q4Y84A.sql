create view V_ECM_CERTIFYRECORDS as
select FCertifyID,COUNT(counts) counts from 
(

SELECT FCertifyID, COUNT(fid) counts FROM CT_ECM_ConstructingBillEntry group by FCertifyID
union all
SELECT FCertifyID, COUNT(fid) counts FROM CT_ECM_CertifyReturnBillEntry  group by FCertifyID
union all
SELECT FCertifyID,  COUNT(fid) counts FROM T_ECM_CertifyReqBillEntry  group by FCertifyID
union all
SELECT FCertifyID,  COUNT(fid) counts FROM CT_ECM_CertifyChangeBillEntry  group by FCertifyID
union all
SELECT FCertifyID, COUNT(fid) counts FROM CT_ECM_ContinueEduBillEntry  group by FCertifyID
) CertifyRecords 
group by FCertifyID
/

