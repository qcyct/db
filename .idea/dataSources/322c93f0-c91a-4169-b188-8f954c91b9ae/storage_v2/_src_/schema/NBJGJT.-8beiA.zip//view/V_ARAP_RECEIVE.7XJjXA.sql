create view V_ARAP_RECEIVE as
SELECT FID, FNumber, FSourceType, fcompanyid, FPayerID, FPayerTypeID, FCurrencyID, FAuditorID, FAmount FENTRYAMOUNT, FLocalAmount FAMTLOCAL, FBizDate FENTRYDATE FROM T_CAS_ReceivingBill WHERE (((FBillStatus >= 12) AND (FBillStatus < 17)) AND FSourceType = 100)
/

