create view V_ARAP_PAYMENT as
SELECT FID, FNumber, FSourceType, fcompanyid, FPayeeID, FPayeeTypeID, FCurrencyID, FAuditorID, FAmount FENTRYAMOUNT, FLocalAmount FAMTLOCAL, FBizDate FENTRYDATE FROM T_CAS_PaymentBill WHERE (((FBillStatus >= 12) AND (FBillStatus < 17)) AND FSourceType = 101)
/

