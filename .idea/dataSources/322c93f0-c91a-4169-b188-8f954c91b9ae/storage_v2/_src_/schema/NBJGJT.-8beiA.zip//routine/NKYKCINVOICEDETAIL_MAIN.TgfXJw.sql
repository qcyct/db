create procedure NkyKCInvoiceDetail_Main(
v_startdate in varchar2,
v_enddate in varchar2) is
cursor cc is    select  f.fname_l2 projectMGType,g.fnumber contractNumber,
g.cfcontractamount contractAmount,g.fbizdate contractSignDate,
c.fnumber proProjectNumber,c.cfprojectclass projectClass,
e.cfmainprojectname mainProjectName,c.cfprovince||c.cfcity projectAddr,
a.cfinvoicetypecode invoiceTypecode,a.cfinvoicenumber invoiceNumber,
a.cfinvoiceamount invoiceAmount,a.cfinvoicedate invoiceDate,a.cfentrytaxrate taxRate,
a.cfinvoicestate invoiceState,d.cfnkycustomername invCustomerName,
b.cfactticketamount actTicketAmount,b.cfperrreceiveamount perReceiveAmount,
b.cfunreceiveamount unReceiveAmount,b.cfreceivedate receiveDate,c.Cftotticketamount totTicketAmount, 
c.Cftotreceiveamount totReceiveAmount, c.Cftotpayamount totPayamount,
c.fid proprojectid,d.cfinvoicetype invoiceType

from CT_KC_InvoiceApplyInvoiceEntry a
left outer join CT_KC_InvoiceApplyEntry b on b.fparentid=a.fparentid 
left outer join ct_kc_nkyproproject c on c.fid=b.cfnkyproprojectid
left outer join Ct_Kc_Invoiceapply d on d.fid=a.fparentid
left outer join ct_kc_nkymainproject e on e.fid=d.cfmainprojectid
left outer join CT_NKY_NkyProjectType f on f.fid=e.cfprojectmgtypeid
left outer join CT_KC_NkyOwnerContract g on g.fid=c.cfcontractnubmerid
where d.cfbillstate='03'
and c.cfbillstate='03'
--and g.cfbillstate='03'
--and g.cfcontractstate!='04'
and a.cfinvoicedate>=to_date(v_startdate,'yyyyMMdd')
and a.cfinvoicedate<to_date(v_enddate,'yyyyMMdd')+1
order by a.cfinvoicedate desc,e.cfmainprojectname,c.cfprojectclass;


tt cc%rowtype;
v_costitem NVARCHAR2(100);
v_itemPayAmountTot NUMERIC(20,2);
v_seqNum integer;

begin
  DELETE FROM  NkyKCInvoiceDetail_temp;
  v_seqNum:= 1;
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;
  
   --已开票的才显示完整提款明细数据
       if  tt.Invoicestate='01' then
         --提款明细项目
   for c_costit  in (select g.fid itemid, g.fname_l2 itemname from CT_NKY_NkyPayItem g order by g.fnumber asc ) loop
       for c_costamount in 
         ( select nvl(sum(p.Cfperpayamount),0) paysum  from CT_KC_NkyKCPayment q,Ct_Kc_Nkykcpaymententry p  where q.fid=p.fparentid  and q.cfbillstate='03'  and q.cfproprojectnumber=tt.proprojectid  and p.cfcostitemid = c_costit.itemid ) loop
        v_costitem:=c_costit.itemname;
        v_itemPayAmountTot:= c_costamount.paysum ;
        insert into NkyKCInvoiceDetail_temp(Seqnum,Projectmgtype,Contractnumber,Contractamount,Contractsigndate,Proprojectnumber,Projectclass,Mainprojectname,Projectaddr,
                    Invoicetypecode,Invoicenumber,Invoiceamount,Invoicedate,taxRate,Invoicestate,Invcustomername,Actticketamount,Perreceiveamount,Unreceiveamount,
                    Receivedate,Totticketamount,Totreceiveamount,Totpayamount,Costitem,Itempayamounttot,Invoicetype )
               values(v_seqNum,tt.Projectmgtype,tt.Contractnumber,tt.Contractamount,tt.Contractsigndate,tt.Proprojectnumber,tt.Projectclass,tt.Mainprojectname,tt.Projectaddr,
               tt.Invoicetypecode,tt.Invoicenumber,tt.Invoiceamount,tt.Invoicedate,tt.Taxrate,tt.Invoicestate,tt.Invcustomername,tt.Actticketamount,tt.Perreceiveamount,tt.Unreceiveamount,
               tt.Receivedate,tt.Totticketamount,tt.Totreceiveamount,tt.Totpayamount,v_costitem,v_itemPayAmountTot,tt.Invoicetype
               );
                                              
       end loop;
   end loop;
       v_seqNum:=v_seqNum+1;
       
       else
         insert into NkyKCInvoiceDetail_temp(Seqnum,Projectmgtype,Contractnumber,Contractamount,Contractsigndate,Proprojectnumber,Projectclass,Mainprojectname,Projectaddr,
                    Invoicetypecode,Invoicenumber,Invoiceamount,Invoicedate,taxRate,Invoicestate,Invcustomername,Actticketamount,Invoicetype )
               values(v_seqNum,tt.Projectmgtype,tt.Contractnumber,tt.Contractamount,tt.Contractsigndate,tt.Proprojectnumber,tt.Projectclass,tt.Mainprojectname,tt.Projectaddr,
               tt.Invoicetypecode,tt.Invoicenumber,tt.Invoiceamount,tt.Invoicedate,tt.Taxrate,tt.Invoicestate,tt.Invcustomername,tt.Actticketamount,tt.Invoicetype
               );
       v_seqNum:=v_seqNum+1;
       end if;
  
  end loop;
  close cc;

end NkyKCInvoiceDetail_Main;
/

