create procedure proc_invperiodclose 
(
  projectorg in varchar2 default '' 
, projectid in varchar2 default '' 
, periodid in varchar2 default '' 
, lastperiodid in varchar2 default '' 
) as 
begin
--入库,根据单据类型为入库的查询对应的事务类型(+=10,-=20,0=30)，再查询单据,根据单据类型来区分，不区别事务类型的库存影响类型，
--如果为+ 增加库存，如果为 - 扣减库存，但是库存依然为入库发生
--先算增加部分，再算扣减部分
DELETE FROM tempTable;--清空缓存表
--tempTable为本期数据
INSERT INTO tempTable (FProviderID,FMATERIALID,FINQTY,FINAMOUNT,FOUTQTY,FOUTAMOUNT) 
--本期发生 SELECT FMaterialID 物料ID, FMATERIALNAME 物料名称,SUM(INQTY) 本期入库数量,SUM(inamount) 本期入库金额,SUM(outqty) 本期出库数量,SUM(outamount) 本期出库金额
SELECT FProviderID,FMaterialID ,SUM(INQTY) INQTY,SUM(inamount) inamount,SUM(outqty) outqty,SUM(outamount) outamount
FROM (
SELECT FProviderID,FMaterialID, FMATERIALNAME,
CASE WHEN billtype='IN' THEN QTY ELSE 0.00 END inqty,
CASE WHEN billtype='IN' THEN amount ELSE 0.00 END inamount,
CASE WHEN billtype='OUT' THEN QTY ELSE 0.00 END outqty,
CASE WHEN billtype='OUT' THEN amount ELSE 0.00 END outamount
 FROM 
(
--本期入库 如果类型：10 表示入库，20表示出库，直接扣减
SELECT 'IN' billtype,A.FProviderID,b.FMaterialID, b.FMaterialName,
sum(CASE WHEN c.FStockType='10' THEN b.FQty ELSE -1*b.FQty END) qty,
sum(CASE WHEN c.FStockType='10' THEN b.FAmount ELSE -1* b.FAmount END) amount 
FROM T_EC_MaterialInvBill  a left join T_EC_MaterialInvBillEntry b on a.fid=b.FParentID
LEFT JOIN T_EC_TransactionType c on c.fid=a.FTransTypeID
LEFT JOIN T_BD_Supplier D ON D.FID=A.FProviderID
WHERE a.FBillSate=03 and FProjectOrgID=projectorg and a.FProjectID=projectid  and a.FPeriodID=periodid
AND FTransTypeID IN (SELECT b.fid FROM T_EC_BillType a left join T_EC_TransactionType b on a.fid=b.FBillTypeID where  a.fisinstore=0 and a.FIsEnabled=1 and b.FIsEnabled=1 and b.FStockType<>'30')
--AND B.FMATERIALID='7xXox99QRP+FntCHqGdMTiMJTxY='
group by A.FProviderID,b.FMaterialID,b.FMaterialName
union
--本期出库
SELECT 'OUT' billtype,A.FProviderID,b.FMaterialID, b.FMaterialName,
sum(CASE WHEN c.FStockType='20' THEN b.FQty ELSE -1*b.FQty END) qty,
sum(CASE WHEN c.FStockType='20' THEN b.FAmount ELSE -1* b.FAmount END) amount 
FROM T_EC_MaterialInvBill  a left join T_EC_MaterialInvBillEntry b on a.fid=b.FParentID
LEFT JOIN T_EC_TransactionType c on c.fid=a.FTransTypeID
LEFT JOIN T_BD_Supplier D ON D.FID=A.FProviderID
WHERE a.FBillSate=03 and FProjectOrgID=projectorg and a.FProjectID=projectid  and a.FPeriodID=periodid
AND FTransTypeID IN (SELECT b.fid FROM T_EC_BillType a left join T_EC_TransactionType b on a.fid=b.FBillTypeID where  a.fisinstore=1 and a.FIsEnabled=1 and b.FIsEnabled=1 and b.FStockType<>'30')
group by A.FProviderID,b.FMaterialID,b.FMaterialName
) T
union

--库存调整单  本期调整 采购入库调整	101  采购出库调整     102
SELECT A.CFSupplierID,b.CFMATERIALID,b.CFMATERIALNAME,
SUM( CASE WHEN C.fnumber = '101' THEN b.CFQTY ELSE 0 END) inqty,
SUM( CASE WHEN C.fnumber = '101' THEN b.CFamount ELSE 0 END) inamount ,
SUM( CASE WHEN C.fnumber = '102' THEN b.CFQTY ELSE 0 END) outqty,
SUM( CASE WHEN C.fnumber = '102' THEN b.CFamount ELSE 0 END) outamount 
FROM CT_INV_InvAdjust A  LEFT JOIN CT_INV_InvAdjustEntry B ON A.FID=B.FPARENTID
LEFT JOIN T_EC_TransactionType C ON A.CFTRANSTYPEID =C.FID
LEFT JOIN T_BD_Supplier D ON D.FID=A.CFSupplierID
where 1=1
 AND a.CFBILLSATE=03 and CFPROJECTORGID=projectorg and a.CFPROJECTID=projectid  and a.CFPERIODID=periodid
group by A.CFSupplierID,b.CFMATERIALID,b.CFMATERIALNAME
) P
group by FProviderID,FMaterialID;

-- tempTable 为本期数据
--数据合并，把数据更新到结账表,本期期初为上期期末 lastperiodid
INSERT INTO t_inv_invperiodclose(fid, FSUPPLIERID,fprojectorgid, fprojectid, fperiodid,fmaterialid,
finbeginqty, finbeginamount, foutbeginqty, foutbeginamount,
finqty, finamount, foutqty, foutamount,
finendqty, finendamount, foutendqty, foutendamount)-- --期末值采用表更新方式

SELECT newbosid('EFC2CA44') fid,T.FProviderID,projectorg, projectid,periodid,a.fid fmaterialid,--关键字段
NVL(c.FINENDQTY,0),NVL(c.FINENDAMOUNT,0),NVL(c.FOUTENDQTY,0),NVL(c.FOUTENDAMOUNT,0),--期初数据（上期期末）
NVL(t.finqty,0),NVL(t.finamount,0),NVL(t.foutqty,0),NVL(t.foutamount,0),0,0,0,0
FROM T_EC_ResourceItem a 
left join tempTable t on a.fid=t.FMaterialID 
left join T_INV_InvPeriodClose c on a.fid=c.FMaterialID AND T.FProviderID=C.FSUPPLIERID AND c.FProjectOrgID=projectorg and c.FProjectID=projectid and c.FPeriodID=lastperiodid--获取期初
where  t.FMaterialID is not null or c.FMaterialID is not null;

--更新期末余额
UPDATE t_inv_invperiodclose 
SET finendqty=FINBEGINQTY+FINQTY,
finendamount=FINBEGINAMOUNT+FINAMOUNT,
foutendqty=FOUTBEGINQTY+FOUTQTY,
foutendamount=FOUTBEGINAMOUNT+FOUTAMOUNT,
FQTY=finendqty-foutendqty,--结余-入库累计-出库累计
FAMOUNT=finendamount-foutendamount--金额结余同理
WHERE FProjectOrgID=projectorg and FProjectID=projectid and FPeriodID=periodid;

--更新期末余额
UPDATE t_inv_invperiodclose 
SET
FQTY=finendqty-foutendqty,--结余-入库累计-出库累计
FAMOUNT=finendamount-foutendamount--金额结余同理
WHERE FProjectOrgID=projectorg and FProjectID=projectid and FPeriodID=periodid;
--清空缓存表
DELETE FROM tempTable;

end proc_invperiodclose;
/

