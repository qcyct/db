create view V_HR_AFFAIRHISTORY as
SELECT NVL(OldAdmin.FLongNumber, '') OLD_LNUM, NVL(NewAdmin.FLongNumber, '') NEW_LNUM, Af.FAffairType, Af.FEffectDate FAFFAIRDATE, Af.FFluctuationTypeID, AF.FPERSONID FROM T_HR_AffairHistory AF LEFT OUTER JOIN T_ORG_Admin NEWADMIN ON Af.FNewDeptID = NewAdmin.FID LEFT OUTER JOIN T_ORG_Admin OLDADMIN ON Af.FOldDeptID = OldAdmin.FID
/

