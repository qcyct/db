create procedure mat_settlesummary_matBalAmount(
v_projectorg in varchar2 default '' ,
v_contractID in varchar2,
v_startperiod in date,
v_endperiod in date,
v_matBalAmount out NUMBER) as
i integer;
begin
  if v_startperiod is null then --累计
      select count(*) into i
      from CT_SET_MTBalanceBill MTBalanceBill
       where
          MTBalanceBill.Cfbillsate in('03','11')
          and MTBalanceBill.Cfprojectorgid= v_projectorg
          and MTBalanceBill.Fbizdate< v_endperiod
          and MTBalanceBill.Cfcontractid= v_contractID ;
      if i>0 then
        select sum(MTBalanceBill.Cfbalamountsum) into v_matBalAmount
        from CT_SET_MTBalanceBill MTBalanceBill
         where
          MTBalanceBill.Cfbillsate in('03','11')
          and MTBalanceBill.Cfprojectorgid= v_projectorg
          and MTBalanceBill.Fbizdate< v_endperiod
          and MTBalanceBill.Cfcontractid= v_contractID
          group by MTBalanceBill.Cfprojectorgid,MTBalanceBill.Cfcontractid;
      end if;

  else    --期间
      select count(*) into i
      from CT_SET_MTBalanceBill MTBalanceBill
       where
          MTBalanceBill.Cfbillsate in('03','11')
          and MTBalanceBill.Cfprojectorgid= v_projectorg
          and MTBalanceBill.Fbizdate>= v_startperiod
          and MTBalanceBill.Fbizdate< v_endperiod
          and MTBalanceBill.Cfcontractid= v_contractID ;
      if i>0 then
        select sum(MTBalanceBill.Cfbalamountsum) into v_matBalAmount
        from CT_SET_MTBalanceBill MTBalanceBill
         where
          MTBalanceBill.Cfbillsate in('03','11')
          and MTBalanceBill.Cfprojectorgid= v_projectorg
          and MTBalanceBill.Fbizdate>= v_startperiod
          and MTBalanceBill.Fbizdate< v_endperiod
          and MTBalanceBill.Cfcontractid= v_contractID
          group by MTBalanceBill.Cfprojectorgid,MTBalanceBill.Cfcontractid;
      end if;
  end if;

end mat_settlesummary_matBalAmount;
/

