create procedure ProjCapPlan_SUB_Rent(
v_projectorg in varchar2 default '' ,
v_startperiod in date,
v_endperiod in date) is
cursor cc is   select c.fname_l2 contractCostType,a.cfsupplierid supplierID,b.fname_l2 supplierName,a.fid contractID,a.cfname contractName,a.cforiginalamount contractAmount,a.cftaxrate taxRate,substr(a.cfpaymentterms,0,400) paymentterms
from CT_LB_LeaseContractBill a
left outer join T_BD_Supplier b on b.fid=a.cfsupplierid
left outer join CT_BAS_ContractCostType c on c.fid=a.cfcontractcosttype
left outer join T_BAS_ContractCostTypeTREE d on d.fid= c.ftreeid
where a.cfprojectorgid=v_projectorg
and d.fnumber ='04' --专业分包拆分合同 设备租赁拆分
and a.cfcontractattribute='0' -- 原始合同
and a.cfcontractstatus in ('3','6','7','10')
order by c.fnumber asc;

tt cc%rowtype;
v_paypercent number(28,10);--付款比例
per_matBalAmount number(28,10);--本期结算
tot_matBalAmount number(28,10);--累计结算
tot_payAmount  number(28,10);--累计付款
tot_unPayAmount number(28,10);--累计未付
v_seqNum integer;

begin
  select count(*)+1 into v_seqNum FROM  ProjCapPlan_temp;
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;

  per_matBalAmount:= 0;--本期结算
  tot_matBalAmount:= 0;--累计结算
  tot_payAmount:=0;--累计付款
  tot_unPayAmount:=0;--累计未付

   --本期结算
   select sum(d.cforiginalamount)  into per_matBalAmount
         from CT_LB_LeaseSettleBill  d
          where d.cfprojectorgid=v_projectorg
          and d.cfcontractid=tt.contractID
          and d.fbizdate>=v_startperiod
          and d.fbizdate <v_endperiod
          and d.cfbillsate in ('03','04','05','06','10');
  per_matBalAmount:= nvl(per_matBalAmount,0);--本期结算
  --累计结算
  select sum(d.cforiginalamount) into tot_matBalAmount
         from CT_LB_LeaseSettleBill  d
          where d.cfprojectorgid=v_projectorg
          and d.cfcontractid=tt.contractID
          and d.fbizdate <v_endperiod
          and d.cfbillsate in ('03','04','05','06','10');
  tot_matBalAmount:= nvl(tot_matBalAmount,0);--累计结算
  --累计付款
  mat_settlesummary_payAmount(v_projectorg,tt.CONTRACTID,null,v_endperiod,tot_payAmount);
    --累计未付 = 累计对账-累计已付
    tot_unPayAmount:= tot_matBalAmount-tot_payAmount;

   --付款比例  = 累计付款/累计对账
   if tot_matBalAmount>0 then
      v_paypercent:= round(tot_payAmount/tot_matBalAmount,2);
   else
      v_paypercent:= 0;
   end if;
   per_matBalAmount:= nvl(per_matBalAmount,0);--本期结算
   tot_matBalAmount:= nvl(tot_matBalAmount,0);--累计结算
   tot_payAmount:= nvl(tot_payAmount,0);--累计付款
   tot_unPayAmount:= nvl(tot_unPayAmount,0);--累计未付

   insert into ProjCapPlan_temp(contractCostType,supplierName,supplierID,contractID,contractName,contractAmount,taxRate,permatBalAmount,totmatBalAmount,totpayAmount,totunPayAmount,paypercent,paymentterms,Countsign,Seqnum )
   values(tt.contractcosttype,tt.suppliername,tt.supplierid,tt.contractid,tt.contractname,tt.contractamount,tt.taxRate,per_matBalAmount,tot_matBalAmount,tot_payAmount,tot_unPayAmount,v_paypercent,tt.paymentterms,'3',v_seqNum);
   v_seqNum:=v_seqNum+1;
  end loop;
  close cc;

end ProjCapPlan_SUB_Rent;
/

