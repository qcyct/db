create procedure mat_settlesummary_matInvAmount(
v_projectorg in varchar2 default '' ,
v_contractID in varchar2,
v_startperiod in date,
v_endperiod in date,
v_matInvAmount out NUMBER) as
i integer;
begin
  --累计获得发票
  if v_startperiod is null then --累计
      select sum(nub) into i
      from
      (select count(*) nub from CT_II_GeneralInvoice GeneralInvoice
       where GeneralInvoice.Cfcontractid=v_contractID
            and GeneralInvoice.Cfprojectorgid=v_projectorg
            and GeneralInvoice.Cfbillsate in ('03','04','05','06','10')
            and GeneralInvoice.Fbizdate<v_endperiod
       union all
       select count(*) nub from CT_II_InvoiceBill InvoiceBill
       where InvoiceBill.Cfcontractid=v_contractID
            and InvoiceBill.Cfprojectorgid=v_projectorg
            and InvoiceBill.Cfbillsate in ('03','04','05','06','10')
            and InvoiceBill.Fbizdate<v_endperiod
      ) ;

      if i>0 then
      select sum(Cftotamount) into v_matInvAmount
      from
      (select sum(GeneralInvoice.Cftotamount) Cftotamount
       from CT_II_GeneralInvoice GeneralInvoice
       where GeneralInvoice.Cfcontractid=v_contractID
            and GeneralInvoice.Cfprojectorgid=v_projectorg
            and GeneralInvoice.Cfbillsate in ('03','04','05','06','10')
            and GeneralInvoice.Fbizdate<v_endperiod
       union all
       select sum(InvoiceBill.Cftotamount) Cftotamount
       from  CT_II_InvoiceBill InvoiceBill
       where InvoiceBill.Cfcontractid=v_contractID
            and InvoiceBill.Cfprojectorgid=v_projectorg
            and InvoiceBill.Cfbillsate in ('03','04','05','06','10')
            and InvoiceBill.Fbizdate<v_endperiod
      )  ;
      end if;

  else    --当期
      select sum(nub) into i
      from
      (select count(*) nub from CT_II_GeneralInvoice GeneralInvoice
       where GeneralInvoice.Cfcontractid=v_contractID
            and GeneralInvoice.Cfprojectorgid=v_projectorg
            and GeneralInvoice.Cfbillsate in ('03','04','05','06','10')
            and GeneralInvoice.Fbizdate<v_endperiod
            and GeneralInvoice.Fbizdate>=v_startperiod
       union all
       select count(*) nub from CT_II_InvoiceBill InvoiceBill
       where InvoiceBill.Cfcontractid=v_contractID
            and InvoiceBill.Cfprojectorgid=v_projectorg
            and InvoiceBill.Cfbillsate in ('03','04','05','06','10')
            and InvoiceBill.Fbizdate<v_endperiod
            and InvoiceBill.Fbizdate>=v_startperiod
      ) ;

      if i>0 then
      select sum(Cftotamount) into v_matInvAmount
      from
      (select sum(GeneralInvoice.Cftotamount) Cftotamount
       from CT_II_GeneralInvoice GeneralInvoice
       where GeneralInvoice.Cfcontractid=v_contractID
            and GeneralInvoice.Cfprojectorgid=v_projectorg
            and GeneralInvoice.Cfbillsate in ('03','04','05','06','10')
            and GeneralInvoice.Fbizdate<v_endperiod
            and GeneralInvoice.Fbizdate>=v_startperiod
       union all
       select sum(InvoiceBill.Cftotamount) Cftotamount
       from  CT_II_InvoiceBill InvoiceBill
       where InvoiceBill.Cfcontractid=v_contractID
            and InvoiceBill.Cfprojectorgid=v_projectorg
            and InvoiceBill.Cfbillsate in ('03','04','05','06','10')
            and InvoiceBill.Fbizdate<v_endperiod
            and InvoiceBill.Fbizdate>=v_startperiod
      )  ;
      end if;
  end if;
end mat_settlesummary_matInvAmount;
/

