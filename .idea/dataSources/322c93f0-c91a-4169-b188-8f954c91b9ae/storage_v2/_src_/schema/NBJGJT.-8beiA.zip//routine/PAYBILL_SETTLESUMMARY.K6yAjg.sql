create procedure paybill_settlesummary(
v_projectorg in varchar2 default '' ,
v_contractID in varchar2,
v_billtypeInv in varchar2,
v_transtypeAdj in varchar2,
v_enddate in varchar2 ,
v_contractType in varchar2 ,
v_matInAmount out NUMBER,
v_matBalAmount out NUMBER,
v_matInvAmount out NUMBER,
v_accountAmount out NUMBER,
v_payAmount out NUMBER,
v_reqConAmt out number) as

i integer;
v_prepay number(28,10);--预付款
v_endperiod date;

begin
  if v_enddate is not null then
    v_endperiod := to_date(v_enddate,'yyyyMMdd')+1;
  end if;

     --入库累计
     v_matInAmount:= 0;
     select sum(amount) into v_matInAmount from (
         select sum(f.famount) amount from T_EC_MaterialInvBill d
         left outer join T_EC_MaterialInvBillEntry f on d.fid=f.fparentid
         left outer join T_EC_TransactionType a on a.fid=d.ftranstypeid
         left outer join T_EC_BillType b on b.fid=a.fbilltypeid
         where d.fcontractid=v_contractID
         and d.fprojectorgid=v_projectorg
         and b.fid=v_billtypeInv
         and d.fbillsate='03'
         and d.fbizdate<v_endperiod
         union all
         select sum(h.cfamount) amount from CT_INV_InvAdjust g
         left outer join CT_INV_InvAdjustEntry h on g.fid= h.fparentid
         where g.cfcontractid=v_contractID
         and g.cfprojectorgid=v_projectorg
         and g.cftranstypeid=v_transtypeAdj
         and g.cfbillsate='03'
         and g.fbizdate<v_endperiod
         );
    v_matInAmount:= nvl(v_matInAmount,0);--入库累计     
    --对账累计
    v_matBalAmount:= 0;
     select count(*) into i
      from CT_SET_MTBalanceBill MTBalanceBill
       where
          MTBalanceBill.Cfbillsate in('03','11')
          and MTBalanceBill.Cfprojectorgid= v_projectorg
          and MTBalanceBill.Fbizdate< v_endperiod
          and MTBalanceBill.Cfcontractid= v_contractID ;
      if i>0 then
        select sum(MTBalanceBill.Cfbalamountsum) into v_matBalAmount
        from CT_SET_MTBalanceBill MTBalanceBill
         where
          MTBalanceBill.Cfbillsate in('03','11')
          and MTBalanceBill.Cfprojectorgid= v_projectorg
          and MTBalanceBill.Fbizdate< v_endperiod
          and MTBalanceBill.Cfcontractid= v_contractID
          group by MTBalanceBill.Cfprojectorgid,MTBalanceBill.Cfcontractid;
      end if;

     --累计开票
     v_matInvAmount:= 0;
     select sum(nub) into i
      from
      (select count(*) nub from CT_II_GeneralInvoice GeneralInvoice
       where GeneralInvoice.Cfcontractid=v_contractID
            and GeneralInvoice.Cfprojectorgid=v_projectorg
            and GeneralInvoice.Cfbillsate in ('03','04','05','06','10')
            and GeneralInvoice.Fbizdate<=v_endperiod
       union all
       select count(*) nub from CT_II_InvoiceBill InvoiceBill
       where InvoiceBill.Cfcontractid=v_contractID
            and InvoiceBill.CFISSPLIT=0
            and InvoiceBill.Cfprojectorgid=v_projectorg
            and InvoiceBill.Cfbillsate in ('03','04','05','06','10')
            and InvoiceBill.cfbillStatus = '0'
            and InvoiceBill.Fbizdate<=v_endperiod
      ) ;

      if i>0 then
      select sum(Cftotamount) into v_matInvAmount
      from
      (select sum(GeneralInvoice.Cftotamount) Cftotamount
       from CT_II_GeneralInvoice GeneralInvoice
       where GeneralInvoice.Cfcontractid=v_contractID
            and GeneralInvoice.Cfprojectorgid=v_projectorg
            and GeneralInvoice.Cfbillsate in ('03','04','05','06','10')
            and GeneralInvoice.Fbizdate<v_endperiod
       union all
       select sum(InvoiceBill.Cftotamount) Cftotamount
       from  CT_II_InvoiceBill InvoiceBill
       where InvoiceBill.Cfcontractid=v_contractID
            and InvoiceBill.Cfprojectorgid=v_projectorg
            and InvoiceBill.Cfbillsate in ('03','04','05','06','10')
            and InvoiceBill.cfbillStatus = '0'
            and InvoiceBill.Fbizdate<v_endperiod
      )  ;
      end if;
      --累计对账审核
      select sum(mab.cfpertaxinamountsum) into v_accountAmount
      from CT_SET_MaterialAccountBill mab
        where 
        mab.cfbillstate='03'
        and mab.cfprojectorgid=v_projectorg
        and mab.cfcontractid=v_contractID
        and mab.fbizdate<v_endperiod;
      v_accountAmount:= nvl(v_accountAmount,0);--累计对账审核     
      --累计付款
      --劳务协议合同预付
      if v_contractType = '5' then
         select  count(*) into i
                from CT_LAB_LabourPrepay lp ,ct_lab_labourprepayentry lpe
                where lp.fid=lpe.fparentid
                and lp.cfbillsate='03'
                and lp.cfprojectorgid = v_projectorg
                and lpe.cfcontractid=  v_contractID
                and lp.fbizdate<v_endperiod ;
         if i>0 then
            select sum(lpe.cfcurramount) into v_prepay
                from CT_LAB_LabourPrepay lp ,ct_lab_labourprepayentry lpe
                where lp.fid=lpe.fparentid
                and lp.cfbillsate='03'
                and lp.cfprojectorgid = v_projectorg
                and lpe.cfcontractid=  v_contractID
                and lp.fbizdate<v_endperiod ;
         end if;
      else
      --其他合同预付款
         select count(*) into i
                from CT_II_ImprestBill impay
                where
                impay.cfbillstate='03'
                and impay.cfprojectorgid= v_projectorg
                and impay.CFCFContractID0 = v_contractID
                and impay.fbizdate<v_endperiod ;
         if i>0 then
            select sum(impay.cfimprestamount) into v_prepay
            from CT_II_ImprestBill impay
            where
            impay.cfbillstate='03'
            and impay.cfprojectorgid= v_projectorg
            and impay.CFCFContractID0 = v_contractID
            and impay.fbizdate<v_endperiod ;
         end if;
      end if;
      v_prepay:= nvl(v_prepay,0);
      select count(*) into i
      from CT_II_InvoicePaymentBill InvoicePaymentBill
      LEFT OUTER JOIN CT_II_InvoicePBI  InvoicePBI ON InvoicePBI.Fparentid = InvoicePaymentBill.Fid
                 where InvoicePaymentBill.Cfprojectorgid=v_projectorg
                 and InvoicePBI.Cfcfcontractid0= v_contractID
                 and InvoicePaymentBill.Cfbillsate in ('03','04','05','06')
                 and InvoicePaymentBill.Fbizdate<v_endperiod ;
      if i>0 then
      select sum(InvoicePBI.Cfcurrpayamount) into v_payAmount
      from CT_II_InvoicePaymentBill InvoicePaymentBill
      LEFT OUTER JOIN CT_II_InvoicePBI  InvoicePBI ON InvoicePBI.Fparentid = InvoicePaymentBill.Fid
                 where InvoicePaymentBill.Cfprojectorgid=v_projectorg
                 and InvoicePBI.Cfcfcontractid0= v_contractID
                 and InvoicePaymentBill.Cfbillsate in ('03','04','05','06')
                 and InvoicePaymentBill.Fbizdate<v_endperiod ;
      end if;
      
      --add contact reqrequest bill amount
      select nvl(sum(amount),0) into v_reqConAmt
      from (select nvl(b.CFReqPayAmount,0) amount from CT_II_InvoicePayRequestBill a 
      left join CT_II_InvoicePRBI b on a.fid=b.fparentid
      where a.CFBillSate>'01' and b.CFCONTRACTID=v_contractID
      union all
      select nvl(a.CFImprestAmount,0) from CT_II_ImprestBill a where a.CFBillState>'01' and a.CFCONTRACTID=v_contractID
      union all
      SELECT nvl(B.CFCurrAmount,0) FROM CT_LAB_LabourPrepay A LEFT JOIN CT_LAB_LabourPrepayEntry B ON A.FID=B.FPARENTID
      WHERE a.CFBillSate>'01' and  b.cfcontractid=v_contractID
      ) panda ;
       
      v_payAmount:= nvl(v_payAmount,0);
      v_payAmount:=v_payAmount+v_prepay;

       Exception
         when NO_DATA_FOUND then
            v_matInAmount:= 0;
            v_matBalAmount:= 0;
            v_matInvAmount:= 0;
            v_matInAmount:= 0;
            v_accountAmount:=0;
            v_payAmount:= 0;
            v_reqConAmt:=0;

end paybill_settlesummary;
/

