create procedure NkyOWContract_updWorkassign (
v_mainprojectid in varchar2 default '',
v_proprojectid in varchar2,
v_confid in varchar2,
v_conname in varchar2,
v_conamount in number) is
cursor cc is    select b.cfcontractnubmerid,b.cfcontractname,b.cfcontractamount,b.fid wafid,b.Cfproprojectnumber ppfid  from ct_kc_workassignment b where b.cfmainprojectid=v_mainprojectid ;

tt cc%rowtype;

begin
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;
  
  --合同中的专业工程不为空时，只更新对应的专业工程
  if v_proprojectid is not null then
     if tt.ppfid=v_proprojectid  then
         --源单据没有合同的才更新
         if tt.cfcontractnubmerid is  null then
             update  ct_kc_workassignment a  set a.cfcontractnubmerid=v_confid , a.cfcontractname=v_conname, a.cfcontractamount=v_conamount
                     where a.fid=tt.wafid;
         end if;  
         --同一个合同则更新名称和金额
         if tt.cfcontractnubmerid = v_confid then
            update  ct_kc_workassignment a  set  a.cfcontractname=v_conname, a.cfcontractamount=v_conamount
                    where a.fid=tt.wafid;
         end if; 
     end if;
  else
          --源单据没有合同的才更新
         if tt.cfcontractnubmerid is  null then
             update  ct_kc_workassignment a  set a.cfcontractnubmerid=v_confid , a.cfcontractname=v_conname, a.cfcontractamount=v_conamount
                     where a.fid=tt.wafid;
         end if;  
         --同一个合同则更新名称和金额
         if tt.cfcontractnubmerid = v_confid then
            update  ct_kc_workassignment a  set  a.cfcontractname=v_conname, a.cfcontractamount=v_conamount
                    where a.fid=tt.wafid;
         end if; 
  
  end if;
  
  
    
    
  end loop;
  close cc;
end NkyOWContract_updWorkassign;
/

