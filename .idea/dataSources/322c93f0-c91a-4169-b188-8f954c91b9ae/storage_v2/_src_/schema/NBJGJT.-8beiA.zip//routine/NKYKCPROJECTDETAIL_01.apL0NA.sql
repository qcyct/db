create procedure NkyKCProjectDetail_01(
v_proprojectnumber in varchar2 default '' ,
v_seqNum in integer,
v_projectmgtype in varchar2,
v_Projectclass in varchar2,
v_Mainprojectname in varchar2,
v_Projectaddr in varchar2,
v_Customername in varchar2,
v_Signperson in varchar2,
v_Contractnumber in varchar2,
v_Contractamount in NUMBER default 0,
v_drsDate in timestamp,
v_tecLeader  in varchar2,
v_registerPerson in varchar2,
v_Workload  in varchar2,
v_Startdate in timestamp,
v_Enddate in timestamp,
v_totticketamount in NUMBER default 0,
v_totreceiveamount in NUMBER default 0,
v_totpayamount in NUMBER default 0,
v_receivePoint in varchar2,
v_proprojectnumberid in varchar2,
v_totOtherCostAmout in NUMBER default 0
) is
cursor cc is    select g.fid itemid, g.fname_l2 itemname from CT_NKY_NkyPayItem g  order by g.fnumber asc ;

tt cc%rowtype;

v_costitem NVARCHAR2(100);
v_itemPayAmountTot NUMERIC(20,2);

begin
  
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;

   --提款明细项目

       for c_costamount in 
         ( select nvl(sum(p.Cfperpayamount),0) paysum  from CT_KC_NkyKCPayment q,Ct_Kc_Nkykcpaymententry p  where q.fid=p.fparentid  and q.cfbillstate='03'  and q.cfproprojectnumber=v_proprojectnumberid  and p.cfcostitemid = tt.itemid ) loop
        v_costitem:=tt.itemname;
        v_itemPayAmountTot:= c_costamount.paysum ;
        
        insert into NkyKCProjectDetail_temp(seqNum,projectMGType,Projectclass,proProjectNumber,Mainprojectname,Projectaddr,Customername,Signperson,Contractnumber,Contractamount,Drsdate,Tecleader,
               Registerperson,Workload,Startdate,Enddate,Totticketamount,Totreceiveamount,Totpayamount,Receivepoint,Costitem,Itempayamounttot,Proprojectnumberid,Totothercostamout)
               values(v_seqNum,v_projectmgtype,v_Projectclass,v_proprojectnumber,v_Mainprojectname,v_Projectaddr,v_Customername,v_Signperson,v_Contractnumber,v_Contractamount,v_drsDate,v_tecLeader,
               v_registerPerson,v_Workload,v_Startdate,v_Enddate,v_totticketamount,v_totreceiveamount,v_totpayamount, v_receivePoint,v_costitem,v_itemPayAmountTot,v_proprojectnumberid,v_totOtherCostAmout);
                                              
       end loop;
 
  end loop;
  close cc;

end NkyKCProjectDetail_01;
/

