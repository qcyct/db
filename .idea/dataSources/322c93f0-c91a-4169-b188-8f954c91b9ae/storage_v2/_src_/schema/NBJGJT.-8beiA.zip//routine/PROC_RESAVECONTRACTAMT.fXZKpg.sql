create PROCEDURE proc_resavecontractamt ( v_contractid IN VARCHAR2 ) AS

    v_payamount         NUMBER(28,10);--已结算金额不含税 
--v_UnPayAmount number(28,10);--未结算金额不含税
    v_paymonth          NUMBER(28,10);--月结累计不含税
    v_paylist           NUMBER(28,10);--清单结算累计不含税
    v_totreqamt         NUMBER(28,10);--累计申请金额（含税）
    v_totreqnontaxamt   NUMBER(28,10);--累计申请金额（不含税）
    v_actreqamount      NUMBER(28,10);--累计付款金额（含税）
    v_actreqnotamt      NUMBER(28,10);--累计付款金额（不含税）
BEGIN
  --通过结算单获取结算信息及未结算信息
    SELECT
        SUM(nvl(payamount,0) ) payamount,
        SUM(nvl(paymonth,0) ) paymonth,
        SUM(nvl(paylist,0) ) paylist
    INTO
        v_payamount,v_paymonth,v_paylist
    FROM
        (
            SELECT
                    CASE
                        WHEN cfsettlementtype = 0 THEN SUM(nvl(cfcurramount,0) )
                        ELSE 0
                    END
                paymonth,--月结
                    CASE
                        WHEN cfsettlementtype = 1 THEN SUM(nvl(cfcurramount,0) )
                        ELSE 0
                    END
                paylist,--清单结算
                SUM(nvl(cfcurramount,0) ) AS payamount --累计结算
            FROM
                ct_lab_laboursettlebill
            WHERE
                    cfbillsate > '02'
                AND
                    cfcontractid = v_contractid
            GROUP BY
                cfsettlementtype
        ) panda;

  --通过付款申请单获取申请信息

    SELECT
        totreqamt,
        totreqnontaxamt
    INTO
        v_totreqamt,v_totreqnontaxamt
    FROM
        (
            SELECT
                SUM(nvl(cfreqamount,0) ) AS totreqamt,--申请金额（含税）
                SUM(nvl(cfcurramount,0) ) AS totreqnontaxamt --申请金额（不含税）
            FROM
                (
                    SELECT
                        SUM(nvl(cfreqamount,0) ) AS cfreqamount,--申请金额（含税）
                        SUM(nvl(cfcurramount,0) ) AS cfcurramount --申请金额（不含税）
                    FROM
                        ct_lab_labourrequestbill
                    WHERE
                            cfbillsate > '02'
                        AND
                            cfcontractid = v_contractid
                    UNION ALL --上查询关联老数据 
                     SELECT
                        SUM(nvl(b.cfreqamount,0) ) AS cfreqamount,--申请金额（含税）
                        SUM(nvl(b.cfcurramount,0) ) AS cfcurramount --申请金额（不含税）
                    FROM
                        ct_lab_labourrequestbill a
                        LEFT JOIN ct_lab_labourrequestbillentry b ON a.fid = b.fparentid
                    WHERE
                            a.cfbillsate > '02'
                        AND
                            b.cfcontractid = v_contractid
                ) dd
        ) panda;

  --通过付款单获取付款金额信息

    SELECT
        SUM(nvl(b.cfcurramount,0) ) actreqamount,
        SUM(nvl(b.cfactreqnotamt,0) ) actreqnotamt
    INTO
        v_actreqamount,v_actreqnotamt
    FROM
        ct_lab_labourprepay a
        LEFT JOIN ct_lab_labourprepayentry b ON a.fid = b.fparentid
    WHERE
            a.cfbillsate > '02'
        AND
            b.cfcontractid = v_contractid;

  --开始更新合同信息

    UPDATE ct_lab_labourcontract
        SET
            cfpayamount = v_payamount,
            cfunpayamount = cforiginalamount - v_payamount,--未结算金额不含税 = 合同总金额（不含税） - 已结算金额不含税
            cfpaymonth = v_paymonth,
            cfpaylist = v_paylist,
            cftotreqamt = v_totreqamt,--累计申请金额（含税）
            cftotreqnontaxamt = v_totreqnontaxamt,--累计申请金额（含税）
            cfactreqamount = v_actreqamount,--累计付款金额（含税）
            cfactreqnotamt = v_actreqnotamt--累计付款金额（不含税）
    WHERE
        fid = v_contractid;

    COMMIT;
END;
/

