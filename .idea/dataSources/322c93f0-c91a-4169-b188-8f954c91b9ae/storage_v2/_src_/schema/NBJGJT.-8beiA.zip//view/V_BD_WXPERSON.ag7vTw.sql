create view V_BD_WXPERSON as
SELECT per.fid as personID,per.FNumber AS userid, per.FName_L2 AS name, per.femail AS email, org.FWXCODE AS dep,org.fname_l2 orgName , pos.fname_l2 AS pos
	, per.FCell AS mobile
	, CASE per.FGender
		WHEN 1 THEN '男'
		WHEN 2 THEN '女'
		ELSE NULL
	END AS gender, per.FIDCardNO AS IDCardNO, bde.FNumber AS perType, bde.FName_l2 AS perTypeName
 ,case to_char(bde.FNumber)  WHEN '001' THEN 'update' WHEN '013' THEN 'update' else 'delete' end as optMethod
 ,emp.fnumber empType ,emp.fname_l2 empTypeName,org.FadminID
FROM T_ORG_ADMIN a
LEFT JOIN T_HR_PersonPosition b ON a.fid = b.FPersonDep 
LEFT JOIN T_org_Position pos ON pos.FID = b.FPrimaryPositionID 
LEFT JOIN T_bd_person per ON b.FPERSONID = per.fid 
LEFT JOIN T_ORG_wxAdmin org ON org.FadminID = pos.FAdminOrgUnitID 
LEFT JOIN T_HR_BDEmployeeType bde ON per.FEmployeeTypeID = bde.FID 
left join T_HR_EmployeeFenLei emp ON bde.FEmployeeFenLeiID = emp.FID 
WHERE org.fwxcode is not null
--and A.FID = 'mbUAAAAcFTzM567U'
/

