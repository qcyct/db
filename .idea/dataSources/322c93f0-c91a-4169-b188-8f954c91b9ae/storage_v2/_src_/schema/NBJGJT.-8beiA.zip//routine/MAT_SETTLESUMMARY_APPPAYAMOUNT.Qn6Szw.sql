create procedure mat_settlesummary_appPayAmount(
v_projectorg in varchar2 default '' ,
v_contractID in varchar2,
v_startperiod in date,
v_endperiod in date,
v_applyPayAmount out NUMBER) as

begin
  v_applyPayAmount:=0;
  if v_startperiod is null then --累计付款申请
     select nvl(sum(amount),0) into v_applyPayAmount
     from (
          select nvl(sum(InvoicePRBI.Cfreqpayamount),0) amount
          from CT_II_InvoicePayRequestBill InvoicePayRequestBill
          LEFT OUTER JOIN CT_II_InvoicePRBI  InvoicePRBI ON InvoicePRBI.Fparentid = InvoicePayRequestBill.Fid
                 where InvoicePayRequestBill.Cfprojectorgid=v_projectorg
                 and InvoicePRBI.Cfcfcontractid0= v_contractID
                 and InvoicePayRequestBill.Cfbillsate in ('03','04','05','06')
                 and InvoicePayRequestBill.Fbizdate<v_endperiod 
          union all           
          select nvl(a.CFImprestAmount,0) amount from CT_II_ImprestBill a 
                 where a.CFBillState>'01' 
                 and a.CFCONTRACTID=v_contractID    
                 and a.fbizdate<v_endperiod  )   
                  ;


  else    --当期
     select nvl(sum(amount),0) into v_applyPayAmount
     from (
          select nvl(sum(InvoicePRBI.Cfreqpayamount),0) amount
          from CT_II_InvoicePayRequestBill InvoicePayRequestBill
          LEFT OUTER JOIN CT_II_InvoicePRBI  InvoicePRBI ON InvoicePRBI.Fparentid = InvoicePayRequestBill.Fid
                 where InvoicePayRequestBill.Cfprojectorgid=v_projectorg
                 and InvoicePRBI.Cfcfcontractid0= v_contractID
                 and InvoicePayRequestBill.Cfbillsate in ('03','04','05','06')
                 and InvoicePayRequestBill.Fbizdate>=v_startperiod
                 and InvoicePayRequestBill.Fbizdate<v_endperiod 
          union all           
          select nvl(a.CFImprestAmount,0) amount from CT_II_ImprestBill a 
                 where a.CFBillState>'01' 
                 and a.CFCONTRACTID=v_contractID  
                 and a.fbizdate>=  v_startperiod
                 and a.fbizdate<v_endperiod  )   
                  ;      
  
      
  end if;
end mat_settlesummary_appPayAmount;
/

