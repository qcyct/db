create procedure proc_calcSupplierConSummary
(
filterType in varchar2 default '0',
baseUnitID in varchar2 default '' ,
startDate in varchar2 default '',
endDate in varchar2 default ''
)
as
begin 
--清空缓存表
delete from T_BE_SupplierConSummaryTemp ;


if filterType = '0' then --根据财务组织过滤项目，再关联初始化数据 

   insert into T_BE_SupplierConSummaryTemp (COLUMN1,COLUMN2,COLUMN3,COLUMN4,COLUMN5,COLUMN6,COLUMN7,COLUMN8,COLUMN9,COLUMN10,COLUMN11,COLUMN12,COLUMN13,COLUMN14,COLUMN15)
   select contractid,组织名称, 项目组织, 供应商名称,TO_CHAR(BIZDATE, 'YYYY-MM-DD'), 合同编号, 合同名称, 合同类型, 合同成本类型, 合同变更后金额, 累计入库, 累计对账, 累计开票, 累计申请 , 累计付款 from v_SupplierConSummaryTemp 
   where COMPANYID = baseUnitID
    and TO_CHAR(BIZDATE, 'YYYY-MM-DD') >= startDate -- startDate
    and TO_CHAR(BIZDATE, 'YYYY-MM-DD') <= endDate-- endDate
;

elsif filterType = '1' then --根据项目组织过滤

    insert into T_BE_SupplierConSummaryTemp (COLUMN1,COLUMN2,COLUMN3,COLUMN4,COLUMN5,COLUMN6,COLUMN7,COLUMN8,COLUMN9,COLUMN10,COLUMN11,COLUMN12,COLUMN13,COLUMN14,COLUMN15)
   select contractid,组织名称, 项目组织, 供应商名称,TO_CHAR(BIZDATE, 'YYYY-MM-DD'), 合同编号, 合同名称, 合同类型, 合同成本类型, 合同变更后金额, 累计入库, 累计对账, 累计开票,  累计申请 , 累计付款 from v_SupplierConSummaryTemp 
    where FProjectOrgID = baseUnitID
    and TO_CHAR(BIZDATE, 'YYYY-MM-DD') >= startDate -- startDate
    and TO_CHAR(BIZDATE, 'YYYY-MM-DD') <= endDate-- endDate
   ;

elsif filterType = '2' then --根据供应商过滤

    insert into T_BE_SupplierConSummaryTemp (COLUMN1,COLUMN2,COLUMN3,COLUMN4,COLUMN5,COLUMN6,COLUMN7,COLUMN8,COLUMN9,COLUMN10,COLUMN11,COLUMN12,COLUMN13,COLUMN14,COLUMN15)
   select contractid,组织名称, 项目组织, 供应商名称,TO_CHAR(BIZDATE, 'YYYY-MM-DD'), 合同编号, 合同名称, 合同类型, 合同成本类型, 合同变更后金额, 累计入库, 累计对账, 累计开票,  累计申请 , 累计付款 from v_SupplierConSummaryTemp 
    where supplierID = baseUnitID
    and TO_CHAR(BIZDATE, 'YYYY-MM-DD') >= startDate -- startDate
    and TO_CHAR(BIZDATE, 'YYYY-MM-DD') <= endDate-- endDate
    ;

end if;

--计算期末余额


commit;
end proc_calcSupplierConSummary;
/

