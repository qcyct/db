create package dbms_java_definers authid definer as

  FUNCTION get_nth_native_compiler_option(n number) return VARCHAR2;


  -- sets a native-compiler option to the specified value for the
  -- given schema
  PROCEDURE set_native_compiler_option_(optionName VARCHAR2,
                                        value VARCHAR2,
                                        owner NUMBER);

  -- decode, into a user-readable format, a persisted native-compiler
  -- option.  This function is not intended to be used by users
  -- directly
  FUNCTION decode_native_compiler_option_(optionName VARCHAR2,
                                          value      VARCHAR2) RETURN VARCHAR2;

  -- unsets a native-compiler option given by the tuple
  --   [optionName, value] for the given schema
  --
  -- if the option given by optionName is not allowed to have
  -- duplicate values, then the value is ignored.
  PROCEDURE unset_native_compiler_option_(optionName VARCHAR2,
                                          value      VARCHAR2,
                                          owner      NUMBER);

  -- compile all methods defined by the class identified by
  -- classname in the supplied schema.
  -- return the number of methods successfully compiled
  --
  -- If the class does not exist in the schema, or the schema does not
  -- exist, an ORA-29532 (Uncaught Java exception) will occur.
  FUNCTION compile_class_(schema    VARCHAR2,
                          classname VARCHAR2) return NUMBER;

  -- compile the method specified by name and Java type signature
  -- defined by the class identified by classname in the supplied
  -- schema.
  -- return the number of methods successfully compiled
  --
  -- If the class does not exist in the schema, or the schema does not
  -- exist, an ORA-29532 (Uncaught Java exception) will occur.
  FUNCTION compile_method_(schema     VARCHAR2,
                           classname  VARCHAR2,
                           methodname VARCHAR2,
                           methodsig  VARCHAR2) return NUMBER;

  -- uncompile all methods defined by the class identified by
  -- classname in the supplied schema.
  --
  -- return the number of methods successfully uncompiled.
  --
  -- If permanentp, then mark these methods as permanently dynamicaly
  -- un-compilable, otherwise, they are eligible for future dynamic
  -- recompilation.
  --
  -- If the class does not exist in the schema, or the schema does not
  -- exist an ORA-29532 (Uncaught Java exception) will occur.
  FUNCTION uncompile_class_(schema    VARCHAR2,
                            classname VARCHAR2,
                            permanentp NUMBER) return NUMBER;

  -- uncompile the method specified by the name and Java type
  -- signature defined by the class identified by classname in the
  -- supplied schema.
  --
  -- return the number of methods successfully uncompiled.
  --
  -- If permanentp, then mark the method as permanently dynamicaly
  -- un-compilable, otherwise, it is eligible for future dynamic
  -- recompilation.
  --
  -- If the class does not exist in the schema, or the schema does not
  -- exist an ORA-29532 (Uncaught Java exception) will occur.
  FUNCTION uncompile_method_(schema     VARCHAR2,
                             classname  VARCHAR2,
                             methodname VARCHAR2,
                             methodsig  VARCHAR2,
                             permanentp NUMBER) return NUMBER;
end;
/

