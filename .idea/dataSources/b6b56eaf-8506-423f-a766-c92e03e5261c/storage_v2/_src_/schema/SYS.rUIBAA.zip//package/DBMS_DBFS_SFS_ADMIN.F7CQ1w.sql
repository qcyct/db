create package dbms_dbfs_sfs_admin
    authid definer
as



    /*
     * Bless the current session user with sufficient _direct_
     * privileges to enable them to use various DBFS API types in their
     * internal tables.
     *
     * This procedure is not meant to be invoked directly, but is a
     * helper function available for use with the
     * "dbms_dbfs_sfs.createFilesystem" method.
     *
     *
     */

    procedure   blessUser(forView in boolean default false);



    /*
     * Helper function for store creation (only for use with
     * dbms_dbfs_sfs.createFilesystem).
     *
     */

    function    defaultTablespace(
        uname       in          varchar2)
            return  varchar2;



    /*
     * Helper function for looking up a store id (only for use with
     * dbms_dbfs_sfs.getStoreId).
     *
     */

    function    getStoreId(
        schema_name in      varchar2,
        tbl_name    in      varchar2)
            return  number;



    /*
     * Helper functions for space usage queries (only for use with
     * dbms_dbfs_sfs.spaceUsage).
     *
     */

    procedure   spaceDependents(
        schema_name in              varchar2,
        tbl_name    in              varchar2,
        potbl_name  in              varchar2,
        dseg        in out nocopy   dbms_dbfs_sfs.dsegments_t);

    procedure   spaceUsage(
        tbs         in out nocopy   dbms_dbfs_content_properties_t,
        schema_name in              varchar2,
        tbl_name    in              varchar2,
        potbl_name  in              varchar2,
        dseg        in out nocopy   dbms_dbfs_sfs.dsegments_t,
        blksize     out             integer,
        tbytes      out             integer,
        ubytes      out             integer,
        fbytes      out             integer,
        do_fast     in              boolean     default false,
        useEstimate in              integer     default 0);

    function    tbsUsage(
        tbs         in              dbms_dbfs_content_properties_t)
            return  integer;



    /*
     * Helper function for space usage queries (only for use with
     * dbms_dbfs_sfs.shrinkFS).
     *
     */

    procedure   lobUsage(
        schema_name in          varchar2,
        tbl_name    in          varchar2,
        part_name   in          varchar2    default null,
        nbytes      out         integer);



    /*
     * Create a POSIX store.
     *
     * Helper function for store creation (only for use with
     * dbms_dbfs_sfs.createFilesystem).
     *
     *
     * Add a newly created POSIX table to the list of known POSIX
     * tables. At this stage, no store is registered to a particular
     * owner as an accessible filesystem (use "registerFilesystem", if
     * needed).
     *
     * The (schema_name, tbl_name) and its identifier (tabid) must both
     * be database-wide unique. If the table uses object-types,
     * "ptbl_name" should be "null", else the name of a valid properties
     * table.
     *
     */

    procedure   createFilesystem(
        tabid       in              number,
        schema_name in              varchar2,
        tbl_name    in              varchar2,
        ptbl_name   in              varchar2,
        version     in              varchar2,
        properties  in              dbms_dbfs_content_properties_t
                                                default null);



    /*
     * Register a POSIX store.
     *
     *
     * Register an already created POSIX store table
     * (dbms_dbfs_sfs.createFilesystem) in schema "schema_name", table
     * "tbl_name", as a new filesystem named "store_name".
     *
     * The new filesystem/store can optionally be volume/snapshot
     * qualified (by default the "main" volume and current snapshot are
     * used).
     *
     * The same table can be registered as different filesystems by the
     * same/different user as long as the "store_name" and (schema_name,
     * tbl_name, volume_name, snapshot_name) tuple are unique per-user.
     *
     */

    procedure   registerFilesystem(
        store_name      in          varchar2,
        schema_name     in          varchar2,
        tbl_name        in          varchar2,
        volume_name     in          varchar2    default 'main',
        snapshot_name   in          varchar2    default null);



    /*
     * Unregister a POSIX store.
     *
     *
     * The store is removed from the metadata tables, unregistered from
     * the DBFS API, but the underlying filesystem itself is otherwise
     * untouched.
     *
     */

    procedure   unregisterFilesystem(
        store       in              varchar2);



    /*
     * Initialize a POSIX store.
     *
     * Helper function for store initialization (only for use with
     * dbms_dbfs_sfs.initFS).
     *
     *
     * Remove all volumes and snapshots associated with a POSIX
     * filesystem table, and update its "formatted" timestamp.
     *
     */

    procedure   initFilesystem(
        schema_name in              varchar2,
        tbl_name    in              varchar2);



    /*
     * Update the properties of a POSIX store.
     *
     * Helper function for store modification (only for use with
     * dbms_dbfs_sfs.{add,delete,set}FSProperties).
     *
     *
     * Update the store-wide properties of a POSIX store.
     *
     */

    procedure   setFSProperties(
        schema_name in              varchar2,
        tbl_name    in              varchar2,
        properties  in              dbms_dbfs_content_properties_t);



    /*
     * Drop a POSIX store.
     *
     * Helper function for store creation (only for use with
     * dbms_dbfs_sfs.dropFilesystem).
     *
     *
     * Remove a POSIX filesystem table from the list of known POSIX
     * filesystem tables.
     *
     * The table underlying the store must not be in use (i.e. all
     * filesystems referring to this table must have been unregistered
     * prior to this call).
     *
     */

    procedure   dropFilesystem(
        schema_name in              varchar2,
        tbl_name    in              varchar2);



    /*
     * Snapshot operations.
     *
     * Helper functions for snapshot operations meant to be invoked only
     * from "dbms_dbfs_sfs".
     *
     */

    procedure   createSnapshot(
        store_name  in              varchar2,
        snap_name   in              varchar2,
        vol_name    in              varchar2    default 'main');

    procedure   revertSnapshot(
        store_name  in              varchar2,
        snap_name   in              varchar2,
        vol_name    in              varchar2    default 'main');

    procedure   dropSnapshot(
        store_name  in              varchar2,
        snap_name   in              varchar2,
        vol_name    in              varchar2    default 'main');



    /*
     * Drop _all_ POSIX filesystem tables.
     *
     * Action to be invoked only during cleanup/downgrade.
     *
     *
     * The procedure executes like a DDL (i.e. auto-commits before and
     * after its execution).
     *
     */

    procedure   drop_all_tables;



    /*
     * Delete orphaned filesystem/table entries.
     *
     * Action to be invoked only during explicit and immediate cleanup
     * (for cases where the user does not want to wait for auto
     * cleanup).
     *
     *
     * The procedure executes like a DDL (i.e. auto-commits before and
     * after its execution).
     *
     */

    procedure   delete_orphans;



    /*
     * Partition the SFS sequence# generator for distributed
     * multi-master environments.
     *
     *
     * The procedure partitions (by regenerating the sequence) for use
     * with "nodes" nodes/databases, where the current node/database has
     * an index of "myid" (in the range [0 .. nodes-1]).
     *
     *
     * A "newstart" value can be specified as the starting value for the
     * sequence and will be used as long as it is larger than the
     * current sequence value.
     *
     * The same value of "newstart" must be specified across the various
     * "nodes" to make sure that the sequence#s generated by each node
     * have no overlap.
     *
     * **NOTE**: do not invoke this procedure unless you know exactly
     * what you are doing.
     *
     *
     * The procedure executes like a DDL (i.e. auto-commits before and
     * after its execution).
     *
     */

    procedure   partition_sequence(
        nodes       in              number,
        myid        in              number,
        newstart    in              number      default null);



    /*
     * Adjust the SFS sequence# cache to allow for higher concurrency
     * and file ingest throughput.
     *
     *
     * The default cache size of "20" is increased to "8192" (or the
     * user-specified value).
     *
     *
     * The procedure executes like a DDL (i.e. auto-commits before and
     * after its execution).
     *
     */

    procedure   recache_sequence(
        newcache    in              number      default 8192);



    /*
     * DBFS export/import procedural actions.
     *
     * For internal use only. See project-5464 for details.
     *
     */

    function    system_info_exp(
        prepost             in          pls_integer,
        connectstring       out nocopy  varchar2,
        version             in          varchar2,
        new_block           out         pls_integer)
            return  varchar2;

    function    schema_info_exp(
        schema              in          varchar2,
        prepost             in          pls_integer,
        isdba               in          pls_integer,
        version             in          varchar2,
        new_block           out         pls_integer)
            return  varchar2;

    function    instance_info_exp(
        name                in          varchar2,
        schema              in          varchar2,
        prepost             in          pls_integer,
        isdba               in          pls_integer,
        version             in          varchar2,
        new_block           out         pls_integer)
            return  varchar2;



    /*
     * DBFS export/import support.
     *
     * A one-time action to register the SFS entities with the
     * procedural action infrastructure.
     *
     * The registrations should normally have already occurred
     * implicitly during catalog initialization; however, invoking this
     * procedure (one or more times) explicitly is harmless.
     *
     *
     * The procedure executes like a DDL (i.e. auto-commits before and
     * after its execution).
     *
     */

    procedure   eximRegisterAll;



    /*
     * DBFS export/import support (helper functions).
     *
     * These functions are _strictly_ for internal use in the DBFS
     * export/import infrastructure. Do not even _think_ about using
     * them explicitly.
     *
     */

    procedure   exim_seq(
        newval              in          number);
    procedure   exim_tab(
        tabid               out         number,
        schema_name         in          varchar2,
        table_name          in          varchar2,
        ptable_name         in          varchar2,
        version#            in          varchar2,
        created             in          number,
        formatted           in          number);
    procedure   exim_tabp(
        tabid               in          number,
        propname            in          varchar2,
        propvalue           in          varchar2,
        typecode            in          number);
    procedure   exim_vol(
        tabid               in          number,
        volid               in          number,
        volname             in          varchar2,
        created             in          number,
        csnap#              in          number,
        dvolid              in          number,
        dsnap#              in          number,
        deleted             in          number);
    procedure   exim_snap(
        tabid               in          number,
        volid               in          number,
        snap#               in          varchar2,
        snapname            in          varchar2,
        created             in          number,
        deleted             in          number);
    procedure   exim_fs(
        tabid               in          number,
        store_owner         in          varchar2,
        store_name          in          varchar2,
        volid               in          number,
        snap#               in          varchar2,
        created             in          number);
    procedure   exim_grants(
        tabid               in          number);
    procedure   exim_attrv(
        tabid               in          number,
        attrv               in          varchar2,
        asof                in          number,
        vol#                in          number,
        goff                in          number);



end;
/

