create type aq$_jms_message         as object
(
  header        aq$_jms_header,
  senderid      varchar2(100),
  message_type  int,
  text_len      int,
  bytes_len     int,
  text_vc       varchar2(4000),
  bytes_raw     raw(2000),
  text_lob      clob,
  bytes_lob     blob,
  STATIC FUNCTION construct ( mtype IN int ) RETURN aq$_jms_message,
  STATIC FUNCTION construct( text_msg IN  aq$_jms_text_message)
  RETURN aq$_jms_message,
  STATIC FUNCTION construct( bytes_msg IN  aq$_jms_bytes_message)
  RETURN aq$_jms_message,
  STATIC FUNCTION construct( stream_msg IN  aq$_jms_stream_message)
  RETURN aq$_jms_message,
  STATIC FUNCTION construct( map_msg IN  aq$_jms_map_message)
  RETURN aq$_jms_message,
  STATIC FUNCTION construct( object_msg IN  aq$_jms_object_message)
  RETURN aq$_jms_message,
  MEMBER FUNCTION cast_to_text_msg RETURN aq$_jms_text_message,
  MEMBER FUNCTION cast_to_bytes_msg RETURN aq$_jms_bytes_message,
  MEMBER FUNCTION cast_to_stream_msg RETURN aq$_jms_stream_message,
  MEMBER FUNCTION cast_to_map_msg RETURN aq$_jms_map_message,
  MEMBER FUNCTION cast_to_object_msg RETURN aq$_jms_object_message,
  MEMBER PROCEDURE set_text ( payload IN VARCHAR2 ),
  MEMBER PROCEDURE set_text ( payload IN CLOB ),
  MEMBER PROCEDURE get_text ( payload OUT VARCHAR2 ),
  MEMBER PROCEDURE get_text ( payload OUT CLOB ),
  MEMBER PROCEDURE set_bytes ( payload IN RAW ),
  MEMBER PROCEDURE set_bytes ( payload IN BLOB ),
  MEMBER PROCEDURE get_bytes ( payload OUT RAW ),
  MEMBER PROCEDURE get_bytes ( payload OUT BLOB ),
  MEMBER PROCEDURE set_replyto (replyto IN      sys.aq$_agent),
  MEMBER PROCEDURE set_type (type       IN      VARCHAR ),
  MEMBER PROCEDURE set_userid (userid   IN      VARCHAR ),
  MEMBER PROCEDURE set_appid (appid     IN      VARCHAR ),
  MEMBER PROCEDURE set_groupid (groupid IN      VARCHAR ),
  MEMBER PROCEDURE set_groupseq (groupseq       IN      int ),
  MEMBER PROCEDURE clear_properties ,
  MEMBER PROCEDURE set_boolean_property (
                property_name   IN      VARCHAR,
                property_value  IN      BOOLEAN ),
  MEMBER PROCEDURE set_byte_property (
                property_name   IN      VARCHAR,
                property_value  IN      int ),
  MEMBER PROCEDURE set_short_property (
                property_name   IN      VARCHAR,
                property_value  IN      int ),
  MEMBER PROCEDURE set_int_property (
                property_name   IN      VARCHAR,
                property_value  IN      int ),
  MEMBER PROCEDURE set_long_property (
                property_name   IN      VARCHAR,
                property_value  IN      NUMBER ),
  MEMBER PROCEDURE set_float_property (
                property_name   IN      VARCHAR,
                property_value  IN      FLOAT ),
  MEMBER PROCEDURE set_double_property (
                property_name   IN      VARCHAR,
                property_value  IN      DOUBLE PRECISION ),
  MEMBER PROCEDURE set_string_property (
                property_name   IN      VARCHAR,
                property_value  IN      VARCHAR ),
  MEMBER FUNCTION get_replyto RETURN sys.aq$_agent,
  MEMBER FUNCTION get_type RETURN VARCHAR,
  MEMBER FUNCTION get_userid RETURN VARCHAR,
  MEMBER FUNCTION get_appid RETURN VARCHAR,
  MEMBER FUNCTION get_groupid RETURN VARCHAR,
  MEMBER FUNCTION get_groupseq RETURN int,
  MEMBER FUNCTION get_boolean_property ( property_name   IN      VARCHAR)
  RETURN   BOOLEAN,
  MEMBER FUNCTION get_byte_property ( property_name   IN      VARCHAR)
  RETURN   int,
  MEMBER FUNCTION get_short_property ( property_name   IN      VARCHAR)
  RETURN   int,
  MEMBER FUNCTION get_int_property ( property_name   IN      VARCHAR)
  RETURN   int,
  MEMBER FUNCTION get_long_property ( property_name   IN      VARCHAR)
  RETURN   NUMBER,
  MEMBER FUNCTION get_float_property ( property_name   IN      VARCHAR)
  RETURN   FLOAT,
  MEMBER FUNCTION get_double_property ( property_name   IN      VARCHAR)
  RETURN   DOUBLE PRECISION,
  MEMBER FUNCTION get_string_property ( property_name   IN      VARCHAR)
  RETURN   VARCHAR
)
/

