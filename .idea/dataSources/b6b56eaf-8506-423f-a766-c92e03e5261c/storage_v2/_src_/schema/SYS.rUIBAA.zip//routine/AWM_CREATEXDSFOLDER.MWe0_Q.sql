create function awm_createxdsfolder(resPath varchar2) return varchar2 is
  v_ret boolean;
  v_retcode varchar2(10);
begin
  v_ret := dbms_xdb.createfolder(resPath);

  if v_ret = true then
    v_retcode := 'GOOD';
  else
    v_retcode := 'BAD';
  end if;

  return v_retcode;

end awm_createxdsfolder;
/

