create PACKAGE dbms_app_cont_prvt AS

 ------------
 --  OVERVIEW
 --
 --  This package allows an application to manage transaction monitoring
 --  and replay for select-only transactions.

 ----------------
 --  INSTALLATION
 --
 --  This package should be installed under SYS schema.
 --
 --  SQL> @dbmsappcont
 --

  ----------------------------
  --  PROCEDURES AND FUNCTIONS
  --

  PROCEDURE monitor_txn;
  -- Enables the monitoring of transactions in the server

  PROCEDURE begin_replay;
  -- Enables the replay mode in the server. While in replay mode, no transactions can
  -- be either started or committed.

  PROCEDURE end_replay;
  -- Disables the replay mode.

END dbms_app_cont_prvt;
/

