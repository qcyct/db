create PACKAGE dbms_feature_usage_report AS

  /********************************************************************
   * FUNCTIONS
   *   display_text, display_html
   *
   * DESCRIPTION
   *   Pipelined functions that displays the DB Feature Report in
   *   either Text or HTML format for the inputted DBID and Version.
   *
   *   For example, to generate a report on the DB Feature Usage
   *   data for the local database ID and Version, the following
   *   statements can be used:
   *
   *     -- display in Text format
   *     select output from table(dbms_feature_usage_report.display_text);
   *
   *     -- display in HTML format
   *     select output from table(dbms_feature_usage_report.display_html);
   *
   * PARAMETERS
   *   l_dbid    - Database ID to display the DB Feature Usage for.
   *               If NULL, then default to the local dbid.
   *   l_version - Version to display the DB Feature Usage for.
   *               If NULL, then default to the current version.
   *   l_options - Report options, currently no options are supported
   ********************************************************************/

  /* Displays the DB Feature Report in Text format */
  FUNCTION display_text(l_dbid    IN NUMBER   DEFAULT NULL,
                        l_version IN VARCHAR2 DEFAULT NULL,
                        l_options IN NUMBER   DEFAULT 0
                       )
  RETURN awrrpt_text_type_table PIPELINED;

  /* Displays the DB Feature Report in HTML format */
  FUNCTION display_html(l_dbid    IN NUMBER   DEFAULT NULL,
                        l_version IN VARCHAR2 DEFAULT NULL,
                        l_options IN NUMBER   DEFAULT 0
                       )
  RETURN awrrpt_html_type_table PIPELINED;

END dbms_feature_usage_report;
/

