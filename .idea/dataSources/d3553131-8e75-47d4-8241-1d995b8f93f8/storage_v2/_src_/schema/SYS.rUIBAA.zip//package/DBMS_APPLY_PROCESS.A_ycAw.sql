create PACKAGE dbms_apply_process wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
12a 103
qdZsHvOr/gpjx6HDxJqFoeunkukwgwL/mJ4VZy8COB56lfv9YrIrOW36yV9t+n60VecmbyCQ
4HyNICB8Jo6O6HulqlnpJ4Cths80Mu5QYbEXESz+62MeZ9EYqflN5RgbV668n6jrSiWs+xbv
cxscJm/CLlAGrRdtPattXYILiAoPk+SNzCfYxk9+WF/QSCfMh/01/yI0kCl+j0byQG9writ5
+tTHVDMNjSjinFRlkd4pOcrDPBaf0Vg0prSWaR8=
/

