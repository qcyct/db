create type dbms_dbfs_hs_item_t
    authid definer
as object (
    storename  varchar2(32),
    storeowner varchar2(32),
    path        varchar2(1024),
    contentfilename   varchar2(1024)
);
/

