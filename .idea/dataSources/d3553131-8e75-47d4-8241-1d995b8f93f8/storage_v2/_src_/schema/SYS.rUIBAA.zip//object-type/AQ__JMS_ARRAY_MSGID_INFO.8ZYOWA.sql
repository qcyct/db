create type aq$_jms_array_msgid_info
                                                                       wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
42 7d
qYa+eAU9tfTW859HL9khQnNQ6HQwg5n0dLhcWlbD9HKXYkquVsXy2F9yYtxyWfRyRwzZwcB0
K6W/m8Ayy8yPJY8JaWmlsp/+9fslnjVK7qtAyexx7Dx0pq8G04I=
/

