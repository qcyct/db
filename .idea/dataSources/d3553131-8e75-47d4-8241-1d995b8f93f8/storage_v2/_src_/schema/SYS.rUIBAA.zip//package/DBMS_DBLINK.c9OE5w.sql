create PACKAGE dbms_dblink AS

 ---- NAME
 --    PROCEDURE upgrade
 --
 -- DESCRIPTION
 --    upgrades all database links, this will simply execute the DDL
 -- as the owner of the database link. This needs to be in the migrate mode
 -- and the current user executing this should be SYSDBA user.
 PROCEDURE upgrade;

END;
/

