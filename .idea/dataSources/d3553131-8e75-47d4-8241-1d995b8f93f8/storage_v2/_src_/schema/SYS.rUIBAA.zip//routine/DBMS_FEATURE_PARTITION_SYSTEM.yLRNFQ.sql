create PROCEDURE dbms_feature_partition_system
      (is_used OUT number, data_ratio OUT number, clob_rest OUT clob)
AS
BEGIN
  -- initialize
  is_used := 0;
  data_ratio := 0;
  clob_rest := NULL;

  FOR crec IN (select num||':'||idx_or_tab||':'||ptype||':'||subptype||':'||pcnt||':'||subpcnt||':'||
                      pcols||':'||subpcols||':'||idx_flags||':'||
                      idx_type||':'||idx_uk||'|' my_string
               from (select * from
                     (select /*+ full(o) */ dense_rank() over
                             (order by  decode(i.bo#,null,p.obj#,i.bo#)) NUM,
                      decode(o.type#,1,'I',2,'T',null) IDX_OR_TAB,
                      is_xml ||
                      decode(p.parttype, 1, case when bitand(p.flags,64)=64 then 'INTERVAL'
                                                 else 'RANGE' end
                                         ,2, 'HASH', 3, 'SYSTEM', 4, 'LIST', 5, 'REF'
                                         ,p.parttype||'-?') ||
                      decode(bitand(p.flags,32),32,' (PARENT)') PTYPE,
                      decode(mod(p.spare2, 256), 0, null, 1, 'RANGE', 2, 'HASH', 3,'SYSTEM'
                                                    , 4, 'LIST', 5, 'REF'
                                                    , p.spare2||'-?') SUBPTYPE,
                      p.partcnt  ||
                      case when bitand(p.flags,64)=64 then '-' || op.xnumpart
                      end  PCNT,
                      case mod(trunc(p.spare2/65536), 65536)
                           when 0 then null
                           else mod(trunc(p.spare2/65536), 65536) ||'-'|| osp.numsubpart end SUBPCNT,
                      p.partkeycols PCOLS,
                      case mod(trunc(p.spare2/256), 256)
                           when 0 then null
                           else mod(trunc(p.spare2/256), 256) end SUBPCOLS,
                      case when bitand(p.flags,1) = 1 then
                                case when bitand(p.flags,2) = 2 then 'LP'
                                      else 'L' end
                           when bitand(p.flags,2) = 2 then 'GP'
                      end IDX_FLAGS,
                      decode(i.type#, 1, 'NORMAL'||
                                     decode(bitand(i.property, 4), 0, '', 4, '/REV'),
                      2, 'BITMAP', 3, 'CLUSTER', 4, 'IOT - TOP',
                      5, 'IOT - NESTED', 6, 'SECONDARY', 7, 'ANSI', 8, 'LOB',
                      9, 'DOMAIN')  ||
                       case when bitand(i.property,16) = 16 then '-FUNC' end IDX_TYPE,
                      decode(i.property, null,null,
                                         decode(bitand(i.property, 1), 0, 'NU',
                                         1, 'U', '?')) IDX_UK
                      from partobj$ p, obj$ o, user$ u, ind$ i,
                           ( select distinct obj#, 'XML-' as is_xml from opqtype$ where type=1) xml,
                           ( select /* NO_MERGE FULL(tsp) FULL(tcp) */ tcp.bo#, count(*) numsubpart
                             from tabsubpart$ tsp, tabcompart$ tcp
                             where tcp.obj# = tsp.pobj#
                             group by tcp.bo#
                             union all
                             select /* NO_MERGE FULL(isp) FULL(icp) */ icp.bo#, count(*) numsubpart
                             from indsubpart$ isp, indcompart$ icp
                             where icp.obj# = isp.pobj#
                             group by icp.bo#) osp,
                           ( select tp.bo#, count(*) xnumpart
                             from tabpart$ tp
                             group by tp.bo#
                             union all
                             select ip.bo#, count(*) xnumpart
                             from indpart$ ip
                             group by ip.bo#) op
                      where o.obj# = i.obj#(+)
                      and   o.owner# = u.user#
                      and   p.obj# = o.obj#
                      and   p.obj# = xml.obj#(+)
                      and   p.obj# = osp.bo#(+)
                      and   p.obj# = op.bo#(+)
                      -- fix bug 3074607 - filter on obj$
                      and o.type# in (1,2,19,20,25,34,35)
                union all
                -- global nonpartitioned indexes on partitioned tables
                select dense_rank() over (order by  decode(i.bo#,null,p.obj#,i.bo#)) NUM,
                       'I' IDX_OR_TAB,
                        null,null,null,null,
                        case cols when 0 then null
                                  else cols end PCOLS,null,
                       'GNP' IDX_FLAGS,
                       decode(i.type#, 1, 'NORMAL'||
                                      decode(bitand(i.property, 4), 0, '', 4, '/REV'),
                                      2, 'BITMAP', 3, 'CLUSTER', 4, 'IOT - TOP',
                                      5, 'IOT - NESTED', 6, 'SECONDARY', 7, 'ANSI', 8, 'LOB',
                                      9, 'DOMAIN') ||
                       case when bitand(i.property,16) = 16 then '-FUNC' end IDX_TYPE,
                       decode(i.property, null,null,
                                          decode(bitand(i.property, 1), 0, 'NU',
                                          1, 'U', '?')) IDX_UK
                from partobj$ p, user$ u, obj$ o, ind$ i
                where p.obj# = i.bo#
                and   o.owner# = u.user#
                and   p.obj# = o.obj#
                and   p.flags =0
                and   bitand(i.property, 2) <>2
                )
                order by num, idx_or_tab desc )) LOOP

     if (is_used = 0) then
       is_used:=1;
     end if;

     clob_rest := clob_rest||crec.my_string;
   end loop;

   if (is_used = 1) then
     select pcnt into data_ratio
     from
     (
       SELECT c1, TRUNC((ratio_to_report(sum_blocks) over())*100,2) pcnt
       FROM
       (
        select decode(p.obj#,null,'REST','PARTTAB') c1, sum(s.blocks) sum_blocks
        from tabpart$ p, seg$ s
        where s.file#=p.file#(+)
        and s.block#=p.block#(+)
        and s.type#=5
        group by  decode(p.obj#,null,'REST','PARTTAB')
        )
      )
      where c1 = 'PARTTAB';
   end if;
end;
/

