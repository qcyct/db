create type aq$_jms_array_error_info
                                                                       wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
86 aa
X56m1OMX6PFhLRNKhCxg7X8Qyhswg5n0dLhcWlbD9HKXYkquVsXy2F+uYsWXlhhyRwzZwcB0
K6W/m8Ayy8yPJY8JaWm4sp6bKBgopSgzdAjS/h2eFjCSAn3KkeTklI+mXNR4tKTRtosEXYru
BJEaOOBwcA76Y97Xpqb4K6ic
/

