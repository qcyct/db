create PACKAGE dbms_cube_util AUTHID CURRENT_USER AS

  ---------------------
  --  OVERVIEW
  --
  --  This package is the interface to cube utility functions
  --
  ---------------------
  --  Visibility
  --   All users
  --

  ---------------------
  --  CONSTANTS

  ---------------------
  --  EXCEPTIONS

  ---------------------
  --  PROCEDURES

  -- Create a report filter
  PROCEDURE create_rpt_filter(p_owner       IN VARCHAR2,
                              p_dimension   IN VARCHAR2,
                              p_rfname      IN VARCHAR2,
                              p_member_list IN VARCHAR2);

  -- Drop a report filter
  PROCEDURE drop_rpt_filter(p_owner       IN VARCHAR2,
                            p_dimension   IN VARCHAR2,
                            p_rfname      IN VARCHAR2);

  -- Drop a branch
  PROCEDURE drop_branch(p_owner       IN VARCHAR2,
                        p_dimension   IN VARCHAR2);

  -- Get HIERARCHY ALL or DEFAULT member for a cube dimension hierarchy
  -- Valid specialMemberTypes:
  -- HIERARCHY_ALL, DEFAULT_FIRST, DEFAULT_LAST or DEFAULT
  -- DEFAULT and DEFAULT_LAST are the same.
  -- When a hierarchy name is not specified the dimension is treated
  -- as a LIST dimension for the purpose of getting a DEFAULT member.
  FUNCTION get_dimension_special_member
    (qualifiedHierarchy IN VARCHAR2, -- "OWNER"."DIMENSION"[."HIERARCHY"]
     specialMemberType  IN VARCHAR2 DEFAULT 'DEFAULT')
    RETURN VARCHAR2;

  -- return extended metadata
  FUNCTION get_ext_metadata(owner          IN VARCHAR2 DEFAULT NULL,
                            dimension_name IN VARCHAR2 DEFAULT NULL)
  return sys.dbms_cube_util_ext_md_t
  pipelined;


END dbms_cube_UTIL;
/

