create package dbms_cube_advise AUTHID CURRENT_USER is
---------------------------------------------------------------------------
--                   PUBLIC GLOBAL VARIABLES, TYPES AND CONSTANTS
---------------------------------------------------------------------------

   -- Advice statement types
   DBMS_COAD_ADVTYP_NN     CONSTANT BINARY_INTEGER := 1; -- NOT NULL
   DBMS_COAD_ADVTYP_PKT    CONSTANT BINARY_INTEGER := 2; -- Primary Key on Tab
   DBMS_COAD_ADVTYP_PKV    CONSTANT BINARY_INTEGER := 3; -- Primary Key on View
   DBMS_COAD_ADVTYP_FKT    CONSTANT BINARY_INTEGER := 4; -- Foriegn Key on Tab
   DBMS_COAD_ADVTYP_FKV    CONSTANT BINARY_INTEGER := 5; -- Foriegn Key on View
   DBMS_COAD_ADVTYP_RELDIM CONSTANT BINARY_INTEGER := 6; -- Relational Dimension
   DBMS_COAD_ADVTYP_MVLOG  CONSTANT BINARY_INTEGER := 7; -- MView Log
   DBMS_COAD_ADVTYP_MVCMP  CONSTANT BINARY_INTEGER := 8; -- MView compile
   -- Default name of constraint exception log table
   DBMS_COAD_EXCEPTLOGTAB VARCHAR2(65) :=
     '"'||sys_context('USERENV', 'SESSION_USER')||'"."EXCEPTIONS"';

   -- Trace diagnostics destinations
   DBMS_COAD_DIAG_NOTRACE CONSTANT BINARY_INTEGER := 0; -- no trace messages
   DBMS_COAD_DIAG_SRVROUT CONSTANT BINARY_INTEGER := 1; -- trace to serveroutput
   DBMS_COAD_DIAG_TRCFILE CONSTANT BINARY_INTEGER := 2; -- trace to tracefile

   -- Trace diagnostics flag
   DBMS_COAD_DIAG BINARY_INTEGER := DBMS_COAD_DIAG_NOTRACE; -- Default no trace

   -- Trace diagnostics log entry types
   DBMS_COAD_DIAG_NOTE      CONSTANT BINARY_INTEGER := 0; -- Note
   DBMS_COAD_DIAG_BACKTRACE CONSTANT BINARY_INTEGER := 1; -- BACKTRACE
   DBMS_COAD_DIAG_CKMVPRIV  CONSTANT BINARY_INTEGER := 2; -- SQLERRM
   DBMS_COAD_DIAG_HANDLED   CONSTANT BINARY_INTEGER := 3; -- ERROR_STACK

   -- Record and ref cursor type for input to table function get_atr_expr_rc()
   TYPE lvlList_r IS RECORD (
     dimOwner   VARCHAR2(30),
     dimName    VARCHAR2(30),
     lvlName    VARCHAR2(30));

   TYPE lvlList_t IS REF CURSOR RETURN lvlList_r;

   -- Record and table type for output from table function get_atr_expr_rc()
   type atrExprList_r is RECORD (
     dimOwner   VARCHAR2(30),
     dimName    VARCHAR2(30),
     lvlName    VARCHAR2(30),
     atrExpr    VARCHAR2(100));

   type atrExprList_t is TABLE of atrExprList_r;

---------------------------------------------------------------------------
--                   PUBLIC PROCEDURES AND FUNCTIONS DECLARATIONS
---------------------------------------------------------------------------


 -------------------------------- mv_cube_advice ---------------------------
 -- NAME:
 --     mv_cube_advice
 --
 -- DESCRIPTION:
 --     This table function generates records that include a clob containing
 --     sql ddl/dml that helps allow the broadest range of query rewrite
 --     transforms possible and mv log based fast refresh for the cube based
 --     MVs
 --
 -- PARAMETERS:
 --     owner         (IN)       - Owner of the cube MV
 --     mvName        (IN)       - Name of cube organized materialized view
 --     reqType       (IN)       - List of advice elements to generate 0-5
 --     validate      (IN)       - 1-validate constraint, 0[DEFAULT]-novalidate
 --     coad_advice_t returning  - Record that includes advice sql statments
 --
 -- REQTYPEs:
 --     0 [DEFAULT] - Generate all advice types that apply
 --     1           - column in-line not null constraints
 --     2           - primary key constraints
 --     3           - foriegn key constraints
 --     4           - relational dimension objects
 --     5           - mv logs, having 'with primary key'
 --
 -- TABLE FUNCTION RECORD FORMAT:
 --     owner       varchar2(30)   - Owner of apiObject
 --     apiObject   varchar2(30)   - Name of top apiObject
 --     sqlObjOwn   varchar2(30)   - Owner of primary subject object of sqlText
 --     sqlObject   varchar2(30)   - Name of  primary subject object of sqlText
 --     adviceType  number(38,0)   - Type of advice statement
 --     disposition varchar2(2000) - Notes of pre-existing conditions
 --     sqlText     clob           - Advice sql statment
 --     dropText    clob           - Anti-sqlText statement
 --
 --     adviceTypes are declared in package dbms_cube_advise_int as follows
 --       1 -- NOT NULL,             DBMS_COAD_ADVTYP_NN
 --       2 -- Primary Key on Tab,   DBMS_COAD_ADVTYP_PKT
 --       3 -- Primary Key on View,  DBMS_COAD_ADVTYP_PKV
 --       4 -- Foriegn Key on Tab,   DBMS_COAD_ADVTYP_FKT
 --       5 -- Foriegn Key on View,  DBMS_COAD_ADVTYP_FKV
 --       6 -- Relational Dimension, DBMS_COAD_ADVTYP_RELDIM
 --       7 -- MView Log,            DBMS_COAD_ADVTYP_MVLOG
 --       8 -- MView compile,        DBMS_COAD_ADVTYP_MVCMP
 --
 -- NOTES:
 --     This function used metadata collected from the MV itself and additional
 --     related metadata defined via the OLAP API.

   function mv_cube_advice
          (
            owner         in     varchar2 DEFAULT USER,
            objName       in     varchar2,
            reqType       in     varchar2 DEFAULT '0',
            validate      in     number   DEFAULT 0
          ) return coad_advice_t pipelined;

   /* Sets dbms_coad_diag level flag. Allows diagnostics messages to go to
    * serveroutput via dbsm_output.
    * 0 - No trace,
    * 1 - Trace     */
   procedure trace
             (
               diagLevel BINARY_INTEGER
             );

   /* Produced dbms_output messages based on msgids shown here  */
   procedure log
             (
               msgid BINARY_INTEGER DEFAULT 0,
               msgtxt varchar2 DEFAULT ''
             );

   /* Set the name of an EXCEPTIONS table. See utlxexcpt.sql */
   procedure set_cns_exception_log
             (
               exceptLogTab varchar2 DEFAULT '"'|| user ||'"."EXCEPTIONS"'
             );

   /* Table function that returns list of attribute expressions for each
    * level when given a cursor of type lvlList_t i.e.dimension levels */
   function get_atr_expr_rc
            (
              lvlList in lvlList_t
            ) return atrExprList_t pipelined;

   /* Returns true if API objName has a colName that matches and is then
    * mdClass. MEASURE, UNIQUEKEYATTRIBTE, or ANY. */
   function is_md_class (
     mdClass  in      BINARY_INTEGER,
     owner    in      varchar2,
     objName  in      varchar2,
     colName  in      varchar2) return BINARY_INTEGER ;

   /* Gets name of table column primary key constraint, if any */
   function get_pk_name (
     tabOwner in      varchar2,
     tabName  in      varchar2,
     colName  in      varchar2) return varchar2;

   /* Gets name of table column foriegn  key constraint, if any */
   function get_fk_name (
     tabOwner in      varchar2,
     tabName  in      varchar2,
     colName  in      varchar2) return varchar2;

   /* Gets conflicting object info for dimension level mappings, if any */
   function get_dimlvl_disposition (
     tabOwner in      varchar2,
     tabName  in      varchar2,
     colName  in      varchar2) return varchar2;

   /* Gets conflicting object info for dimension name, if any */
   function get_dim_disposition (
     dimOwner in      varchar2,
     dimName  in      varchar2) return varchar2;

   /* Gets conflicting object info for hierarchy snowflake  joins, if any */
   function get_dimHierJoin_disposition (
     tabOwner in varchar2,
     tabName  in varchar2,
     colName  in varchar2) return varchar2;

   /* Gets a level name for a given dimension and column alias */
   function get_lvl_name (
     owner    in      varchar2,
     dimName  in      varchar2,
     colName  in      varchar2) return varchar2;

  /* Get count of distinct values in colName */
  function get_colDistinctCount
    (owner   varchar2,
     tabName varchar2,
     colName varchar2) return number;

  /* Get first measure column for given MV column alias. */
  function get_meas_col
    (mvOwner  in varchar2,
     mvName   in varchar2,
     colAlias in varchar2 ) return varchar2;

END dbms_cube_advise; /* package spec */
/

