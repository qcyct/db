create PROCEDURE aps_validate IS
   AWok BOOLEAN;
   OBJok BOOLEAN;
   x NUMBER; -- dummy output spot
   junklob CLOB;
BEGIN

   -- AWs are valid if we can read an option
   BEGIN
     junklob := dbms_aw.INTERP('show SESSCACHE');
     AWok := TRUE;
   EXCEPTION
     WHEN OTHERS THEN
       AWok := FALSE;
   END;

   -- supporting object things
   BEGIN
     SELECT 0 INTO x FROM DBA_OBJECTS
       WHERE STATUS = 'INVALID' AND rownum <=1 AND
         OWNER='SYS' AND OBJECT_NAME IN
        ('OLAP_TABLE', 'OLAPIMPL_T', 'OLAP_SRF_T', 'OLAP_NUMBER_SRF',
         'OLAP_EXPRESSION', 'OLAP_TEXT_SRF', 'OLAP_EXPRESSION_TEXT',
         'OLAP_BOOL_SRF', 'OLAP_EXPRESSION_BOOL');
     -- at least one object is invalid so component is invalid
     OBJok := FALSE;
   EXCEPTION
   WHEN NO_DATA_FOUND THEN
     -- no invalid objects were found so component is valid
     OBJok := TRUE;
   END;

   IF AWok AND OBJok THEN
     dbms_registry.valid('APS');
   ELSE
     dbms_registry.invalid('APS');
   END IF;
  END;
/

