create PACKAGE dbms_aq_exp_zecurity wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
bc df
u3Gxxs76V/ziLKBG3wvPGZzpB54wg/D/vssVfC82afzPladQJeiDtNXgZizYzecRK3Y+FshX
bI8eUs7hg7N61zbDpNHnSvhOTJ/qiIcfOnQHwc3SMB2Ld6uyxYK3DPHvf3DYxandh/f/WQ6j
CZBQezDc07TSXppWbKe0ZgRbUO8Kb0IiCrU3AbmwcWGyCBGF3lDw8KwKLWK6xapZg3e3liCC
Ifg=
/

