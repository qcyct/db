create type aq$_jms_text_message         as object
(
  header    aq$_jms_header,
  text_len  int,
  text_vc   varchar2(4000),
  text_lob  clob,
  STATIC FUNCTION construct RETURN aq$_jms_text_message,
  MEMBER PROCEDURE set_text ( payload IN VARCHAR2 ),
  MEMBER PROCEDURE set_text ( payload IN CLOB ),
  MEMBER PROCEDURE get_text ( payload OUT VARCHAR2 ),
  MEMBER PROCEDURE get_text ( payload OUT CLOB ),
  MEMBER PROCEDURE set_replyto (replyto IN      sys.aq$_agent),
  MEMBER PROCEDURE set_type (type       IN      VARCHAR ),
  MEMBER PROCEDURE set_userid (userid   IN      VARCHAR ),
  MEMBER PROCEDURE set_appid (appid     IN      VARCHAR ),
  MEMBER PROCEDURE set_groupid (groupid IN      VARCHAR ),
  MEMBER PROCEDURE set_groupseq (groupseq       IN      int ),
  MEMBER PROCEDURE clear_properties ,
  MEMBER PROCEDURE set_boolean_property (
                property_name   IN      VARCHAR,
                property_value  IN      BOOLEAN ),
  MEMBER PROCEDURE set_byte_property (
                property_name   IN      VARCHAR,
                property_value  IN      int ),
  MEMBER PROCEDURE set_short_property (
                property_name   IN      VARCHAR,
                property_value  IN      int ),
  MEMBER PROCEDURE set_int_property (
                property_name   IN      VARCHAR,
                property_value  IN      int ),
  MEMBER PROCEDURE set_long_property (
                property_name   IN      VARCHAR,
                property_value  IN      NUMBER ),
  MEMBER PROCEDURE set_float_property (
                property_name   IN      VARCHAR,
                property_value  IN      FLOAT ),
  MEMBER PROCEDURE set_double_property (
                property_name   IN      VARCHAR,
                property_value  IN      DOUBLE PRECISION ),
  MEMBER PROCEDURE set_string_property (
                property_name   IN      VARCHAR,
                property_value  IN      VARCHAR ),
  MEMBER FUNCTION get_replyto RETURN sys.aq$_agent,
  MEMBER FUNCTION get_type RETURN VARCHAR,
  MEMBER FUNCTION get_userid RETURN VARCHAR,
  MEMBER FUNCTION get_appid RETURN VARCHAR,
  MEMBER FUNCTION get_groupid RETURN VARCHAR,
  MEMBER FUNCTION get_groupseq RETURN int,
  MEMBER FUNCTION get_boolean_property ( property_name   IN      VARCHAR)
  RETURN   BOOLEAN,
  MEMBER FUNCTION get_byte_property ( property_name   IN      VARCHAR)
  RETURN   int,
  MEMBER FUNCTION get_short_property ( property_name   IN      VARCHAR)
  RETURN   int,
  MEMBER FUNCTION get_int_property ( property_name   IN      VARCHAR)
  RETURN   int,
  MEMBER FUNCTION get_long_property ( property_name   IN      VARCHAR)
  RETURN   NUMBER,
  MEMBER FUNCTION get_float_property ( property_name   IN      VARCHAR)
  RETURN   FLOAT,
  MEMBER FUNCTION get_double_property ( property_name   IN      VARCHAR)
  RETURN   DOUBLE PRECISION,
  MEMBER FUNCTION get_string_property ( property_name   IN      VARCHAR)
  RETURN   VARCHAR
)
/

