create PACKAGE dbms_frequent_itemset AUTHID CURRENT_USER AS

FUNCTION fi_transactional(
  tranx_cursor          IN  SYS_REFCURSOR,
  support_threshold     IN  NUMBER,
  itemset_length_min    IN  NUMBER,
  itemset_length_max    IN  NUMBER,
  including_items       IN  SYS_REFCURSOR DEFAULT NULL,
  excluding_items       IN  SYS_REFCURSOR DEFAULT NULL)
RETURN SYS.AnyDataSet pipelined parallel_enable using ora_fi_Imp_t;

FUNCTION fi_horizontal(
  tranx_cursor          IN  SYS_REFCURSOR,
  support_threshold     IN  NUMBER,
  itemset_length_min    IN  NUMBER,
  itemset_length_max    IN  NUMBER,
  including_items       IN  SYS_REFCURSOR DEFAULT NULL,
  excluding_items       IN  SYS_REFCURSOR DEFAULT NULL)
RETURN SYS.AnyDataSet pipelined parallel_enable using ora_fi_Imp_t;


END;
/

