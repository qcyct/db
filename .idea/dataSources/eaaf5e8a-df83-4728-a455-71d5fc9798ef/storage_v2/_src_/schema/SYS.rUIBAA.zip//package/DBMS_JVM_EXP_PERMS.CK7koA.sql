create package DBMS_JVM_EXP_PERMS AUTHID CURRENT_USER as
  TYPE temp_rec is record (
       kind        dba_java_policy.kind%TYPE,
       grantee     dba_java_policy.grantee%TYPE,
       type_schema dba_java_policy.type_schema%TYPE,
       type_name   dba_java_policy.type_name%TYPE,
       name        dba_java_policy.name%TYPE,
       action      dba_java_policy.action%TYPE,
       enabled     dba_java_policy.enabled%TYPE
       );

  TYPE temp_java_policy is table of temp_rec;

  function create_exp(objid IN number,
                      version in varchar2,
                      new_block OUT PLS_INTEGER) return varchar2;

  function grant_exp (objid IN NUMBER,
                      isdba IN PLS_INTEGER,
                      grantor OUT VARCHAR2,
                      version IN VARCHAR2,
                      new_block OUT PLS_INTEGER) RETURN varchar2;

  function audit_exp (objid IN NUMBER,
                      version IN VARCHAR2,
                      new_block OUT PLS_INTEGER) RETURN varchar2;

  function drop_exp (objid IN NUMBER,
                     version IN VARCHAR2,
                     new_block OUT PLS_INTEGER) RETURN varchar2;

  function audit_sysprivs_exp (version IN VARCHAR2,
                               new_block OUT PLS_INTEGER ) RETURN varchar2;
  function grant_sysprivs_exp(version IN varchar2,
                              new_block OUT PLS_INTEGER
                             ) return varchar2;
  procedure import_jvm_perms(pcol temp_java_policy);
  function  export_perms(state IN OUT PLS_INTEGER, new_block OUT PLS_INTEGER)
                        return varchar2;
end DBMS_JVM_EXP_PERMS;
/

