create PROCEDURE dbms_feature_qosm
      (is_used OUT number, aux_count OUT number, feature_info OUT clob)
AS

BEGIN
  -- initialize
  feature_info := NULL;
  aux_count := NULL;

  -- get number of performance classes

  select count(*) into is_used from x$kywmpctab
    where kywmpctabsp not like ':%';

  -- if QOSM is used
  if (is_used >= 1) then

    -- number of Performance Classes
    aux_count := is_used;

  end if;
END;
/

