create procedure DBMS_FEATURE_RESOURCE_MANAGER
    (feature_boolean  OUT  NUMBER,
     aux_count        OUT  NUMBER,
     feature_info     OUT  CLOB)
AS
  feature_usage             varchar2(1000);
  non_maint_sql             varchar2(1000);
  non_maint_usage           number;
  non_maint_cpu             number;
  non_maint_other           number;
begin

  -- Initialize all variables

  feature_boolean := 0;
  aux_count       := 0;
  feature_info    := to_clob('Resource Manager usage not detected');

  feature_usage   := NULL;
  non_maint_sql   := NULL;
  non_maint_cpu   := 0;
  non_maint_other := 0;

  -- 'feature_boolean' is set to 1 if Resource Manager was enabled, not
  -- including for maintenance windows.

  non_maint_sql :=
      'select decode(count(*), 0, 0, 1) from v$rsrc_plan_history where ' ||
      'name != ''INTERNAL_PLAN'' and name is not null and ' ||
      '(name != ''DEFAULT_MAINTENANCE_PLAN'' or ' ||
      '  (window_name is null or ' ||
      '   (window_name != ''MONDAY_WINDOW'' and ' ||
      '    window_name != ''TUESDAY_WINDOW'' and ' ||
      '    window_name != ''WEDNESDAY_WINDOW'' and ' ||
      '    window_name != ''THURSDAY_WINDOW'' and ' ||
      '    window_name != ''FRIDAY_WINDOW'' and ' ||
      '    window_name != ''SATURDAY_WINDOW'' and ' ||
      '    window_name != ''SUNDAY_WINDOW''))) ';

  execute immediate
    non_maint_sql
  into feature_boolean;

  -- 'aux_count' is not being used

  -- 'feature_info' is constructed of the following name-value pairs:
  --   Non-Maintenance CPU Management:
  --     This field is set to 1 if Resource Manager was enabled explicitly
  --     and the Resource Plan was managing CPU.
  --   Non-Maintenance Other Management:
  --     This field is set to 1 if Resource Manager was enabled explicitly
  --     and the Resource Plan was NOT managing CPU, i.e. the Resource Plan
  --     was managing idle time, switch time, DOP, etc.

  if feature_boolean > 0
  then
    execute immediate
      non_maint_sql || ' and cpu_managed = ''ON'' '
    into non_maint_cpu;

    execute immediate
      non_maint_sql || ' and cpu_managed = ''OFF'' '
    into non_maint_other;

    feature_usage :=
      'Non-Maintenance CPU Management: ' || non_maint_cpu ||
      ', Non-Maintenance Other Management: ' || non_maint_other;

    feature_info := to_clob(feature_usage);
  end if;

end dbms_feature_resource_manager;
/

