create procedure DBMS_FEATURE_TEST_PROC_3
  ( current_value  OUT  NUMBER)
AS
begin

    /* doesn't matter what I do here as long as the values get
     * returned correctly.
     */
    current_value := 101;
end;
/

