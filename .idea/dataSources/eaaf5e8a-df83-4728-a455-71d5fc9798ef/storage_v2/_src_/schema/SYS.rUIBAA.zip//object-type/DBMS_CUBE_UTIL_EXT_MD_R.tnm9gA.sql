create type dbms_cube_util_ext_md_r
  as object (owner             varchar2(128),
             dimension_name    varchar2(128),
             hierarchy_name    varchar2(128),
             default_member    varchar2(4000),
             depth_count       number,
             depth             number,
             depth_cardinality number)
/

