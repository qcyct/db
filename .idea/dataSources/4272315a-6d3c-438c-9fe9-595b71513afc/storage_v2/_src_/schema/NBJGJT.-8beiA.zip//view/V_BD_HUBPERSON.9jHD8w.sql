create view V_BD_HUBPERSON as
SELECT case when usermap.fxtid is null  and bde.FNumber in('001','013') then  'addNew' when map.fxtorgid is not null and bde.FNumber in('001','013') then  'update' else 'delete' end as optMethod
 ,per.fid as personID,per.FNumber, usermap.fxtid,per.FName_L2 AS name, null email, map.forglongname ,map.fname orgName , pos.fname_l2 AS pos
	, per.FCell AS mobile
	, CASE per.FGender
		WHEN 1 THEN '男'
		WHEN 2 THEN '女'
		ELSE NULL
	END AS genderName, 
per.FIDCardNO AS IDCardNO, bde.FNumber AS perType, bde.FName_l2 AS perTypeName
 ,emp.fnumber empType ,emp.fname_l2 empTypeName,usermap.fdescription,
 pos.FAdminOrgUnitID  adminOrgId,per.FGender,
  pos.fisrespposition , -- 是否为负责人，新增时，1是负责人，0为一般用户，修改时 ，2为取消负责人，为一般用户
 to_char(per.FBIRTHDAY,'YYYY-MM-DD') FBIRTHDAY,to_char(b.FEnterDate,'YYYY-MM-DD') FEnterDate,
 '0' ishidephone,'sHR' regsource,pmuser.fid userid,pmuser.fnumber as usernumber,pmuser.fname_l2 username,
 0 as isMap
from T_bd_person per  -- 查询员工主表
LEFT JOIN T_HR_BDEmployeeType bde ON per.FEmployeeTypeID = bde.FID -- 用工关系
left join T_HR_EmployeeFenLei emp ON bde.FEmployeeFenLeiID = emp.FID -- 员工状态
left join t_pm_easxtusermap usermap on usermap.FPERSONID = per.fid -- 对应表信息
left join t_pm_user pmuser on  per.fid = pmuser.fpersonid  and pmuser.FForbidden=0 and pmuser.FISDELETE=0 -- 关联用户账号
left join T_HR_PersonPosition b on b.fpersonid = per.fid
LEFT JOIN T_org_Position pos ON pos.FID = b.FPrimaryPositionID --
left join T_ORG_ADMIN a on a.fid = b.fpersondep
LEFT JOIN t_pm_easxtorgmap map ON map.feasorgid = pos.FAdminOrgUnitID 
 WHERE map.fxtorgid is not null
 and per.FCell is not null
 and (per.CFHMCRYLXID = 'mbUAAAID60p9tElB' or per.CFHMCRYLXID is null)  -- 只查询CFHMCRYLXID 类型 自有人员或为空的数据
 
union all
-- FID, FPERSONID, FUSERID, FXTID, FPERSONNAME, FCELL, FORGLONGNAME, FPOSITION, FEMAIL, FUSERNUMBER, FUSERNAME, FSTATUS, FISSYNCH, FDESCRIPTION, FFORBIDDEN, FISDELETE, FAGENTUSER, FCREATETIME, FWEIGHTS, FPERSONNUMBER
select 'update' as optMethod,usermap.FPERSONID,usermap.FPERSONNUMBER,usermap.FXTID,usermap.FPERSONNAME,null email,usermap.FORGLONGNAME,
a.fname_l2 orgname,usermap.FPOSITION,usermap.FCELL,
    CASE per.FGender
		WHEN 1 THEN '男'
		WHEN 2 THEN '女'
		ELSE NULL
	END AS genderName,per.FIDCardNO AS IDCardNO,
bde.FNumber AS perType, bde.FName_l2 AS perTypeName,
emp.fnumber empType ,emp.fname_l2 empTypeName,usermap.fdescription,
b.FPersonDep  adminOrgId,per.FGender,pos.fisrespposition,to_char(per.FBIRTHDAY,'YYYY-MM-DD') FBIRTHDAY,
to_char(b.FEnterDate,'YYYY-MM-DD') FEnterDate,
'0' ishidephone,'sHR' regsource,pmuser.fid userid,pmuser.fnumber as usernumber,pmuser.fname_l2 username,
1 as isMap 
from  t_pm_easxtusermap usermap 
LEFT JOIN T_bd_person per ON usermap.FPERSONID = per.fid 
LEFT JOIN T_HR_BDEmployeeType bde ON per.FEmployeeTypeID = bde.FID 
left join T_HR_EmployeeFenLei emp ON bde.FEmployeeFenLeiID = emp.FID 
LEFT JOIN T_HR_PersonPosition b on b.FPersonID = per.fid
LEFT JOIN T_org_Position pos ON pos.FID = b.FPrimaryPositionID 
left join T_ORG_ADMIN a on a.fid = pos.FAdminOrgUnitID 
left join t_pm_user pmuser on  per.fid = pmuser.fpersonid and pmuser.FForbidden=0 and pmuser.FISDELETE=0
/

