create view V_AR_CHECKACCOUNTBILL1 as
SELECT bill.fbizdate FBILLDATE, bill.fcompanyid FCOMPANYID, bill.fpayertypeid FASSTACTTYPEID, bill.fpayerid FASSTACTID, bill.fcurrencyid FCURRENCYID, bill.fpersonid FPERSONID, bill.fadminorgunitid FADMINORGUNITID, billentry.fid FENTRYID, 1 FDIRECTION, billentry.famount FDAMOUNT, billentry.flocalamount FDAMOUNTLOCAL, billentry.famount FCAMOUNT, billentry.flocalamount FCAMOUNTLOCAL FROM t_cas_receivingbill BILL INNER JOIN t_cas_receivingbillentry BILLENTRY ON bill.fid = billentry.freceivingbillid WHERE (((bill.fsourcetype = 100 AND bill.ffivouchered = 1) AND FIsTransBill = 0) AND ((bill.FPayerTypeID IS NOT NULL) OR (LTRIM(RTRIM(bill.FPayerTypeID)) != '') OR (bill.FPayerID IS NOT NULL) OR (LTRIM(RTRIM(bill.FPayerID)) != '')))
/

