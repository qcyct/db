create view V_SUPPLIERCONSUMMARYTEMP as
select org.companyID,a.FProjectOrgID,c.fid supplierID,a.fid contractID,a.FAuditDate bizDate,org.fnumber || ' '|| org.FNAME_L2 组织名称,d.fnumber || ' ' ||d.fname_l2 项目组织,c.fnumber || ' ' || c.FNAME_L2 供应商名称,a.fnumber 合同编号,a.FNAME 合同名称,f.fname_l2 合同类型, b.fname_l2 合同成本类型 ,
a.FOriginalAmount 合同变更后金额,
v_matInAmount.amount 累计入库,v_matBalAmount.amount 累计对账, invoice.amount  累计开票,pay.prepay+pay.payAmount 累计付款,req.reqAmount 累计申请
from T_EC_ContractBill a
left join v_transToCompany org on org.transportID = a.FProjectOrgID
left join CT_BAS_ContractCostType b on a.FContractCostTypeID = b.fid
left join T_BD_SUPPLIER c on a.FPartBID = c.fid
left join T_ORG_Transport d on a.FProjectOrgID = d.fid 
left join T_EC_ContractType f on a.FContractTypeID = f.fid
--累计入库
left join (
select fcontractid,sum(amount) amount from (
select fcontractid, sum(nvl(a.FOriginalAmount,0))  amount from T_EC_MaterialInvBill a 
where fbillsate='03' group by fcontractid
union all
select a.cfcontractid,sum(nvl(a.CFOriginalAmount,0)) amount from CT_INV_InvAdjust a
where a.cftranstypeid= 'mbUAAAAgcZ5/Dqk0' and a.cfbillsate='03'  group by a.cfcontractid
) matin group by fcontractid
) v_matInAmount on v_matInAmount.fcontractid = a.fid
--累计对账
left join (
 select Cfcontractid ,sum(Cfbalamountsum) amount
        from CT_SET_MTBalanceBill 
         where Cfbillsate='03'  group by Cfcontractid
)v_matBalAmount on  v_matBalAmount.Cfcontractid = a.fid

--累计开票
left join (
select Cfcontractid,sum(Cftotamount)   amount
      from
      (select Cfcontractid,sum(Cftotamount) Cftotamount
       from CT_II_GeneralInvoice 
       where Cfbillsate in ('03','04','05','06','10')
       group by Cfcontractid
       union all
       select Cfcontractid,sum(Cftotamount) Cftotamount
       from  CT_II_InvoiceBill
       where Cfbillsate in ('03','04','05','06','10')
       group by Cfcontractid
      )    invoice group by   Cfcontractid
) invoice on invoice.Cfcontractid = a.fid

--累计付款
left join (
select contractid,sum(prepay) prepay,sum(payAmount) payamount from (
    select CFCFContractID0 contractid,sum(impay.cfimprestamount)  prepay,0 payAmount
    from CT_II_ImprestBill impay
    where  impay.cfbillstate='03' group by CFCFContractID0
    union all 
    select InvoicePBI.Cfcfcontractid0,0, sum(InvoicePaymentBill.CFPayAmount)  payAmount
    from CT_II_InvoicePayRequestBill InvoicePaymentBill
    LEFT OUTER JOIN CT_II_InvoicePRBI  InvoicePBI ON InvoicePBI.Fparentid = InvoicePaymentBill.Fid and InvoicePBI.fseq =1
    where  InvoicePaymentBill.Cfbillsate in ('03','04','05','06')
    group by    InvoicePBI.Cfcfcontractid0
)pay GROUP BY contractid
) pay on pay.contractid = a.fid

--累计申请
left join (
 select InvoicePBI.Cfcfcontractid0 Cfcontractid,sum(InvoicePBI.CFReqPayAmount)  reqAmount
    from CT_II_InvoicePayRequestBill InvoicePaymentBill
    LEFT OUTER JOIN CT_II_InvoicePRBI  InvoicePBI ON InvoicePBI.Fparentid = InvoicePaymentBill.Fid
    where  InvoicePaymentBill.Cfbillsate in ('03','04','05','06')
    group by    InvoicePBI.Cfcfcontractid0
) req on req.Cfcontractid =  a.fid
where a.FContractCostTypeID is not null
and a.FIsCentralizedPur =0
order by org.fnumber,d.fnumber,c.fnumber
/

