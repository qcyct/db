create procedure NkyInvoiceApply_addinvoice (
v_proprojectid in varchar2 default '',
v_invoiceapplyid in varchar2 ) as
v_ticetkAmountSum NUMBER;
begin
  -- 计算该专业工程下实际开票金额合计
  select nvl(sum(c.cfactticketamount),0) into v_ticetkAmountSum 
         from ct_kc_invoiceapply b, ct_kc_invoiceapplyentry c   
         where b.fid=c.fparentid
               and b.cfbillstate='03' 
               and c.cfnkyproprojectid=v_proprojectid  
               and b.fid!=v_invoiceapplyid  ;
  update ct_kc_nkyproproject a set a.Cftotticketamount = v_ticetkAmountSum   where a.fid=v_proprojectid;
  update CT_KC_NkyOCPE d set d.cftotticketamount = v_ticetkAmountSum    where d.cfproprojectnumber = v_proprojectid;  
end NkyInvoiceApply_addinvoice;
/

