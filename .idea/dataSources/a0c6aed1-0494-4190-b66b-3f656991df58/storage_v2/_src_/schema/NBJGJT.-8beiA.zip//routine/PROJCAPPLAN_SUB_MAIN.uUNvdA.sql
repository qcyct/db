create procedure ProjCapPlan_Sub_Main(
v_projectorg in varchar2 default '' ,
v_startdate in varchar2,
v_enddate in varchar2) is
cursor cc is   select c.fname_l2 contractCostType,a.fpartbid supplierID,b.fname_l2 supplierName, a.fid contractID,a.fname contractName,a.foriginalamount contractAmount ,a.cfytaxrate taxRate,substr(a.fpaymentterms,0,400) paymentterms
from T_EC_ContractBill a
left outer join T_BD_Supplier b on b.fid=a.fpartbid
left outer join CT_BAS_ContractCostType c on c.fid=a.fcontractcosttypeid
where a.fprojectorgid=v_projectorg
and a.fcontracttypeid='AsNgkrwvT4K5uhJBrd1MR+ZhjkE='-- 合同类型 专业分包合同
and a.fcontractattribute='0'
and a.fcontractstatus in ('3','6','10') --合同状态 批准 签订 执行
order by c.fnumber asc;

tt cc%rowtype;
v_paypercent number(28,10);--付款比例
v_startperiod date;
v_endperiod date;
per_matBalAmount number(28,10);--本期结算
tot_matBalAmount number(28,10);--累计结算
tot_payAmount  number(28,10);--累计付款
tot_unPayAmount number(28,10);--累计未付
v_seqNum integer;
begin
  if v_startdate is not null then
    v_startperiod := to_date(v_startdate,'yyyyMMdd');
  end if;
  if v_enddate is not null then
    v_endperiod := to_date(v_enddate,'yyyyMMdd')+1;
  end if;         

  select count(*)+1 into v_seqNum FROM  ProjCapPlan_temp;
  --插入第一行 类型 4、专业分包
  insert into ProjCapPlan_temp(contractCostType,Seqnum,Countsign) values ('4.专业分包',v_seqNum,'c4');
  v_seqNum:=v_seqNum+1;
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;

  per_matBalAmount:= 0;--本期结算
  tot_matBalAmount:= 0;--累计结算
  tot_payAmount:=0;--累计付款
  tot_unPayAmount:=0;--累计未付

  
   --本期结算
   select sum(d.foriginalamount)  into per_matBalAmount
         from T_EC_ContractSettleBill  d
          where d.fprojectorgid=v_projectorg
          and d.fcontractbillid=tt.contractID
          and d.fbizdate>=v_startperiod
          and d.fbizdate <v_endperiod
          and d.fbillsate in ('03','04','05','06','10','30','40');
  per_matBalAmount:= nvl(per_matBalAmount,0);--本期结算
  --累计结算
  select sum(d.foriginalamount)  into tot_matBalAmount
         from T_EC_ContractSettleBill  d
          where d.fprojectorgid=v_projectorg
          and d.fcontractbillid=tt.contractID
          and d.fbizdate <v_endperiod
          and d.fbillsate in ('03','04','05','06','10','30','40');
  tot_matBalAmount:= nvl(tot_matBalAmount,0);--累计结算
  --累计付款
  mat_settlesummary_payAmount(v_projectorg,tt.CONTRACTID,null,v_endperiod,tot_payAmount);

    --累计未付 = 累计对账-累计已付
    tot_unPayAmount:= tot_matBalAmount-tot_payAmount;

   --付款比例  = 累计付款/累计对账
   if tot_matBalAmount>0 then
      v_paypercent:= round(tot_payAmount/tot_matBalAmount,2);
   else
      v_paypercent:= 0;
   end if;
   per_matBalAmount:= nvl(per_matBalAmount,0);--本期结算
   tot_matBalAmount:= nvl(tot_matBalAmount,0);--累计结算
   tot_payAmount:= nvl(tot_payAmount,0);--累计付款
   tot_unPayAmount:= nvl(tot_unPayAmount,0);--累计未付

   insert into ProjCapPlan_temp(contractCostType,supplierName,supplierID,contractID,contractName,contractAmount,taxRate,permatBalAmount,totmatBalAmount,totpayAmount,totunPayAmount,paypercent,paymentterms,Countsign,Seqnum )
   values(tt.contractcosttype,tt.suppliername,tt.supplierid,tt.contractid,tt.contractname,tt.contractamount,tt.taxRate,per_matBalAmount,tot_matBalAmount,tot_payAmount,tot_unPayAmount,v_paypercent,substr(tt.paymentterms,0,400),'4',v_seqNum);
   v_seqNum:=v_seqNum+1;
  end loop;
  close cc;

  --专业分包-材料拆分
  ProjCapPlan_Sub_Mat(v_projectorg,v_startperiod,v_endperiod);
  --专业分包-劳务拆分
  ProjCapPlan_Sub_Lab(v_projectorg,v_startperiod,v_endperiod);
  --专业分包-设备拆分
  ProjCapPlan_SUB_Rent(v_projectorg,v_startperiod,v_endperiod);

  select count(*)+1 into v_seqNum FROM  ProjCapPlan_temp;
  --插入最后一行 小计
  insert into ProjCapPlan_temp(contractCostType,contractAmount,permatInAmount,totmatInAmount,permatBalAmount,totmatBalAmount,totInvAmount,totpayAmount,totunPayAmount,Countsign,Seqnum)
              select  '小计', sum(a.contractamount) contractAmount,sum(a.permatinamount) permatInAmount,sum(a.Totmatinamount) totmatInAmount,
                      sum(a.totmatbalamount) permatBalAmount,sum(a.Totmatbalamount) totmatBalAmount,
                      sum(a.Totinvamount) totInvAmount,sum(a.Totpayamount) totpayAmount,sum(a.Totunpayamount) totunPayAmount ,'c4',v_seqNum
                      from ProjCapPlan_temp a  where a.countsign='4' ;

  -- 其他费用
  ProjCapPlan_OtherCost(v_projectorg,v_startperiod,v_endperiod);

  select count(*)+1 into v_seqNum FROM  ProjCapPlan_temp;
  --插入最后一行 总 合计
  insert into ProjCapPlan_temp(contractCostType,contractAmount,permatInAmount,totmatInAmount,permatBalAmount,totmatBalAmount,totInvAmount,totpayAmount,totunPayAmount,Countsign,Seqnum)
              select  '合计', sum(a.contractamount) contractAmount,sum(a.permatinamount) permatInAmount,sum(a.Totmatinamount) totmatInAmount,
                      sum(a.totmatbalamount) permatBalAmount,sum(a.Totmatbalamount) totmatBalAmount,
                      sum(a.Totinvamount) totInvAmount,sum(a.Totpayamount) totpayAmount,sum(a.Totunpayamount) totunPayAmount ,'c6',v_seqNum
                      from ProjCapPlan_temp a  where a.countsign in ('c1','c2','c3','c4','c5') ;


end ProjCapPlan_Sub_Main;
/

