create view V_GL_ACPERIOD as
SELECT DISTINCT c.FCOMPANYID FCOMPANYID, rangeperiod.fid FPERIODID FROM t_bd_systemstatusctrol C, t_bd_period P, t_bd_period RANGEPERIOD WHERE (((p.fid = (SELECT CASE  WHEN (c.facperiodid IS NOT NULL) THEN c.facperiodid ELSE c.fstartperiodid END FROM DUAL) AND (((p.fperiodyear * 100) + p.fperiodnumber) <= ((rangeperiod.fperiodyear * 100) + rangeperiod.fperiodnumber))) AND p.ftypeid = rangeperiod.ftypeid) AND c.fsystemstatusid = (SELECT fid FROM t_bd_systemstatus WHERE fname = 6))
/

