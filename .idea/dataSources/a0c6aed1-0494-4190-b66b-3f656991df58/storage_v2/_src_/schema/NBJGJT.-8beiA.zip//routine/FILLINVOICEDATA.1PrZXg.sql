create procedure fillInvoiceData is
cursor cc is    select a.fid,a.cftotamount,a.cfinvoiceamount,a.cfnotaxamount,a.cfinvoicetax,a.Cfinvoicebilltaxrate,a.Cfledpartamount,a.cfledpartnotaxamount,a.cfledparttax,a.cfgoodsname
 from ct_out_prebillproject a where a.cfbillsate='03' and a.cfgoodsname is null  ;

tt cc%rowtype;
v_goodsname   varchar2(200);
v_taxrate  integer;
v_notaxamount number(28,10);
v_invoicetax number(28,10);
begin
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;

  select c.fname_l2, b.cfbilltaxrate into v_goodsname,v_taxrate
  from ct_out_prebillprojectentry b  left outer join CT_TAX_Commoditycode c on b.cfgoodscodeid=c.fid
  where b.fparentid=tt.fid and rownum=1;

  v_notaxamount:=round(tt.cftotamount*100/(v_taxrate+100),2);
  v_invoicetax:=tt.cftotamount-v_notaxamount;

  update ct_out_prebillproject d set d.cfinvoiceamount=tt.cftotamount,d.cfnotaxamount=v_notaxamount,d.cfinvoicetax=v_invoicetax,d.Cfinvoicebilltaxrate=v_taxrate,
                               d.Cfledpartamount=tt.cftotamount,d.cfledpartnotaxamount=v_notaxamount,d.cfledparttax=v_invoicetax,d.cfgoodsname=v_goodsname
  where d.fid=tt.fid;

  end loop;
  close cc;

end fillInvoiceData;
/

