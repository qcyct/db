create procedure JGSupllier_Contract_all(
v_mainspid in varchar2,
v_jgspid in varchar2) is
cursor cc is --材料合同 2
         select '2' contype,b.fid,b.fnumber,b.fname conname,b.fprojectorgid projectorgid,b.foriginalamount originalamount,b.fbegindate begindate,b.ffinishdate finishdate,b.fbizdate   from  T_EC_ContractBill b
                where  b.fcontractclass='2'-- 合同类型 购销合同
                and b.fcontractattribute='0' --合同性质  原始合同
                and b.fcontractstatus in ('3','6','10') --合同状态 批准 签订 执行
                and b.fpartbid=v_mainspid
         union --专业分包 1
         select  '1' contype, b.fid,b.fnumber,b.fname conname,b.fprojectorgid projectorgid,b.foriginalamount originalamount,b.fbegindate begindate,b.ffinishdate finishdate,b.fbizdate   from  T_EC_ContractBill b
         where  b.fcontracttypeid='AsNgkrwvT4K5uhJBrd1MR+ZhjkE='-- 合同类型 专业分包合同
                and b.fcontractattribute='0'
                and b.fcontractstatus in ('3','6','10') --合同状态 批准 签订 执行
                and b.fpartbid=v_mainspid
         union --劳务 5
         select '5' contype, b.fid,b.fnumber,b.fname conname,b.fprojectorgid projectorgid,b.foriginalamount originalamount,b.fbegindate begindate,b.ffinishdate finishdate,b.fbizdate   from  T_EC_ContractBill b
         where b.fcontracttypeid='ltCU6k5lT7KgOIUWZQqcIuZhjkE='-- 合同类型 劳务分包合同
               and b.fcontractattribute='0'
               and b.fcontractstatus in ('3','6','10') --合同状态 批准 签订 执行
               and b.fpartbid=v_mainspid
         union --设备 4
         select '4' contype, c.fid,c.fnumber,c.cfname conname,c.cfprojectorgid projectorgid,c.cforiginalamount originalamount,c.cfbegindate begindate,c.cffinishdate finishdate,c.fbizdate  from CT_LB_LeaseContractBill c
         where  c.cfcontractattribute='0' -- 原始合同
                and c.cfcontractstatus in ('3','6','7','10')
                and c.cfsupplierid=v_mainspid
         union --运输 3
         select '3' contype, d.fid,d.fnumber,d.cfname conname,d.cfprojectorgid projectorgid,d.cforiginalamount originalamount,d.cfbegindate begindate,d.cffinishdate finishdate,d.fbizdate from CT_TRA_DevTransContractBill d
                where d.cfcontractattribute='0' -- 原始合同
                and d.cfcontractstatus in ('3','6','7','10')
                and d.cfsupplierid=v_mainspid;

tt cc%rowtype;

begin

  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;
     insert into ct_sup_jgsupplierentry (fid,fparentid,cfcontractid,cfcontractnumber,cfcontractname,cfprojectorgid,cfcontractamount,cfstartdate,cfenddate,cfsigndate,cfjgcontracttype)
          values(newbosid('AD582822'),v_jgspid,tt.fid,tt.fnumber,tt.conname,tt.projectorgid,tt.originalamount,tt.begindate,tt.finishdate,tt.fbizdate,tt.contype);

  end loop;
  close cc;

end JGSupllier_Contract_all;
/

