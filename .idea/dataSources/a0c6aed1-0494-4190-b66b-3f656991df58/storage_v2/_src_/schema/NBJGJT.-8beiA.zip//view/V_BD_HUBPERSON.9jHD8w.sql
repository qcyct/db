create view V_BD_HUBPERSON as
SELECT case when usermap.fxtid is null  and bde.FNumber in('001','013') then  'addNew' when map.fxtorgid is not null and bde.FNumber in('001','013') then  'update' else 'delete' end as optMethod
 ,per.fid as personID,per.FNumber, usermap.fxtid,per.FName_L2 AS name, per.femail AS email, map.forglongname ,map.fname orgName , pos.fname_l2 AS pos
	, per.FCell AS mobile
	, CASE per.FGender
		WHEN 1 THEN '男'
		WHEN 2 THEN '女'
		ELSE NULL
	END AS genderName, 
per.FIDCardNO AS IDCardNO, bde.FNumber AS perType, bde.FName_l2 AS perTypeName
 ,emp.fnumber empType ,emp.fname_l2 empTypeName,usermap.fdescription,
 a.fid adminOrgId,per.FGender,pos.fisrespposition,
 to_char(per.FBIRTHDAY,'YYYY-MM-DD') FBIRTHDAY,to_char(b.FEnterDate,'YYYY-MM-DD') FEnterDate,
 '0' ishidephone,'sHR' regsource,pmuser.fid userid,pmuser.fnumber as usernumber,pmuser.fname_l2 username,
 0 as isMap
FROM T_ORG_ADMIN a
LEFT JOIN T_HR_PersonPosition b ON a.fid = b.FPersonDep 
LEFT JOIN T_org_Position pos ON pos.FID = b.FPrimaryPositionID 
LEFT JOIN T_bd_person per ON b.FPERSONID = per.fid 
LEFT JOIN t_pm_easxtorgmap map ON map.feasorgid = pos.FAdminOrgUnitID 
LEFT JOIN T_HR_BDEmployeeType bde ON per.FEmployeeTypeID = bde.FID 
left join T_HR_EmployeeFenLei emp ON bde.FEmployeeFenLeiID = emp.FID 
left join t_pm_easxtusermap usermap on usermap.FPERSONID = per.fid
left join t_pm_user pmuser on  per.fid = pmuser.fpersonid  and pmuser.FForbidden=0 and pmuser.FISDELETE=0
WHERE map.fxtorgid is not null
-- and A.FID = 'mbUAAAAX9u7M567U'
union all
-- FID, FPERSONID, FUSERID, FXTID, FPERSONNAME, FCELL, FORGLONGNAME, FPOSITION, FEMAIL, FUSERNUMBER, FUSERNAME, FSTATUS, FISSYNCH, FDESCRIPTION, FFORBIDDEN, FISDELETE, FAGENTUSER, FCREATETIME, FWEIGHTS, FPERSONNUMBER
select 'update' as optMethod,usermap.FPERSONID,usermap.FPERSONNUMBER,usermap.FXTID,usermap.FPERSONNAME,usermap.FEMAIL,usermap.FORGLONGNAME,
a.fname_l2 orgname,usermap.FPOSITION,usermap.FCELL,
    CASE per.FGender
		WHEN 1 THEN '男'
		WHEN 2 THEN '女'
		ELSE NULL
	END AS genderName,per.FIDCardNO AS IDCardNO,
bde.FNumber AS perType, bde.FName_l2 AS perTypeName,
emp.fnumber empType ,emp.fname_l2 empTypeName,usermap.fdescription,
b.FPersonDep  adminOrgId,per.FGender,pos.fisrespposition,to_char(per.FBIRTHDAY,'YYYY-MM-DD') FBIRTHDAY,
to_char(b.FEnterDate,'YYYY-MM-DD') FEnterDate,
'0' ishidephone,'sHR' regsource,pmuser.fid userid,pmuser.fnumber as usernumber,pmuser.fname_l2 username,
1 as isMap 
from  t_pm_easxtusermap usermap 
LEFT JOIN T_bd_person per ON usermap.FPERSONID = per.fid 
LEFT JOIN T_HR_BDEmployeeType bde ON per.FEmployeeTypeID = bde.FID 
left join T_HR_EmployeeFenLei emp ON bde.FEmployeeFenLeiID = emp.FID 
LEFT JOIN T_HR_PersonPosition b on b.FPersonID = per.fid
LEFT JOIN T_org_Position pos ON pos.FID = b.FPrimaryPositionID 
left join T_ORG_ADMIN a on a.fid = b.FPersonDep 
left join t_pm_user pmuser on  per.fid = pmuser.fpersonid and pmuser.FForbidden=0 and pmuser.FISDELETE=0
/

