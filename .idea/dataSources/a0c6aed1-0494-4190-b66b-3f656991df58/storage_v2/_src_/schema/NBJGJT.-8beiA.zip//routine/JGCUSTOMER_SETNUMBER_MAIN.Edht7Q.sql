create procedure JGCustomer_SetNumber_main is
cursor cc is    select  f.fnumber,f.fname_l2,f.fid  from T_BD_CSSPGroup f,T_BD_CSSPGroupStandard g where f.Fcsspgroupstandardid=g.fid and g.ftype=1  and   f.fnumber like '00-%' order by  g.ftype,fnumber asc;
tt cc%rowtype;
begin
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;

    JGCustomer_SetNumber_count(tt.fid);

  end loop;
  close cc;
end JGCustomer_SetNumber_main;
/

