create procedure ProjCapPlan_OtherCost(
v_projectorg in varchar2 default '' ,
v_startdate in date,
v_enddate in date) is
cursor cc is   select distinct b.cfcontractcosttype costTypeID,c.fname_l2 contractCostType
 from CT_INV_OtherCostReg a
 left outer join  CT_INV_OtherCostRegEntry b on  a.fid=b.fparentid
 left outer join CT_BAS_ContractCostType c on c.fid=b.cfcontractcosttype
 where    a.cfprojectorgid=v_projectorg
 union
select eae1.cfcontractcosttype costTypeID,c.fname_l2 contractCostType  from CT_EXP_ExpenseApply ea1
left outer join CT_EXP_ExpenseApplyEntry eae1 on ea1.fid=eae1.fparentid
left outer join CT_BAS_ContractCostType c on c.fid= eae1.cfcontractcosttype
where  ea1.cfprojectorgid=v_projectorg  
union
select eae2.cfcontractcosttype costTypeID,c.fname_l2 contractCostType  from CT_EXP_ExpenseApply ea2
left outer join CT_EXP_ExpenseApplyE21 eae2 on ea2.fid=eae2.fparentid
left outer join CT_BAS_ContractCostType c on c.fid= eae2.cfcontractcosttype
where ea2.cfprojectorgid= v_projectorg
;

tt cc%rowtype;
v_paypercent number(28,10);--付款比例
per_matBalAmount number(28,10);--本期结算
tot_matBalAmount number(28,10);--累计结算
tot_payAmount  number(28,10);--累计付款
tot_payAmountTemp  number(28,10);--累计付款2
tot_unPayAmount number(28,10);--累计未付
v_seqNum integer;

begin
  select count(*)+1 into v_seqNum FROM  ProjCapPlan_temp;
  --插入第一行 类型 5、其他
  insert into ProjCapPlan_temp(contractCostType,Seqnum,Countsign) values ('5.其他',v_seqNum,'c5');
  v_seqNum:=v_seqNum+1;
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;

  per_matBalAmount:= 0;--本期结算
  tot_matBalAmount:= 0;--累计结算
  tot_payAmount:=0;--累计付款
  tot_payAmountTemp:=0;--累计付款2
  tot_unPayAmount:=0;--累计未付

   --本期结算 包括 其他费用登记表 ，个人差旅报销单
   select nvl(sum(peramount),0)  into per_matBalAmount  from (
    select nvl(sum(f.cftaxinamount),0 ) peramount
         from CT_INV_OtherCostReg  d,CT_INV_OtherCostRegEntry f
          where d.fid=f.fparentid
          and d.cfprojectorgid=v_projectorg
          and f.cfcontractcosttype=tt.costTypeID
          and d.fbizdate>=v_startdate
          and d.fbizdate <v_enddate
          and d.cfbillstate in ('03','04','05','06','10')
    union
    select nvl(sum(eae1.cfexpamount),0) peramount from CT_EXP_ExpenseApply ea1,CT_EXP_ExpenseApplyEntry eae1   
           where ea1.fid=eae1.fparentid
           and ea1.cfprojectorgid=  v_projectorg
           and eae1.cfcontractcosttype=tt.costTypeID
           and ea1.fbizdate>=v_startdate
           and ea1.fbizdate<v_enddate
           and ea1.cfbillstate in ('03','04','05','06','10')
    union
    select nvl(sum(eae2.cfothexpamount),0) peramount from CT_EXP_ExpenseApply ea2,CT_EXP_ExpenseApplyE21 eae2  
           where  ea2.fid=eae2.fparentid
           and ea2.cfprojectorgid=  v_projectorg
           and eae2.cfcontractcosttype=tt.costTypeID
           and ea2.fbizdate>=v_startdate
           and ea2.fbizdate<v_enddate
           and ea2.cfbillstate in ('03','04','05','06','10')
     )  ;

  --累计结算 
  select  nvl(sum(peramount),0)   into tot_matBalAmount from (
    select nvl(sum(f.cftaxinamount),0 ) peramount
         from CT_INV_OtherCostReg  d,CT_INV_OtherCostRegEntry f
          where d.fid=f.fparentid
          and d.cfprojectorgid=v_projectorg
          and f.cfcontractcosttype=tt.costTypeID
          and d.fbizdate <v_enddate
          and d.cfbillstate in ('03','04','05','06','10')
    union
    select nvl(sum(eae1.cfexpamount),0) peramount from CT_EXP_ExpenseApply ea1,CT_EXP_ExpenseApplyEntry eae1   
           where ea1.fid=eae1.fparentid
           and ea1.cfprojectorgid=  v_projectorg
           and eae1.cfcontractcosttype=tt.costTypeID
           and ea1.fbizdate<v_enddate
           and ea1.cfbillstate in ('03','04','05','06','10')
    union
    select nvl(sum(eae2.cfothexpamount),0) peramount from CT_EXP_ExpenseApply ea2,CT_EXP_ExpenseApplyE21 eae2  
           where  ea2.fid=eae2.fparentid
           and ea2.cfprojectorgid=  v_projectorg
           and eae2.cfcontractcosttype=tt.costTypeID
           and ea2.fbizdate<v_enddate
           and ea2.cfbillstate in ('03','04','05','06','10')
     );

  --累计付款 包括 其他费用登记表 ，个人差旅报销单
  select nvl(sum(amount),0) into tot_payAmount from(
  select distinct ocre.Cfcontractcosttype,  ocre.Cftaxinamount amount,ocre.Cfcostremark,ocre.fid
      from CT_II_InvoicePaymentBill InvoicePaymentBill
      LEFT OUTER JOIN CT_II_InvoicePBI  InvoicePBI ON InvoicePBI.Fparentid = InvoicePaymentBill.Fid
      LEFT OUTER JOIN CT_II_InvoiceCheckBill icb  on icb.CFInvoiceId=InvoicePBI.Cfcfinvoicebillid0
      left outer join CT_II_InvoiceCheckBillEntry icben on icb.fid=icben.fparentid
      left outer join CT_INV_OtherCostRegEntry ocre on ocre.fid=icben.cfsourceentryid 
                 where InvoicePaymentBill.Cfprojectorgid=v_projectorg 
                 and InvoicePBI.Cfcontracttype='9' --合同类型 其他费用
                 and InvoicePaymentBill.Cfbillsate in ('03','04','05','06')
                 and InvoicePaymentBill.Cfunpayamount=0 --未付款金额=0
                 and ocre.Cfcontractcosttype =tt.costTypeID 
                 and InvoicePaymentBill.Fbizdate<v_enddate
                 );
    select  nvl(sum(peramount),0)   into tot_payAmountTemp from (
    select nvl(sum(eae1.cfexpamount),0) peramount from CT_EXP_ExpenseApply ea1,CT_EXP_ExpenseApplyEntry eae1   
           where ea1.fid=eae1.fparentid
           and ea1.cfprojectorgid=  v_projectorg
           and eae1.cfcontractcosttype=tt.costTypeID
           and ea1.fbizdate<v_enddate
           and ea1.cfbillstate in ('05')
    union
    select nvl(sum(eae2.cfothexpamount),0) peramount from CT_EXP_ExpenseApply ea2,CT_EXP_ExpenseApplyE21 eae2  
           where  ea2.fid=eae2.fparentid
           and ea2.cfprojectorgid=  v_projectorg
           and eae2.cfcontractcosttype=tt.costTypeID
           and ea2.fbizdate<v_enddate
           and ea2.cfbillstate in ('05')
     );   
     
     tot_payAmount:=tot_payAmount + tot_payAmountTemp;       

    --累计未付 = 累计对账-累计已付
    tot_unPayAmount:= tot_matBalAmount-tot_payAmount;

   --付款比例  = 累计付款/累计对账
   if tot_matBalAmount>0 then
      v_paypercent:= round(tot_payAmount/tot_matBalAmount,2);
   else
      v_paypercent:= 0;
   end if;
   per_matBalAmount:= nvl(per_matBalAmount,0);--本期结算q
   tot_matBalAmount:= nvl(tot_matBalAmount,0);--累计结算
   tot_payAmount:= nvl(tot_payAmount,0);--累计付款
   tot_unPayAmount:= nvl(tot_unPayAmount,0);--累计未付

   insert into ProjCapPlan_temp(contractCostType,permatBalAmount,totmatBalAmount,totpayAmount,totunPayAmount,paypercent,Countsign,Seqnum )
    values(tt.contractCostType,per_matBalAmount,tot_matBalAmount,tot_payAmount,tot_unPayAmount,v_paypercent,'5',v_seqNum);
   v_seqNum:=v_seqNum+1;
  end loop;
  close cc;

  --插入最后一行 小计
  insert into ProjCapPlan_temp(contractCostType,contractAmount,permatInAmount,totmatInAmount,permatBalAmount,totmatBalAmount,totInvAmount,totpayAmount,totunPayAmount,Countsign,Seqnum)
              select  '小计', sum(a.contractamount) contractAmount,sum(a.permatinamount) permatInAmount,sum(a.Totmatinamount) totmatInAmount,
                      sum(a.totmatbalamount) permatBalAmount,sum(a.Totmatbalamount) totmatBalAmount,
                      sum(a.Totinvamount) totInvAmount,sum(a.Totpayamount) totpayAmount,sum(a.Totunpayamount) totunPayAmount ,'c5',v_seqNum
                      from ProjCapPlan_temp a  where a.countsign='5' ;

end ProjCapPlan_OtherCost;
/

