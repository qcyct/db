create view T_CAS_JOURNALSUMMARY as
SELECT fcompanyid, faccountviewid, fcurrencyid, fperiodid, fcreatedate, SUM(fdebitamount) FDEBITAMOUNT, SUM(fcreditamount) FCREDITAMOUNT, faccountbankid, SUM(fisdebit) FDEBITCOUNT, (COUNT(fisdebit) - SUM(fisdebit)) FCREDITCOUNT, ftype FROM t_cas_journal WHERE (fperiodid IS NOT NULL) GROUP BY fcompanyid, fperiodid, fcreatedate, ftype, fcurrencyid, faccountviewid, faccountbankid
/

