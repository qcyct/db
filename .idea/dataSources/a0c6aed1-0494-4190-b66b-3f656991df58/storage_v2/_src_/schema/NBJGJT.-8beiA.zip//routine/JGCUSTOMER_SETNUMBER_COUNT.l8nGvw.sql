create procedure JGCustomer_SetNumber_count(
v_csspgroupID in varchar2 ) is
cursor cc is    select a.fid ,a.fnumber,a.cfcustomername,a.cfcustomertypetreeid,a.cfcustomertypenumber,a.cfcustomertype 
from Ct_Sup_Jgcustomer  a  where a.cfcustomertypetreeid=v_csspgroupID order by a.cfcustomertypenumber,a.fnumber;

tt cc%rowtype;
v_seqnum integer;
v_number varchar2(44);
begin
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;

    select b.cfseqnumber+1 into v_seqnum from CT_SPB_JGSupplierCustomerSeq  b  where  b.cfcssgrouptreeid=v_csspgroupID;
    v_number:= lpad(v_seqnum,6,'0');
    
    update Ct_Sup_Jgcustomer c set c.fnumber=c.cfcustomertypenumber||'-'||v_number where c.fid=tt.fid;

    update  CT_SPB_JGSupplierCustomerSeq  b set b.cfseqnumber=b.cfseqnumber+1 where  b.cfcssgrouptreeid=v_csspgroupID;
  end loop;
  close cc;
end JGCustomer_SetNumber_count;
/

