create procedure ProjCapPlan_Sub_Lab(
v_projectorg in varchar2 default '' ,
v_startperiod in date,
v_endperiod in date) is
cursor cc is   select c.fname_l2 contractCostType,a.cfsupplierid supplierID,b.fname_l2 supplierName,a.fid contractID,a.cfname contractName,a.cforiginalamount contractAmount,substr(a.cfpaymentterms,0,400) paymentterms
from ct_lab_labourcontract a
left outer join T_BD_Supplier b on b.fid=a.cfsupplierid
left outer join CT_BAS_ContractCostType c on c.fid=a.cfcontractcosttype
left outer join T_BAS_ContractCostTypeTREE d on d.fid= c.ftreeid
where a.cfprojectorgid=v_projectorg
and d.fnumber ='04' --专业分包拆分 劳务协议
and a.cfcontractattribute='0' -- 原始合同
and a.cfcontractstatus in ('3','6','7','10')
order by c.fnumber asc;

tt cc%rowtype;
v_paypercent number(28,10);--付款比例
per_matBalAmount number(28,10);--本期结算
tot_matBalAmount number(28,10);--累计结算
tot_payAmount  number(28,10);--累计付款
tot_unPayAmount number(28,10);--累计未付
v_payAmount  number(28,10);--正常付款
v_seqNum integer;

begin
  select count(*)+1 into v_seqNum FROM  ProjCapPlan_temp;

  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;

  per_matBalAmount:= 0;--本期结算
  tot_matBalAmount:= 0;--累计结算
  tot_payAmount:=0;--累计付款
  tot_unPayAmount:=0;--累计未付

   select sum(d.cfpaytaxamount)  into per_matBalAmount
         from ct_lab_laboursettlebill  d
          where d.cfprojectorgid=v_projectorg
          and d.cfcontractid=tt.contractID
          and d.fbizdate>=v_startperiod
          and d.fbizdate <v_endperiod
          and d.cfbillsate in ('03','04','05','06','10');
  per_matBalAmount:= nvl(per_matBalAmount,0);--本期结算
  --劳务预付单
  select sum(d.cfpaytaxamount) ,sum(d.cfpayamount) into tot_matBalAmount, tot_payAmount
         from ct_lab_laboursettlebill  d
          where d.cfprojectorgid=v_projectorg
          and d.cfcontractid=tt.contractID
          and d.fbizdate <v_endperiod
          and d.cfbillsate in ('03','04','05','06','10');
   tot_matBalAmount:= nvl(tot_matBalAmount,0);--累计结算
   tot_payAmount:= nvl(tot_payAmount,0);--累计付款

   --正常付款单
   select sum(InvoicePBI.Cfcurrpayamount) into v_payAmount
      from CT_II_InvoicePaymentBill InvoicePaymentBill
      LEFT OUTER JOIN CT_II_InvoicePBI  InvoicePBI ON InvoicePBI.Fparentid = InvoicePaymentBill.Fid
                 where InvoicePaymentBill.Cfprojectorgid=v_projectorg
                 and InvoicePBI.Cfcfcontractid0= tt.contractID
                 and InvoicePaymentBill.Cfbillsate in ('03','04','05','06')
                 and InvoicePaymentBill.Fbizdate<v_endperiod ;
    v_payAmount:= nvl(v_payAmount,0);--正常付款
    tot_payAmount:=tot_payAmount+v_payAmount;
    --累计未付 = 累计结算-累计付款
    tot_unPayAmount:= tot_matBalAmount-tot_payAmount;

   --付款比例  = 累计付款/累计对账
   if tot_matBalAmount>0 then
      v_paypercent:= round(tot_payAmount/tot_matBalAmount,2);
   else
      v_paypercent:= 0;
   end if;
   per_matBalAmount:= nvl(per_matBalAmount,0);--本期结算
   tot_matBalAmount:= nvl(tot_matBalAmount,0);--累计结算
   tot_payAmount:= nvl(tot_payAmount,0);--累计付款
   tot_unPayAmount:= nvl(tot_unPayAmount,0);--累计未付

   insert into ProjCapPlan_temp(contractCostType,supplierName,supplierID,contractID,contractName,contractAmount,permatBalAmount,totmatBalAmount,totpayAmount,totunPayAmount,paypercent,paymentterms,Countsign,Seqnum )
   values(tt.contractcosttype,tt.suppliername,tt.supplierid,tt.contractid,tt.contractname,tt.contractamount,per_matBalAmount,tot_matBalAmount,tot_payAmount,tot_unPayAmount,v_paypercent,tt.paymentterms,'4',v_seqNum);
   v_seqNum:=v_seqNum+1;
  end loop;
  close cc;

end ProjCapPlan_Sub_Lab;
/

