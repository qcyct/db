create view T_PM_EASWXUSERMAP_VIEW as
select a.fid id,c.fnumber||'('||d.fnumber||')' fnumber,a.FXTID wxnumber,e.fname_l2 wxname,d.fnumber personNumber,d.FNAME_L2 personName from T_PM_easwxusermap a  
left join T_PM_User c on c.fid=a.FUSERID 
left join T_BD_PERSON d on d.fid = c.fpersonid
left join T_BD_PERSON e on e.fnumber = a.fxtid
where 1=1   
--and c.fnumber like '%马杰%' 
order by c.fnumber
/

