create view V_LIQUID_BALANCE as
SELECT FCompanyID "FCOMPANYID", CASE  WHEN ftype = 1 THEN FAccountViewID ELSE FAccountBankID END "FACCOUNTBANKID", FCurrencyID "FCURRENCYID", (T_BD_Period.Fbegindate + -1) "FBIZDATE", FMonthstartamt "FBALANCE", '1' FTYPE, ftype FCASHORBANK FROM T_CAS_JournalBalance LEFT OUTER JOIN T_BD_Period ON T_CAS_JournalBalance.FPeriodId = T_BD_Period.fid WHERE ((ftype = 1 OR ftype = 2) AND FIsInit = 0)
/

