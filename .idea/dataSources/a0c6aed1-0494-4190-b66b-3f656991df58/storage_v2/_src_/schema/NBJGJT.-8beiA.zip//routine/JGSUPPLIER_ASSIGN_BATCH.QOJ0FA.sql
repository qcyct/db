create procedure JGSupplier_Assign_batch(
v_spinfoID in varchar2 ) is
cursor cc is   select  cfcontrolunitorgid cuorgid from CT_SPB_SupplierAssignOrg;

tt cc%rowtype;
v_cuid varchar2(44); 
i integer;
begin
  v_cuid:='00000000-0000-0000-0000-000000000000CCE7AED4';     
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;
  
  --基础资料分配记录 供应商bostype 37C67DFC
  select count(fid) into i from t_bd_databasedassign where fdatabasedid=v_spinfoID and fassigncuid=tt.cuorgid and FControlUnitID=v_cuid ;
  if i=0 then
    insert into t_bd_databasedassign(fid,fdatabasedid,fassigncuid,fbosobjecttype,FControlUnitID) 
							 values (newbosid('37C67DFC'),v_spinfoID,tt.cuorgid,'37C67DFC' ,v_cuid) ;
  end if;

  --供应商财务信息      
  select count(fid) into i from T_BD_SupplierCompanyInfo where fcomorgid=tt.cuorgid and Fcontrolunitid=tt.cuorgid and fsupplierid=v_spinfoID ;
  if i=0 then 
     insert into T_BD_SupplierCompanyInfo  ( fid,fcomorgid,Fsettlementcurrencyid,Feffectedstatus,Fusingstatus,Fcontrolunitid,
                 Fcreatorid,Fcreatetime,Flastupdateuserid,Flastupdatetime,fsupplierid  )
		    				 values (newbosid('F26C0EC7'),tt.cuorgid,'dfd38d11-00fd-1000-e000-1ebdc0a8100dDEB58FDC','2','0',
		    				 tt.cuorgid ,'256c221a-0106-1000-e000-10d7c0a813f413B7DE7F',systimestamp,
		    				 '256c221a-0106-1000-e000-10d7c0a813f413B7DE7F',systimestamp,v_spinfoID );
  end if;      
  
  end loop;
  close cc;
end JGSupplier_Assign_batch;
/

