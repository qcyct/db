create procedure MatCostMap(
v_matStart in varchar2 default '' ,
v_matEnd in varchar2,
v_costSubjectID in varchar2,
v_industrytypeName in varchar2,
v_industrytypeNumber in varchar2,
v_industrytypeID in varchar2) is
cursor cc is    select a.fid matID,a.fnumber matNumber,a.fname_l2 matName  from t_ec_resourceitem a
where a.fnumber>=v_matStart
and a.fnumber<=v_matEnd  ;

tt cc%rowtype;

i integer;

begin
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;

  --校验该映射关系是否存在  物料ID + 行业
  select  count(b.fid) into i
  from CT_BAS_MatCostMap b
      where b.cfmaterialid=tt.matID
      and b.cfindustrytypeid=v_industrytypeID;
  if i>0 then
    --存在 update
     update CT_BAS_MatCostMap c set c.cfcostaccountid = v_costSubjectID  where c.cfmaterialid = tt.matID and c.cfindustrytypeid=v_industrytypeID;
  else
    --不存在 insert
    insert into   CT_BAS_MatCostMap(fid,Cfmaterialid,Cfmaterialnumber,Cfcostaccountid,Cfindustrytypeid,Cfmaterialname,Cfindustrytypenumber,Cfindustrytypename,Fbizdate,Fcreatetime,Fcreatorid,Fcontrolunitid)
    values (newbosid('9D67FB11'),tt.matID,tt.matNumber,v_costSubjectID,v_industrytypeID,tt.matName,v_industrytypeNumber,v_industrytypeName,sysdate,SYSTIMESTAMP,'256c221a-0106-1000-e000-10d7c0a813f413B7DE7F','c4VJVwEbEADgAE/0ChZiAsznrtQ=');


  end if;

  end loop;
  close cc;

end MatCostMap;
/

