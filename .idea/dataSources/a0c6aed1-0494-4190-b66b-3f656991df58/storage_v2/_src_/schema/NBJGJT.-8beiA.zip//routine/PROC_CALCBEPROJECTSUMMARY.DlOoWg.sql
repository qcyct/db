create procedure proc_calcBEProjectSummary 
(
isProjectOrg in varchar2 default '1',
baseUnitID in varchar2 default '' ,
startDate in varchar2 default '',
endDate in varchar2 default ''
)
as
begin 
--清空缓存表
delete from T_BE_BEProjectSummaryTemp ;
--1 根据项目组织过滤,通过组织获取对应的资金项目，通过资金项目过滤

if isProjectOrg = '1' then --根据单项目过滤

  insert into T_BE_BEProjectSummaryTemp (COLUMN1,COLUMN2,COLUMN3,COLUMN4,COLUMN5,COLUMN6,COLUMN7,COLUMN8,COLUMN9,COLUMN10,COLUMN11,COLUMN12,COLUMN13,COLUMN14,COLUMN15,COLUMN16,COLUMN17,COLUMN18,COLUMN19,COLUMN20,COLUMN21,COLUMN22,COLUMN23,COLUMN24,COLUMN25,COLUMN26,COLUMN27,COLUMN28,COLUMN29,COLUMN30,COLUMN31,COLUMN32)
  select pro.fnumber||' '||pro.fName_l2,org.fname_l2 ,
  --初始化余额 + 开始时间之前所有的进 + 开始之前所有的出 = 期初余额
  nvl(init.期初工程款,0) 工程款,nvl(init.期初往来款,0) 往来款,nvl(init.期初其他费用,0) 其他费用,nvl(init.期初直接贷款,0) 直接贷款,nvl(init.期初票据贴现,0) 票据贴现,
  nvl(init.期初工程款,0) + nvl(init.期初往来款,0) + nvl(init.期初其他费用,0) + nvl(init.期初直接贷款,0) + nvl(init.期初票据贴现,0) 期初小计,

  nvl(actRec.R工程款,0),nvl(actRec.R往来款,0),nvl(actRec.R其他收入,0),nvl(actRec.R直接贷款,0),nvl(actRec.R票据贴现,0),
  nvl(actRec.R工程款,0)+ nvl(actRec.R往来款,0)+nvl(actRec.R其他收入,0)+nvl(actRec.R直接贷款,0)+nvl(actRec.R票据贴现,0) 本期小计,

  nvl(actPay.P材料费,0),nvl(actPay.P人工费,0),nvl(actPay.P分包费,0),nvl(actPay.P机械费,0),nvl(actPay.P税金 ,0),nvl(actPay.P财务费用 ,0),nvl(actPay.P经营管理费用 ,0),nvl(actPay.P往来款,0),nvl(actPay.P其他支出,0),nvl(actPay.P归还直接贷款,0),nvl(actPay.P票据贴现到期还贷,0),
  nvl(actPay.P材料费,0)+nvl(actPay.P人工费,0)+nvl(actPay.P分包费,0)+nvl(actPay.P机械费,0)+nvl(actPay.P税金 ,0)+nvl(actPay.P财务费用 ,0)+nvl(actPay.P经营管理费用 ,0)+nvl(actPay.P往来款,0)+nvl(actPay.P其他支出,0)+nvl(actPay.P归还直接贷款,0)+nvl(actPay.P票据贴现到期还贷,0) 本期支出,
  0,0,0,0,0,0
  from T_BD_Project pro
  left join (
  	 select FProjectID,
				sum(nvl(R工程款,0)) R工程款, 
				sum(nvl(R往来款,0)) R往来款,  
				sum(nvl(R其他收入,0)) R其他收入, 
				sum(nvl(R直接贷款,0)) R直接贷款, 
				sum(nvl(R票据贴现,0)) R票据贴现
				from (
       /*查询本期收款*/
        select rec.* from (
        select a.FProjectID,b.fname_l2 name,nvl(entry.FAmount,0) ACTRECAMT --c.fname_l2 company
        from T_CAS_ReceivingBill a
        left join T_CAS_ReceivingBillEntry entry on a.fid  = entry.FReceivingBillID
        left join T_BD_AccountView actview on actview.fid = entry.FOppAccountID
        left join T_BD_AccountView actview2 on actview2.fid = a.FPayeeAccountID
        left join T_CAS_FeeType b on b.fid = a.FFEETYPEID
        --left join  T_ORG_Company c on c.fid = a.FCompanyID
        --left join T_BD_Project d on d.fid = a.FProjectID
        where 1=1
        and substr(nvl(actview.fnumber,'panda'),0,4) not in ('1001','1002','1003')
        and substr(nvl(actview2.fnumber,'panda'),0,4) in ('1001','1002','1003')
        --添加 a.FPayeeAccountID 收款科目只查 in ('1001','1002','1003')  --2020-06-24 14:06:37  只针对收款
        and a.FProjectID = baseUnitID
        and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') >= startDate -- startDate
        and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') <= endDate-- endDate
        )
        pivot (
        SUM(ACTRECAMT) for name in ('工程款' R工程款,'往来款' R往来款,'其他收入' R其他收入,'直接贷款' R直接贷款,'票据贴现' R票据贴现)
        ) rec 

        /*关联资金调拨单*/
	      union all
	       select rec.* from (
	          select a.CFDestProjectID, b.fname_l2 name,nvl(a.FBuyAmount,0) ACTRECAMT 
	          from T_CAS_FundsMoveBill a
	          left join T_CAS_FeeType b on b.fid = a.CFFTDRLBID
	          --left join  T_ORG_Company c on c.fid = a.FCompanyID
	          --left join T_BD_Project d on d.fid = a.FProjectID
	          where 1=1 and a.FBillState >2 --取审批、结算状态
	          and a.CFDestProjectID = baseUnitID
	          and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') >= startDate -- startDate
	          and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') <= endDate-- endDate
	      )
	      pivot (
	      SUM(ACTRECAMT) for name in ('工程款' R工程款,'往来款' R往来款,'其他收入' R其他收入,'直接贷款' R直接贷款,'票据贴现' R票据贴现)
	      ) rec	
			)   group by FProjectID
  ) actRec on actRec.FProjectID = pro.fid
left join (
			/*查询本期支出，包括代发单，资金调拨单*/	
      select FProjectID,
				sum(nvl(P材料费,0)) P材料费, 
				sum(nvl(P人工费,0)) P人工费,  
				sum(nvl(P分包费,0)) P分包费, 
				sum(nvl(P机械费,0)) P机械费, 
				sum(nvl(P税金,0)) P税金,  
				sum(nvl(P财务费用,0)) P财务费用, 
				sum(nvl(P经营管理费用,0)) P经营管理费用, 
				sum(nvl(P往来款,0)) P往来款,  
				sum(nvl(P其他支出,0)) P其他支出, 
				sum(nvl(P归还直接贷款,0)) P归还直接贷款,
				sum(nvl(P票据贴现到期还贷,0)) P票据贴现到期还贷
				from (
				/*查询本期支出，包括代发单*/	
				select pay.* from (
				          select a.FProjectID, b.fname_l2 name,nvl(entry.FAmount,0) actPayAmt 
				          from T_CAS_PaymentBill a
				          left join T_CAS_PaymentBillEntry entry on a.fid  = entry.FPaymentBillID
									left join T_BD_AccountView actview on actview.fid = entry.FOppAccountID 
				          left join T_CAS_FeeType b on b.fid = a.FFEETYPEID
				          --left join  T_ORG_Company c on c.fid = a.FCompanyID
				          --left join T_BD_Project d on d.fid = a.FProjectID
				          where 1=1
				          and substr(nvl(actview.fnumber,'panda'),0,4) not in ('1001','1002','1003')
				          and a.FProjectID = baseUnitID
				          and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') >= startDate -- startDate
				          and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') <= endDate-- endDate
				      )
				      pivot (
				      SUM(actPayAmt) for name in ('材料费' P材料费,'人工费' P人工费,'分包费' P分包费,'机械费' P机械费,'税金' P税金 ,'财务费用' P财务费用 ,'经营管理费用' P经营管理费用 ,'往来款' P往来款,'其他支出' P其他支出,'归还直接贷款' P归还直接贷款,'票据贴现到期还贷' P票据贴现到期还贷)
				      ) pay
				      union all 
				 /*关联代发单*/	
				      select pay.* from (
				          select a.CFFTPROJECTID, b.fname_l2 name,nvl(a.FActualAmount,0) actPayAmt 
				          from T_CAS_AgentPayBill a
				          left join T_CAS_FeeType b on b.fid = a.FFEETYPEID
				          --left join  T_ORG_Company c on c.fid = a.FCompanyID
				          --left join T_BD_Project d on d.fid = a.FProjectID
				          where 1=1 and a.FBillStatus = 15--取付款状态
				          and a.CFFTPROJECTID = baseUnitID
				          and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') >= startDate -- startDate
				          and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') <= endDate-- endDate
				      )
				      pivot (
				      SUM(actPayAmt) for name in ('材料费' P材料费,'人工费' P人工费,'分包费' P分包费,'机械费' P机械费,'税金' P税金 ,'财务费用' P财务费用 ,'经营管理费用' P经营管理费用 ,'往来款' P往来款,'其他支出' P其他支出,'归还直接贷款' P归还直接贷款,'票据贴现到期还贷' P票据贴现到期还贷)
				      ) pay

				      /*关联资金调拨单*/
				      union all
				       select pay.* from (
				          select a.CFFTPROJECTID, b.fname_l2 name,nvl(a.FSellAmount,0) actPayAmt 
				          from T_CAS_FundsMoveBill a
				          left join T_CAS_FeeType b on b.fid = a.CFFTDCLBID
				          --left join  T_ORG_Company c on c.fid = a.FCompanyID
				          --left join T_BD_Project d on d.fid = a.FProjectID
				          where 1=1 and a.FBillState >2 --取审批、结算状态
				          and a.CFFTPROJECTID = baseUnitID
				          and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') >= startDate -- startDate
				          and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') <= endDate-- endDate
				      )
				      pivot (
				      SUM(actPayAmt) for name in ('材料费' P材料费,'人工费' P人工费,'分包费' P分包费,'机械费' P机械费,'税金' P税金 ,'财务费用' P财务费用 ,'经营管理费用' P经营管理费用 ,'往来款' P往来款,'其他支出' P其他支出,'归还直接贷款' P归还直接贷款,'票据贴现到期还贷' P票据贴现到期还贷)
				      ) pay
				 ) pay    
				 group by FProjectID

    ) actPay on  actPay.FProjectID = pro.fid --actRec. FProjectID = actPay.FProjectID and

  left join 
    --计算期初余额
    (
     select pro.fid,
        /**
        nvl(init.CFEngineer,0) 工程款,nvl(init.CFPayee,0) 往来款,nvl(init.CFOTHERLOAN,0) 其他费用,nvl(init.CFLOAN,0) 直接贷款,nvl(init.CFDISCOUNT,0) 票据贴现,
        nvl(actRec.R工程款,0),nvl(actRec.R往来款,0),nvl(actRec.R其他收入,0),nvl(actRec.R直接贷款,0),nvl(actRec.R票据贴现,0),
        nvl(actPay.P材料费,0),nvl(actPay.P人工费,0),nvl(actPay.P分包费,0),nvl(actPay.P机械费,0),nvl(actPay.P税金 ,0),nvl(actPay.P财务费用 ,0),nvl(actPay.P经营管理费用 ,0),nvl(actPay.P往来款,0),nvl(actPay.P其他支出,0),nvl(actPay.P归还直接贷款,0),nvl(actPay.P票据贴现到期还贷,0),
        **/
        --工程款：= 初始化 + 之前所有的进 - P材料费~P经营管理费用
        (nvl(init.CFEngineer,0)+nvl(actRec.R工程款,0)) - (nvl(actPay.P材料费,0)+nvl(actPay.P人工费,0)+nvl(actPay.P分包费,0)+nvl(actPay.P机械费,0)+nvl(actPay.P税金 ,0)+nvl(actPay.P财务费用 ,0)+nvl(actPay.P经营管理费用 ,0)) 期初工程款,
        --往来款:= 初始化往来 + 之前所有进 - 支出
        nvl(init.CFPayee,0) + nvl(actRec.R往来款,0) - nvl(actPay.P往来款,0) 期初往来款,
        --其他费用:= 初始化 + 进 - 出
        nvl(init.CFOTHERLOAN,0) + nvl(actRec.R其他收入,0) - nvl(actPay.P其他支出,0) 期初其他费用,
        --直接贷款:= 初始化 + 进 - 出
        nvl(init.CFLOAN,0) + nvl(actRec.R直接贷款,0) - nvl(actPay.P归还直接贷款,0) 期初直接贷款,
        --票据贴现:= 初始化 + 进 - 支
        nvl(init.CFDISCOUNT,0) + nvl(actRec.R票据贴现,0) - nvl(actPay.P票据贴现到期还贷,0) 期初票据贴现

        from  T_BD_Project pro 
         left join (

         	select FProjectID,
					sum(nvl(R工程款,0)) R工程款, 
					sum(nvl(R往来款,0)) R往来款,  
					sum(nvl(R其他收入,0)) R其他收入, 
					sum(nvl(R直接贷款,0)) R直接贷款, 
					sum(nvl(R票据贴现,0)) R票据贴现
					from (
               /*之前所有的进*/
                select rec.* from (
                select a.FProjectID,b.fname_l2 name,nvl(entry.FAmount,0) ACTRECAMT --c.fname_l2 company
                from T_CAS_ReceivingBill a
                left join T_CAS_ReceivingBillEntry entry on a.fid  = entry.FReceivingBillID
				        left join T_BD_AccountView actview on actview.fid = entry.FOppAccountID 
				        left join T_BD_AccountView actview2 on actview2.fid = a.FPayeeAccountID
                left join T_CAS_FeeType b on b.fid = a.FFEETYPEID
                --left join  T_ORG_Company c on c.fid = a.FCompanyID
                --left join T_BD_Project d on d.fid = a.FProjectID
                where 1=1
                and substr(nvl(actview.fnumber,'panda'),0,4) not in ('1001','1002','1003')
                and substr(nvl(actview2.fnumber,'panda'),0,4) in ('1001','1002','1003')
                and a.FProjectID = baseUnitID
                and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') >= '2019-08-01' -- 期初数据为7.31号的数据。
                and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') < startDate-- 小于当前开始期间

                )
                pivot (
                SUM(ACTRECAMT) for name in ('工程款' R工程款,'往来款' R往来款,'其他收入' R其他收入,'直接贷款' R直接贷款,'票据贴现' R票据贴现)
                ) rec 

                /*关联资金调拨单*/
				      union all
				       select rec.* from (
				          select a.CFDestProjectID, b.fname_l2 name,nvl(a.FBuyAmount,0) ACTRECAMT 
				          from T_CAS_FundsMoveBill a
				          left join T_CAS_FeeType b on b.fid = a.CFFTDRLBID
				          --left join  T_ORG_Company c on c.fid = a.FCompanyID
				          --left join T_BD_Project d on d.fid = a.FProjectID
				          where 1=1 and a.FBillState >2 --取审批、结算状态
				          and a.CFDestProjectID = baseUnitID
				          and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') >= '2019-08-01' -- 期初数据为7.31号的数据。
                	and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') < startDate-- 小于当前开始期间
				      )
				      pivot (
				      SUM(ACTRECAMT) for name in ('工程款' R工程款,'往来款' R往来款,'其他收入' R其他收入,'直接贷款' R直接贷款,'票据贴现' R票据贴现)
				      ) rec	
				     ) group by FProjectID

          ) actRec on actRec.FProjectID = pro.fid
        left join (
              /*查询之前所有的出,关联代发单，资金调拨单*/
			      select FProjectID,
							sum(nvl(P材料费,0)) P材料费, 
							sum(nvl(P人工费,0)) P人工费,  
							sum(nvl(P分包费,0)) P分包费, 
							sum(nvl(P机械费,0)) P机械费, 
							sum(nvl(P税金,0)) P税金,  
							sum(nvl(P财务费用,0)) P财务费用, 
							sum(nvl(P经营管理费用,0)) P经营管理费用, 
							sum(nvl(P往来款,0)) P往来款,  
							sum(nvl(P其他支出,0)) P其他支出, 
							sum(nvl(P归还直接贷款,0)) P归还直接贷款,
							sum(nvl(P票据贴现到期还贷,0)) P票据贴现到期还贷
							from (
							/*查询本期支出，包括代发单*/	
							select pay.* from (
			                  select a.FProjectID,b.fname_l2 name,nvl(entry.FAmount,0) actPayAmt 
			                  from T_CAS_PaymentBill a
			                  left join T_CAS_PaymentBillEntry entry on a.fid  = entry.FPaymentBillID
												left join T_BD_AccountView actview on actview.fid = entry.FOppAccountID 
			                  left join T_CAS_FeeType b on b.fid = a.FFEETYPEID
			                  --left join  T_ORG_Company c on c.fid = a.FCompanyID
			                  --left join T_BD_Project d on d.fid = a.FProjectID
			                  where 1=1
			                  and substr(nvl(actview.fnumber,'panda'),0,4) not in ('1001','1002','1003')
			                  and a.FProjectID = baseUnitID
			                  and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') >= '2019-08-01' -- 期初数据为7.31号的数据。
			                	and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') < startDate-- 小于当前开始期间
			              )
			              pivot (
			              SUM(actPayAmt) for name in ('材料费' P材料费,'人工费' P人工费,'分包费' P分包费,'机械费' P机械费,'税金' P税金 ,'财务费用' P财务费用 ,'经营管理费用' P经营管理费用 ,'往来款' P往来款,'其他支出' P其他支出,'归还直接贷款' P归还直接贷款,'票据贴现到期还贷' P票据贴现到期还贷)
			              ) pay

							      union all 
							 /*关联代发单*/	
							      select pay.* from (
							          select a.CFFTPROJECTID, b.fname_l2 name,nvl(a.FActualAmount,0) actPayAmt 
							          from T_CAS_AgentPayBill a
							          left join T_CAS_FeeType b on b.fid = a.FFEETYPEID
							          --left join  T_ORG_Company c on c.fid = a.FCompanyID
							          --left join T_BD_Project d on d.fid = a.FProjectID
							          where 1=1 and a.FBillStatus = 15--取付款状态
							          and a.CFFTPROJECTID = baseUnitID
							          and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') >= '2019-08-01' -- 期初数据为7.31号的数据。
			                	and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') < startDate-- 小于当前开始期间
							      )
							      pivot (
							      SUM(actPayAmt) for name in ('材料费' P材料费,'人工费' P人工费,'分包费' P分包费,'机械费' P机械费,'税金' P税金 ,'财务费用' P财务费用 ,'经营管理费用' P经营管理费用 ,'往来款' P往来款,'其他支出' P其他支出,'归还直接贷款' P归还直接贷款,'票据贴现到期还贷' P票据贴现到期还贷)
							      ) pay

							      /*关联资金调拨单*/
							      union all
							       select pay.* from (
							          select a.CFFTPROJECTID, b.fname_l2 name,nvl(a.FSellAmount,0) actPayAmt 
							          from T_CAS_FundsMoveBill a
							          left join T_CAS_FeeType b on b.fid = a.CFFTDCLBID
							          --left join  T_ORG_Company c on c.fid = a.FCompanyID
							          --left join T_BD_Project d on d.fid = a.FProjectID
							          where 1=1 and a.FBillState >2 --取审批、结算状态
							          and a.CFFTPROJECTID = baseUnitID
							          and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') >= '2019-08-01' -- 期初数据为7.31号的数据。
			                	and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') < startDate-- 小于当前开始期间
							      )
							      pivot (
							      SUM(actPayAmt) for name in ('材料费' P材料费,'人工费' P人工费,'分包费' P分包费,'机械费' P机械费,'税金' P税金 ,'财务费用' P财务费用 ,'经营管理费用' P经营管理费用 ,'往来款' P往来款,'其他支出' P其他支出,'归还直接贷款' P归还直接贷款,'票据贴现到期还贷' P票据贴现到期还贷)
							      ) pay
							 ) pay    
							 group by FProjectID

       ) actPay on  actPay.FProjectID = pro.fid --actRec. FProjectID = actPay.FProjectID and
          left join 
            --计算期初余额 = 初始化余额 + 开始时间之前所有的进 + 开始之前所有的出 
              CT_BE_ProjectInitBalance init  on init.FProjectID = pro.FID and init.CFIsEnabled = 1 --启用
        where pro.fid = baseUnitID  
    ) init on init.fid = pro.fid

  left join T_ORG_Company org on org.fid = pro.FCompanyID
      --where FProjectID = 'mbUAAACu+una3gXu'
  where pro.fid = baseUnitID   
  order by org.fnumber,pro.fnumber
  ;

elsif isProjectOrg = '0' then --根据财务组织过滤项目，再关联初始化数据 

insert into T_BE_BEProjectSummaryTemp (COLUMN1,COLUMN2,COLUMN3,COLUMN4,COLUMN5,COLUMN6,COLUMN7,COLUMN8,COLUMN9,COLUMN10,COLUMN11,COLUMN12,COLUMN13,COLUMN14,COLUMN15,COLUMN16,COLUMN17,COLUMN18,COLUMN19,COLUMN20,COLUMN21,COLUMN22,COLUMN23,COLUMN24,COLUMN25,COLUMN26,COLUMN27,COLUMN28,COLUMN29,COLUMN30,COLUMN31,COLUMN32)
select pro.projectnumber ||' '|| pro.projectname,org.fname_l2 company ,
  --初始化余额 + 开始时间之前所有的进 + 开始之前所有的出 = 期初余额
  nvl(init.期初工程款,0) 工程款,nvl(init.期初往来款,0) 往来款,nvl(init.期初其他费用,0) 其他费用,nvl(init.期初直接贷款,0) 直接贷款,nvl(init.期初票据贴现,0) 票据贴现,
  nvl(init.期初工程款,0) + nvl(init.期初往来款,0) + nvl(init.期初其他费用,0) + nvl(init.期初直接贷款,0) + nvl(init.期初票据贴现,0) 期初小计,

  nvl(actRec.R工程款,0),nvl(actRec.R往来款,0),nvl(actRec.R其他收入,0),nvl(actRec.R直接贷款,0),nvl(actRec.R票据贴现,0),
  nvl(actRec.R工程款,0)+ nvl(actRec.R往来款,0)+nvl(actRec.R其他收入,0)+nvl(actRec.R直接贷款,0)+nvl(actRec.R票据贴现,0) 本期小计,

  nvl(actPay.P材料费,0),nvl(actPay.P人工费,0),nvl(actPay.P分包费,0),nvl(actPay.P机械费,0),nvl(actPay.P税金 ,0),nvl(actPay.P财务费用 ,0),nvl(actPay.P经营管理费用 ,0),nvl(actPay.P往来款,0),nvl(actPay.P其他支出,0),nvl(actPay.P归还直接贷款,0),nvl(actPay.P票据贴现到期还贷,0),
  nvl(actPay.P材料费,0)+nvl(actPay.P人工费,0)+nvl(actPay.P分包费,0)+nvl(actPay.P机械费,0)+nvl(actPay.P税金 ,0)+nvl(actPay.P财务费用 ,0)+nvl(actPay.P经营管理费用 ,0)+nvl(actPay.P往来款,0)+nvl(actPay.P其他支出,0)+nvl(actPay.P归还直接贷款,0)+nvl(actPay.P票据贴现到期还贷,0) 本期支出,
  0,0,0,0,0,0

from (
  select distinct b.fid FCompanyID,b.fname_l2 company,a.FProjectID,c.FNAME_L2 projectname,c.fnumber projectnumber from T_CAS_ReceivingBill a --收款单
    left join t_org_company b on a.FCompanyID = b.fid
    left join T_BD_Project c on a.FProjectID  = c.fid
    where a.FProjectID is not null 
    and a.FCompanyID = baseUnitID
  union --付款单
    select distinct b.fid companyId,b.fname_l2,a.FProjectID,c.FNAME_L2,c.fnumber projectnumber from T_CAS_PaymentBill a 
    left join t_org_company b on a.FCompanyID = b.fid
    left join T_BD_Project c on a.FProjectID  = c.fid
    where a.FProjectID is not null 
    and a.FCompanyID = baseUnitID
  union --关联代发单
  	select distinct b.fid companyId,b.fname_l2,a.CFFTPROJECTID,c.FNAME_L2,c.fnumber projectnumber from T_CAS_AgentPayBill a 
    left join t_org_company b on a.FCompanyID = b.fid
    left join T_BD_Project c on a.CFFTPROJECTID  = c.fid
    where a.CFFTPROJECTID is not null 
    and a.FCompanyID = baseUnitID
  union --关联资金调拨单 调入
  	select distinct b.fid companyId,b.fname_l2,a.CFDestProjectID,c.FNAME_L2,c.fnumber projectnumber from T_CAS_FundsMoveBill a 
    left join t_org_company b on a.FCompanyID = b.fid
    left join T_BD_Project c on a.CFDestProjectID  = c.fid
    where a.CFDestProjectID is not null 
    and a.FCompanyID = baseUnitID 
  union --关联资金调拨单 调出
  	select distinct b.fid companyId,b.fname_l2,a.CFFTProjectID,c.FNAME_L2,c.fnumber projectnumber from T_CAS_FundsMoveBill a 
    left join t_org_company b on a.FCompanyID = b.fid
    left join T_BD_Project c on a.CFFTProjectID  = c.fid
    where a.CFFTProjectID is not null 
    and a.FCompanyID = baseUnitID   
) pro
left join (

		select projectname,
				sum(nvl(R工程款,0)) R工程款, 
				sum(nvl(R往来款,0)) R往来款,  
				sum(nvl(R其他收入,0)) R其他收入, 
				sum(nvl(R直接贷款,0)) R直接贷款, 
				sum(nvl(R票据贴现,0)) R票据贴现
				from (
		      /*查询本期收款*/
		      select rec.* from (
		      select d.fname_l2 projectname,b.fname_l2 name,nvl(entry.FAmount,0) ACTRECAMT --c.fname_l2 company
		      from T_CAS_ReceivingBill a
		      left join T_CAS_ReceivingBillEntry entry on a.fid  = entry.FReceivingBillID
					left join T_BD_AccountView actview on actview.fid = entry.FOppAccountID 
					left join T_BD_AccountView actview2 on actview2.fid = a.FPayeeAccountID
		      left join T_CAS_FeeType b on b.fid = a.FFEETYPEID
		      --left join  T_ORG_Company c on c.fid = a.FCompanyID
		      left join T_BD_Project d on d.fid = a.FProjectID
		      where 1=1
		      and substr(nvl(actview.fnumber,'panda'),0,4) not in ('1001','1002','1003')
		      and substr(nvl(actview2.fnumber,'panda'),0,4) in ('1001','1002','1003')
		      and a.FCompanyID = baseUnitID
		      and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') >= startDate -- startDate
		      and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') <= endDate-- endDate
		      )
		      pivot (
		       SUM(ACTRECAMT) for name in ('工程款' R工程款,'往来款' R往来款,'其他收入' R其他收入,'直接贷款' R直接贷款,'票据贴现' R票据贴现)
		      ) rec 

		      /*关联资金调拨单*/
			      union all
			       select rec.* from (
			          select d.fname_l2 projectname, b.fname_l2 name,nvl(a.FBuyAmount,0) ACTRECAMT 
			          from T_CAS_FundsMoveBill a
			          left join T_CAS_FeeType b on b.fid = a.CFFTDRLBID
			          --left join  T_ORG_Company c on c.fid = a.FCompanyID
			          left join T_BD_Project d on d.fid = a.CFDestProjectID --进
			          where 1=1 and a.FBillState >2 --取审批、结算状态
			          and a.FCompanyID = baseUnitID
			          and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') >= startDate -- startDate
			          and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') <= endDate-- endDate
			      )
			      pivot (
			      SUM(ACTRECAMT) for name in ('工程款' R工程款,'往来款' R往来款,'其他收入' R其他收入,'直接贷款' R直接贷款,'票据贴现' R票据贴现)
			      ) rec	
	      )   group by projectname
    )
    actRec on actRec.projectname = pro.projectname 

    left join (

      /*查询本期支出，包括代发单，资金调拨单*/	
      select projectname,
				sum(nvl(P材料费,0)) P材料费, 
				sum(nvl(P人工费,0)) P人工费,  
				sum(nvl(P分包费,0)) P分包费, 
				sum(nvl(P机械费,0)) P机械费, 
				sum(nvl(P税金,0)) P税金,  
				sum(nvl(P财务费用,0)) P财务费用, 
				sum(nvl(P经营管理费用,0)) P经营管理费用, 
				sum(nvl(P往来款,0)) P往来款,  
				sum(nvl(P其他支出,0)) P其他支出, 
				sum(nvl(P归还直接贷款,0)) P归还直接贷款,
				sum(nvl(P票据贴现到期还贷,0)) P票据贴现到期还贷
				from (
						/*查询本期支出，包括代发单*/	
						select pay.* from (
		          select d.fname_l2 projectname,b.fname_l2 name,nvl(entry.FAmount,0) actPayAmt 
		          from T_CAS_PaymentBill a
		          left join T_CAS_PaymentBillEntry entry on a.fid  = entry.FPaymentBillID
							left join T_BD_AccountView actview on actview.fid = entry.FOppAccountID 
		          left join T_CAS_FeeType b on b.fid = a.FFEETYPEID
		          --left join  T_ORG_Company c on c.fid = a.FCompanyID
		          left join T_BD_Project d on d.fid = a.FProjectID
		          where 1=1
		          and substr(nvl(actview.fnumber,'panda'),0,4) not in ('1001','1002','1003')
		          and a.FCompanyID = baseUnitID
		          and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') >= startDate -- startDate
		          and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') <= endDate-- endDate
				      )
				      pivot (
				      SUM(actPayAmt) for name in ('材料费' P材料费,'人工费' P人工费,'分包费' P分包费,'机械费' P机械费,'税金' P税金 ,'财务费用' P财务费用 ,'经营管理费用' P经营管理费用 ,'往来款' P往来款,'其他支出' P其他支出,'归还直接贷款' P归还直接贷款,'票据贴现到期还贷' P票据贴现到期还贷)
				      ) pay
				      union all 
				 			/*关联代发单*/	
				      select pay.* from (
				          select d.fname_l2 projectname, b.fname_l2 name,nvl(a.FActualAmount,0) actPayAmt 
				          from T_CAS_AgentPayBill a
				          left join T_CAS_FeeType b on b.fid = a.FFEETYPEID
				          --left join  T_ORG_Company c on c.fid = a.FCompanyID
				          left join T_BD_Project d on d.fid = a.CFFTPROJECTID
				          where 1=1 and a.FBillStatus = 15--取付款状态
				          and a.FCompanyID = baseUnitID
				          and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') >= startDate -- startDate
				          and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') <= endDate-- endDate
				      )
				      pivot (
				      SUM(actPayAmt) for name in ('材料费' P材料费,'人工费' P人工费,'分包费' P分包费,'机械费' P机械费,'税金' P税金 ,'财务费用' P财务费用 ,'经营管理费用' P经营管理费用 ,'往来款' P往来款,'其他支出' P其他支出,'归还直接贷款' P归还直接贷款,'票据贴现到期还贷' P票据贴现到期还贷)
				      ) pay

				      /*关联资金调拨单*/
				      union all
				       select pay.* from (
				          select d.fname_l2 projectname, b.fname_l2 name,nvl(a.FSellAmount,0) actPayAmt 
				          from T_CAS_FundsMoveBill a
				          left join T_CAS_FeeType b on b.fid = a.CFFTDCLBID
				          --left join  T_ORG_Company c on c.fid = a.FCompanyID
				          left join T_BD_Project d on d.fid = a.CFFTPROJECTID --出
				          where 1=1 and a.FBillState >2 --取审批、结算状态
				          and a.FCompanyID = baseUnitID
				          and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') >= startDate -- startDate
				          and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') <= endDate-- endDate
				      )
				      pivot (
				      SUM(actPayAmt) for name in ('材料费' P材料费,'人工费' P人工费,'分包费' P分包费,'机械费' P机械费,'税金' P税金 ,'财务费用' P财务费用 ,'经营管理费用' P经营管理费用 ,'往来款' P往来款,'其他支出' P其他支出,'归还直接贷款' P归还直接贷款,'票据贴现到期还贷' P票据贴现到期还贷)
				      ) pay
				 ) pay    
				 group by projectname	

    ) actPay on  actPay.projectname = pro.projectname  --actRec. FProjectID = actPay.FProjectID and



left join 
   (
      select pro.projectname,pro.company ,
        /**
        nvl(init.CFEngineer,0) 工程款,nvl(init.CFPayee,0) 往来款,nvl(init.CFOTHERLOAN,0) 其他费用,nvl(init.CFLOAN,0) 直接贷款,nvl(init.CFDISCOUNT,0) 票据贴现,
        nvl(actRec.R工程款,0),nvl(actRec.R往来款,0),nvl(actRec.R其他收入,0),nvl(actRec.R直接贷款,0),nvl(actRec.R票据贴现,0),
        nvl(actPay.P材料费,0),nvl(actPay.P人工费,0),nvl(actPay.P分包费,0),nvl(actPay.P机械费,0),nvl(actPay.P税金 ,0),nvl(actPay.P财务费用 ,0),nvl(actPay.P经营管理费用 ,0),nvl(actPay.P往来款,0),nvl(actPay.P其他支出,0),nvl(actPay.P归还直接贷款,0),nvl(actPay.P票据贴现到期还贷,0),
        **/
        --工程款：= 初始化 + 之前所有的进 - P材料费~P经营管理费用
        (nvl(init.CFEngineer,0)+nvl(actRec.R工程款,0)) - (nvl(actPay.P材料费,0)+nvl(actPay.P人工费,0)+nvl(actPay.P分包费,0)+nvl(actPay.P机械费,0)+nvl(actPay.P税金 ,0)+nvl(actPay.P财务费用 ,0)+nvl(actPay.P经营管理费用 ,0)) 期初工程款,
        --往来款:= 初始化往来 + 之前所有进 - 支出
        nvl(init.CFPayee,0) + nvl(actRec.R往来款,0) - nvl(actPay.P往来款,0) 期初往来款,
        --其他费用:= 初始化 + 进 - 出
        nvl(init.CFOTHERLOAN,0) + nvl(actRec.R其他收入,0) - nvl(actPay.P其他支出,0) 期初其他费用,
        --直接贷款:= 初始化 + 进 - 出
        nvl(init.CFLOAN,0) + nvl(actRec.R直接贷款,0) - nvl(actPay.P归还直接贷款,0) 期初直接贷款,
        --票据贴现:= 初始化 + 进 - 支
        nvl(init.CFDISCOUNT,0) + nvl(actRec.R票据贴现,0) - nvl(actPay.P票据贴现到期还贷,0) 期初票据贴现

        from (
          select distinct b.fid FCompanyID,b.fname_l2 company,a.FProjectID,c.FNAME_L2 projectname from T_CAS_ReceivingBill a --收款单
			    left join t_org_company b on a.FCompanyID = b.fid
			    left join T_BD_Project c on a.FProjectID  = c.fid
			    where a.FProjectID is not null 
			    and a.FCompanyID = baseUnitID
			  union --付款单
			    select distinct b.fid companyId,b.fname_l2,a.FProjectID,c.FNAME_L2 from T_CAS_PaymentBill a 
			    left join t_org_company b on a.FCompanyID = b.fid
			    left join T_BD_Project c on a.FProjectID  = c.fid
			    where a.FProjectID is not null 
			    and a.FCompanyID = baseUnitID
			  union --关联代发单
			  	select distinct b.fid companyId,b.fname_l2,a.CFFTPROJECTID,c.FNAME_L2 from T_CAS_AgentPayBill a 
			    left join t_org_company b on a.FCompanyID = b.fid
			    left join T_BD_Project c on a.CFFTPROJECTID  = c.fid
			    where a.CFFTPROJECTID is not null 
			    and a.FCompanyID = baseUnitID
			  union --关联资金调拨单 调入
			  	select distinct b.fid companyId,b.fname_l2,a.CFDestProjectID,c.FNAME_L2 from T_CAS_FundsMoveBill a 
			    left join t_org_company b on a.FCompanyID = b.fid
			    left join T_BD_Project c on a.CFDestProjectID  = c.fid
			    where a.CFDestProjectID is not null 
			    and a.FCompanyID = baseUnitID 
			  union --关联资金调拨单 调出
			  	select distinct b.fid companyId,b.fname_l2,a.CFFTProjectID,c.FNAME_L2 from T_CAS_FundsMoveBill a 
			    left join t_org_company b on a.FCompanyID = b.fid
			    left join T_BD_Project c on a.CFFTProjectID  = c.fid
			    where a.CFFTProjectID is not null 
			    and a.FCompanyID = baseUnitID
        ) pro
        left join (
              /*之前所有的收入*/
              select projectname,
							sum(nvl(R工程款,0)) R工程款, 
							sum(nvl(R往来款,0)) R往来款,  
							sum(nvl(R其他收入,0)) R其他收入, 
							sum(nvl(R直接贷款,0)) R直接贷款, 
							sum(nvl(R票据贴现,0)) R票据贴现
							from (
					     select rec.* from (
	              select d.fname_l2 projectname,b.fname_l2 name,nvl(entry.FAmount,0) ACTRECAMT --c.fname_l2 company
	              from T_CAS_ReceivingBill a
	              left join T_CAS_ReceivingBillEntry entry on a.fid  = entry.FReceivingBillID
								left join T_BD_AccountView actview on actview.fid = entry.FOppAccountID 
								left join T_BD_AccountView actview2 on actview2.fid = a.FPayeeAccountID
	              left join T_CAS_FeeType b on b.fid = a.FFEETYPEID
	              --left join  T_ORG_Company c on c.fid = a.FCompanyID
	              left join T_BD_Project d on d.fid = a.FProjectID
	              where 1=1
	              and substr(nvl(actview.fnumber,'panda'),0,4) not in ('1001','1002','1003')
	              and substr(nvl(actview2.fnumber,'panda'),0,4) in ('1001','1002','1003')
	              and a.FCompanyID = baseUnitID
	              and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') >= '2019-08-01' -- 期初数据为7.31号的数据。
	              and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') < startDate-- 小于当前开始期间

	              )
	              pivot (
	               SUM(ACTRECAMT) for name in ('工程款' R工程款,'往来款' R往来款,'其他收入' R其他收入,'直接贷款' R直接贷款,'票据贴现' R票据贴现)
	              ) rec 

					      /*关联资金调拨单*/
						      union all
						       select rec.* from (
						          select d.fname_l2 projectname, b.fname_l2 name,nvl(a.FBuyAmount,0) ACTRECAMT 
						          from T_CAS_FundsMoveBill a
						          left join T_CAS_FeeType b on b.fid = a.CFFTDRLBID
						          --left join  T_ORG_Company c on c.fid = a.FCompanyID
						          left join T_BD_Project d on d.fid = a.CFDestProjectID --进
						          where 1=1 and a.FBillState >2 --取审批、结算状态
						          and a.FCompanyID = baseUnitID
						          and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') >= '2019-08-01' -- 期初数据为7.31号的数据。
	              			and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') < startDate-- 小于当前开始期间
						      )
						      pivot (
						      SUM(ACTRECAMT) for name in ('工程款' R工程款,'往来款' R往来款,'其他收入' R其他收入,'直接贷款' R直接贷款,'票据贴现' R票据贴现)
						      ) rec	
				      )   group by projectname
            )
            actRec on actRec.projectname = pro.projectname 

            left join (
            	/*8.1之前的支出*/
              select projectname,
							sum(nvl(P材料费,0)) P材料费, 
							sum(nvl(P人工费,0)) P人工费,  
							sum(nvl(P分包费,0)) P分包费, 
							sum(nvl(P机械费,0)) P机械费, 
							sum(nvl(P税金,0)) P税金,  
							sum(nvl(P财务费用,0)) P财务费用, 
							sum(nvl(P经营管理费用,0)) P经营管理费用, 
							sum(nvl(P往来款,0)) P往来款,  
							sum(nvl(P其他支出,0)) P其他支出, 
							sum(nvl(P归还直接贷款,0)) P归还直接贷款,
							sum(nvl(P票据贴现到期还贷,0)) P票据贴现到期还贷
							from (
									/*查询本期支出，包括代发单*/	
									select pay.* from (
                  select d.fname_l2 projectname,b.fname_l2 name,nvl(entry.FAmount,0) actPayAmt 
                  from T_CAS_PaymentBill a
                  left join T_CAS_PaymentBillEntry entry on a.fid  = entry.FPaymentBillID
									left join T_BD_AccountView actview on actview.fid = entry.FOppAccountID 
                  left join T_CAS_FeeType b on b.fid = a.FFEETYPEID
                  --left join  T_ORG_Company c on c.fid = a.FCompanyID
                  left join T_BD_Project d on d.fid = a.FProjectID
                  where 1=1
                  and substr(nvl(actview.fnumber,'panda'),0,4) not in ('1001','1002','1003')
                  and a.FCompanyID = baseUnitID
                  and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') >= '2019-08-01' -- 期初数据为7.31号的数据。
                	and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') < startDate-- 小于当前开始期间
		              )
		              pivot (
		              SUM(actPayAmt) for name in ('材料费' P材料费,'人工费' P人工费,'分包费' P分包费,'机械费' P机械费,'税金' P税金 ,'财务费用' P财务费用 ,'经营管理费用' P经营管理费用 ,'往来款' P往来款,'其他支出' P其他支出,'归还直接贷款' P归还直接贷款,'票据贴现到期还贷' P票据贴现到期还贷)
		              ) pay
							      union all 
							 			/*关联代发单*/	
							      select pay.* from (
							          select d.fname_l2 projectname, b.fname_l2 name,nvl(a.FActualAmount,0) actPayAmt 
							          from T_CAS_AgentPayBill a
							          left join T_CAS_FeeType b on b.fid = a.FFEETYPEID
							          --left join  T_ORG_Company c on c.fid = a.FCompanyID
							          left join T_BD_Project d on d.fid = a.CFFTPROJECTID
							          where 1=1 and a.FBillStatus = 15--取付款状态
							          and a.FCompanyID = baseUnitID
							         	and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') >= '2019-08-01' -- 期初数据为7.31号的数据。
                				and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') < startDate-- 小于当前开始期间
							      )
							      pivot (
							      SUM(actPayAmt) for name in ('材料费' P材料费,'人工费' P人工费,'分包费' P分包费,'机械费' P机械费,'税金' P税金 ,'财务费用' P财务费用 ,'经营管理费用' P经营管理费用 ,'往来款' P往来款,'其他支出' P其他支出,'归还直接贷款' P归还直接贷款,'票据贴现到期还贷' P票据贴现到期还贷)
							      ) pay

							      /*关联资金调拨单*/
							      union all
							       select pay.* from (
							          select d.fname_l2 projectname, b.fname_l2 name,nvl(a.FSellAmount,0) actPayAmt 
							          from T_CAS_FundsMoveBill a
							          left join T_CAS_FeeType b on b.fid = a.CFFTDCLBID
							          --left join  T_ORG_Company c on c.fid = a.FCompanyID
							          left join T_BD_Project d on d.fid = a.CFFTPROJECTID --出
							          where 1=1 and a.FBillState >2 --取审批、结算状态
							          and a.FCompanyID = baseUnitID
							          and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') >= '2019-08-01' -- 期初数据为7.31号的数据。
                				and TO_CHAR(A.FBIZDATE, 'YYYY-MM-DD') < startDate-- 小于当前开始期间
							      )
							      pivot (
							      SUM(actPayAmt) for name in ('材料费' P材料费,'人工费' P人工费,'分包费' P分包费,'机械费' P机械费,'税金' P税金 ,'财务费用' P财务费用 ,'经营管理费用' P经营管理费用 ,'往来款' P往来款,'其他支出' P其他支出,'归还直接贷款' P归还直接贷款,'票据贴现到期还贷' P票据贴现到期还贷)
							      ) pay
							 ) pay    
							 group by projectname	

            ) actPay on  actPay.projectname = pro.projectname  --actRec. FProjectID = actPay.FProjectID and

        left join 
        		(select b.* from T_BD_Project a 
        				left join CT_BE_ProjectInitBalance b on a.fid = b.FProjectID and b.CFIsEnabled = 1 ----启用
							where a.FCOMPANYID = baseUnitID)
             init  on init.FProjectID = pro.FProjectID 

        where pro.FCompanyID = baseUnitID
   ) init on init.projectname = pro.projectname
left join T_BD_Project dbpro on dbpro.fid = pro.FProjectID
left join T_ORG_Company org on org.fid = dbpro.FCompanyID

where pro.FCompanyID = baseUnitID   
order by org.fnumber,pro.projectnumber
;
end if;

--计算期末余额
update T_BE_BEProjectSummaryTemp set
COLUMN27 = (COLUMN3 + COLUMN9 ) -  (COLUMN15 + COLUMN16 + COLUMN17 + COLUMN18 + COLUMN19 + COLUMN20 + COLUMN21 ) ,--D1=A1+B1-C1-C2-C3-C4-C5-C6-C7
COLUMN28 = (COLUMN4 + COLUMN10) - COLUMN22 ,--D2=A2+B2-C8
COLUMN29 = (COLUMN5 + COLUMN11) - COLUMN23,--D3=A3+B3-C9
COLUMN30 = (COLUMN6 + COLUMN12 ) - COLUMN24,--D4=A4+B4-C10
COLUMN31 = (COLUMN7 + COLUMN13 ) - COLUMN25--D5=A5+B5-C11
;
update T_BE_BEProjectSummaryTemp set COLUMN32 = (COLUMN27 + COLUMN28 + COLUMN29 + COLUMN30 + COLUMN31) ;
commit;
end proc_calcBEProjectSummary;
/

