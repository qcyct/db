create view T_BAS_MULTIAPPROVEVIEW as
SELECT FID, FIsPass, FOpinion_L1, FOpinion_L2, FOpinion_L3, FHandlerOption, FHandlerContent, FBillID, FCreatorID, FCreateTime, FLastUpdateUserID, FLastUpdateTime, FBosType, FControlUnitID, FNEXTHANDLERPERSONID, FASSIGNMENTID, FSTATUS, FTYPE, FNUMBER, FIsMailNotifyNext, FIsMobelNotifyNext FROM T_BAS_MultiApprove UNION ALL SELECT FID, FIsPass, FOpinion_L1, FOpinion_L2, FOpinion_L3, FHandlerOption, FHandlerContent, FBillID, FCreatorID, FCreateTime, FLastUpdateUserID, FLastUpdateTime, FBosType, FControlUnitID, FNEXTHANDLERPERSONID, FASSIGNMENTID, FSTATUS, FTYPE, FNUMBER, FIsMailNotifyNext, FIsMobelNotifyNext FROM T_BAS_MultiApproveHst
/

