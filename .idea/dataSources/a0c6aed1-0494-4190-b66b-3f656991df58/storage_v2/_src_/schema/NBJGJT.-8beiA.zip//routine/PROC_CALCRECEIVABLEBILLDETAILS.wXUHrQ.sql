create procedure proc_calcReceivableBillDetails
(
companyNumber in varchar2 default '' ,
startDate in varchar2 default '',
endDate in varchar2 default ''
)
as
begin 
--清空缓存表
delete from T_NTReceivableBillDetailsTemp ;

  insert into T_NTReceivableBillDetailsTemp (COLUMN1,COLUMN2,COLUMN3,COLUMN4,COLUMN5,COLUMN6,COLUMN7,COLUMN8,COLUMN9,COLUMN10,COLUMN11,COLUMN12,COLUMN13,COLUMN14,COLUMN15,COLUMN16,COLUMN17,COLUMN18,COLUMN19,COLUMN20,COLUMN21,COLUMN22)
  select holder.fName_l2 holername,nttype.fname_l2 nttypename,
  case when bill.FBillMedium = 1 then '纸质' else '电子' end billMedium ,
  bill.FAcceptorName,bill.FDraftNumber,bill.FDrawerName,bill.FBillAmt,
  case when bill.fIsNoUsed=1 then '是' else '否' end IsNoUsed,
  case when endorse.FIsTransfer = 0 then '不可转让' else '可转让' end IsTransfer ,
  bill.FPeriod  ,TO_CHAR(bill.FIssuesDate, 'YYYY-MM-DD') IssuesDate,
  TO_CHAR(bill.FExpiredDate, 'YYYY-MM-DD') expiredDate,
  TO_CHAR(bill.FTakeDate, 'YYYY-MM-DD') takeDate,bill.FDeliverName,pro.fname_l2 proname,
  --保存=0,登记=1,审批=8,对内背书=7,对外背书=2,贴现=3,收款=4,作废=9,转贷款=10,入池质押=11,入池托管=12
  
  /**
  关于状态取数
  条件1、 收票日期 大于 结束日期，状态为 后期收票
  条件2、 收票日期 小于等于 结束日期，
   条件2.1 转出日期 小于等于 结束日期 直接显示状态
   条件2.2 转出日期 大于 结束日期 显示为登记 
  */
  
  --原始备份
  /**
  case bill.FBillState when  0 then '保存' when  1 then '登记' 
  when  8 then '审批' when  7 then '对内背书' when  2 then '对外背书' 
  when  3 then '贴现' when  4 then '收款' when  9 then '作废' 
  when  10 then '转贷款' when  11 then '入池质押' when  12 then '入池托管' 
  else '' end  as billState,
  **/
  
  case when TO_CHAR(bill.FTakeDate, 'YYYY-MM-DD') > endDate -- 条件1、 收票日期 大于 结束日期，状态为 后期收票
    then '后期收票'
  else 
    case when TO_CHAR(bill.FTransferDate, 'YYYY-MM-DD') > endDate  --条件2.1  转出日期 大于 结束日期 显示为登记
      then '登记'
    else        --转出日期 小于等于 结束日期 直接显示状态
      case bill.FBillState when  0 then '保存' when  1 then '登记' 
        when  8 then '审批' when  7 then '对内背书' when  2 then '对外背书' 
        when  3 then '贴现' when  4 then '收款' when  9 then '作废' 
        when  10 then '转贷款' when  11 then '入池质押' when  12 then '入池托管' 
        else '' end
    end  
  end as billState,
  
  TO_CHAR(bill.FTransferDate, 'YYYY-MM-DD') transferDate,
  endorse.FEndorsee,endorse.FDescription,
  disco.FDiscountRate,disco.FActDiscountInt,disco.FActRecvLocAmount
  from T_ORG_COMPANY org 
  left join T_NT_ReceivableBill bill on org.fid = bill.FCompanyID
  left join T_NT_NTType nttype on nttype.fid = bill.FNtTypeID--票据类型
  left join T_BD_Project pro on pro.fid = bill.fprojectid --工程项目
  left join T_NT_EndorsementBill endorse on endorse.fid = bill.FEndorseBillId --背书单
  left join T_NT_DiscountBill disco  on disco.fid = bill.FDiscountBillID --贴现单
  left join T_ORG_Company holder on holder.fid =  bill.FHolderID--关联执票人
  
  where 1=1 
  and substr(org.fnumber,0,length(companyNumber))=companyNumber --包括下级
--  and TO_CHAR(bill.FExpiredDate, 'YYYY-MM-DD') >= startDate -- startDate
  --and TO_CHAR(bill.FExpiredDate, 'YYYY-MM-DD') <= endDate-- endDate
  and TO_CHAR(bill.FTakeDate, 'YYYY-MM-DD') <= endDate --根据组织查询，然后收藏日期小于等于选择日期的数据
  order by holder.fnumber,bill.FExpiredDate
  ;
  
end proc_calcReceivableBillDetails;
/

