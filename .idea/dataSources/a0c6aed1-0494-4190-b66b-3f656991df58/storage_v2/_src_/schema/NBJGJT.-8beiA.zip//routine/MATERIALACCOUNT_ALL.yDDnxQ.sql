create procedure MaterialAccount_All(
v_projectorg in varchar2 default '' ,
v_billtypeInv in varchar2,
v_transtypeAdj in varchar2,
v_contractcosttypeid in varchar2,
v_enddate in varchar2) is
cursor cc is    select c.fname_l2 contractCostType,a.fcontractcosttypeid, a.fid contractID,a.fname contractName
from T_EC_ContractBill a
left outer join CT_BAS_ContractCostType c on c.fid=a.fcontractcosttypeid
left outer join T_BAS_ContractCostTypeTREE d on d.fid= c.ftreeid
where a.fprojectorgid=v_projectorg
and d.fnumber !='04' --非专业分包拆分合同
and a.fcontractclass='2'-- 合同类型 购销合同
and a.fcontractattribute='0' --合同性质  原始合同
and a.fcontractstatus in ('3','6','10') --合同状态 批准 签订 执行
and a.fcontractcosttypeid=v_contractcosttypeid ;

tt cc%rowtype;
v_endperiod date;
begin
  DELETE FROM  MaterialAccount_all_temp;
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;

  if v_enddate is not null then
    v_endperiod := to_date(v_enddate,'yyyyMMdd')+1;
  end if;

  --单合同材料合并
   MaterialAccount_All_contract(v_projectorg,tt.CONTRACTID,v_billtypeInv,v_transtypeAdj,v_endperiod);

  end loop;
  close cc;
  --插入零星材料
  insert into MaterialAccount_all_temp(materialid,Materialname,Unit,Mtqty,Mtamount)  select b.cfmaterialid,c.fname_l2,b.cfunit,b.cfquantity,b.cftaxinamount
         from ct_inv_sporadicmatreg a
         LEFT OUTER JOIN ct_inv_sporadicmatregentry b on a.fid=b.fparentid
         LEFT OUTER JOIN T_EC_ResourceItem c on c.fid=b.cfmaterialid
         where  a.cfbillstate='03'
         and a.cfprojectorgid=v_projectorg
         and b.cfcontractcosttype=v_contractcosttypeid
         and a.fbizdate<v_endperiod
         ;


end MaterialAccount_All;
/

