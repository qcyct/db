create procedure proc_calcBgActualData 
(
billID in varchar2 default '' ,
projectID in varchar2 default '' ,
proCostStructureID in varchar2 default '',
startDate in varchar2 default '',
endDate in varchar2 default '',
isClearData in varchar2 default '1'
)
as

longNumber nvarchar2(50);

begin

select SUBSTR(fnumber,length(fnumber)-1,length(fnumber))||'!' into longNumber from T_CS_PROCOSTSTRUCTURE where fid = proCostStructureID ;

--清空缓存表
delete from T_CS_BgDataSchema where fkey = billID and FPROJECTID = projectID  and FPROCOSTSTRUCTUREID = proCostStructureID;

if isClearData = '1' then
  delete from T_CS_BgDataSchemaTemp ;
end if;

delete from T_CS_BgDataSchemaTempSummary ;
commit;

--1、先保存明细数据，再汇总父节点更新 先算出本期
insert into T_CS_BgDataSchemaTempSummary ( fid,FKEY,FPROJECTORGID,FPROJECTID,FPROCOSTSTRUCTUREID,FProCostAccountID,FNumber,FName,flevel,FISLEAF,FLongNumber,FBgValue,FBgQty,FmBizActual,FmBgBalance,FmBizNonTaxActual,FmBgNonTaxBalance,FmQty)
--以成本科目为主表，分别查询对应的预算执行值
select a.fid, billID,a.FPROJECTORGID projectOrgID,a.FPROJECTID projectID,proCostStructureID, a.fid proCostAccount,
a.fnumber,a.fname_l2 fname,a.FLEVEL,a.fisLeaf,a.flongNumber ,
--nvl(b.BGVALUE,0) bgValue,nvl(b.bgQty,0) bgQty,
0 bgValue,0 bgQty,
nvl(act.actAmount,0) bizActual ,nvl(b.BGVALUE,0)-nvl(act.actAmount,0) BgBalance,nvl(act.actNonTaxAmount,0) BizNonTaxActual ,nvl(b.BGVALUE,0)-nvl(act.actNonTaxAmount,0) BgNonTaxBalance,nvl(act.qty,0) qty
from T_CS_PROCOSTACCOUNT a 
left join (
  --获取当前审核通过后的预算数据值
  select b.FPROCOSTACCOUNTID,sum(nvl(b.fbgvalue,0)) bgValue ,sum(nvl(b.FBGQTY,0)) bgQty from t_cs_bgform a left join t_cs_bgdata b on a.fid = b.fparentid 
  where 1=1 
    and a.FBillSate='03' 
    and b.FPROCOSTSTRUCTUREID = proCostStructureID 
    and a.FProjectID = projectID
  group by b.FPROCOSTACCOUNTID
) b on a.fid = b.FPROCOSTACCOUNTID

--执行预算数据扣减单据有：取含税金额及不含税金额
  --关联项目级成本科目：  材料运输合结算（CT_TRA_DevTransSettleBill），劳务协议结算 ，专业分包合同结算单（T_EC_ContractSettleBill），设备周村及租赁合同结算单
  --材料出库单（CT_INV_MatStockOut），零星材料登记，其他费用登记（是否统计成本），差旅及公司费用报销单（是否统计成本），排除特殊费用类型
left join (
    select FProCostAccountID,sum(nvl(actAmount,0)) actAmount,sum(nvl(actNonTaxAmount,0)) actNonTaxAmount,sum(nvl(qty,0)) qty from (
      --材料运输结算单
      select b.CFProCostAccountID FProCostAccountID,sum(nvl(b.CFAmount,0)) actAmount,sum(nvl(b.CFNonTaxAmount,0)) actNonTaxAmount,sum(nvl(b.CFQty,0)) qty from CT_TRA_DevTransSettleBill a 
      left join CT_TRA_DevTransSettleBillEntry b on a.fid = b.FParentID
      where a.CFBillSate >= '03' 
      and b.CFExpenseType = 0 --排除特殊费用类型
      and a.CFProjectID = projectID
      and b.CFPROCOSTSTRUCTURE = proCostStructureID 
      and to_char(a.FBizDate,'yyyy-mm-dd') >= startDate 
      and to_char(a.FBizDate,'yyyy-mm-dd') <= endDate 
      group by b.CFProCostAccountID
      
      union all
      --劳务协议结算,劳务清单结算是累计，这个可能会有Bug
      select a.CFProCostAccountID FProCostAccountID,sum(nvl(a.CFCurrTaxAmount,0)) actAmount,sum(nvl(a.CFCurrAmount,0)) actNonTaxAmount ,sum(nvl(b.CFCurrQty,0)) qty from CT_LAB_LabourSettleBill a
      left join CT_LAB_LabourSettleBillEntry b on a.fid = b.FParentID
      where a.CFBillSate >= '03' 
      and a.CFSettlementType = 1 --清单结算
      and a.CFProjectID = projectID
      and a.CFProCostStructure = proCostStructureID 
      and to_char(a.FBizDate,'yyyy-mm-dd') >= startDate 
      and to_char(a.FBizDate,'yyyy-mm-dd') <= endDate 
      group by a.CFProCostAccountID
      
      union all
      --劳务协议结算,月结算
      select b.CFProCostAccountID FProCostAccountID,sum(nvl(b.CFOriginalAmount,0)) actAmount,sum(nvl(b.CFNonTaxAmount,0)) actNonTaxAmount ,sum(nvl(b.CFQty,0)) qty from CT_LAB_LabourSettleBill a
      left join CT_LAB_LabourSettleBillMonths b on a.fid = b.FParentID
      where a.CFBillSate >= '03' 
      and a.CFSettlementType = 0 --月结算
      and b.CFExpenseType = 0 --特殊费用类型
      and a.CFProjectID = projectID
      and b.CFProCostStructure = proCostStructureID 
      and to_char(a.FBizDate,'yyyy-mm-dd') >= startDate 
      and to_char(a.FBizDate,'yyyy-mm-dd') <= endDate 
      group by b.CFProCostAccountID
      
      union all
      --专业分包合同结算单 T_EC_ContractSettleBill T_EC_ContractSettleEntry
      select b.FProCostAccountID FProCostAccountID,sum(nvl(b.FThisAmount,0)) actAmount,sum(nvl(b.CFNonTaxAmount,0)) actNonTaxAmount ,sum(nvl(b.FThisQty,0)) qty from T_EC_ContractSettleBill a
      left join T_EC_ContractSettleEntry b on a.fid = b.FSettleBillID 
      where a.FBillSate >= '03' 
      and b.CFExpenseType = 0 --特殊费用类型
      and a.FProjectID = projectID
      and b.FProCostStructureID = proCostStructureID 
      and to_char(a.FBizDate,'yyyy-mm-dd') >= startDate 
      and to_char(a.FBizDate,'yyyy-mm-dd') <= endDate 
      group by b.FProCostAccountID
      
      union all
      --专业分包合同结算单 T_EC_ContractSettleBill T_EC_ContractSettleItems
      select b.FProCostAccountID FProCostAccountID,sum(nvl(b.FThisAmount,0)) actAmount,sum(nvl(b.FNonTaxAmount,0)) actNonTaxAmount ,0 qty from T_EC_ContractSettleBill a
      left join T_EC_ContractSettleItems b on a.fid = b.FSettleBillID 
      where 1=1 
      and a.FBillSate >= '03' 
      and b.CFExpenseType = 0 --特殊费用类型
      and a.FProjectID = projectID
      and b.FProCostStructureID = proCostStructureID 
      and to_char(a.FBizDate,'yyyy-mm-dd') >= startDate 
      and to_char(a.FBizDate,'yyyy-mm-dd') <= endDate 
      group by b.FProCostAccountID
      
      union all
      --设备周村及租赁合同结算单
      select b.CFProCostAccountID FProCostAccountID,sum(nvl(b.CFAmount,0)) actAmount,sum(nvl(b.CFNonTaxAmount,0)) actNonTaxAmount ,sum(nvl(b.CFQty,0)) qty from CT_LB_LeaseSettleBill a 
      left join CT_LB_LeaseSettleBillEntry b on a.fid = b.FParentID
      where a.CFBillSate >= '03' 
      and b.CFExpenseType = 0 --排除特殊费用类型
      and a.CFProjectID = projectID
      and b.CFPROCOSTSTRUCTURE = proCostStructureID 
      and to_char(a.FBizDate,'yyyy-mm-dd') >= startDate 
      and to_char(a.FBizDate,'yyyy-mm-dd') <= endDate 
      group by b.CFProCostAccountID
      
      union all
      --租赁清单导入，没有税额
      select b.CFProCostAccountID FProCostAccountID,sum(nvl(b.CFAmount,0)) actAmount,sum(nvl(b.CFAmount,0)) actNonTaxAmount ,sum(nvl(b.CFQty,0)) qty from CT_LB_LeaseSettleBill a 
      left join CT_LB_LeaseSettleBillList b on a.fid = b.FParentID
      where a.CFBillSate >= '03' 
      and b.CFExpenseType = 0 --排除特殊费用类型
      and a.CFProjectID = projectID
      and b.CFPROCOSTSTRUCTURE = proCostStructureID 
      and to_char(a.FBizDate,'yyyy-mm-dd') >= startDate 
      and to_char(a.FBizDate,'yyyy-mm-dd') <= endDate 
      group by b.CFProCostAccountID
      
      union all
      --材料出库单（CT_INV_MatStockOut） 没有工程项目，只能通过工程项目取组织ID
      select b.CFProCostAccountID FProCostAccountID,sum(nvl(b.CFTaxinAmount,0)) actAmount,sum(nvl(b.CFNotaxAmount,0)) actNonTaxAmount ,sum(nvl(b.CFQty,0)) qty from CT_INV_MatStockOut a 
      left join CT_INV_MatStockOutEntry b on a.fid = b.FParentID
      where a.CFBillState >= '03' 
      and b.CFJGexpenseType = 0 --排除特殊费用类型
      -- @@and a.CFProjectID = '3K+CMEgqQ4KceiJpZ5YSOsgrxyQ='--projectID
      and a.CFProjectOrgID = (select distinct FProjectOrgID from T_EC_Project where fid = projectID)
      and b.CFProCostStructure = proCostStructureID 
      and to_char(a.FBizDate,'yyyy-mm-dd') >= startDate 
      and to_char(a.FBizDate,'yyyy-mm-dd') <= endDate 
      group by b.CFProCostAccountID
      
      union all
      --零星材料登记 CT_INV_SporadicMatReg
      select b.CFProCostAccountID FProCostAccountID,sum(nvl(b.CFTaxInAmount,0)) actAmount,sum(nvl(b.CFTAmount,0)) actNonTaxAmount ,sum(nvl(b.CFQuantity,0)) qty from CT_INV_SporadicMatReg a 
      left join CT_INV_SporadicMatRegEntry b on a.fid = b.FParentID
      where a.CFBillState >= '03' 
      and b.CFJGexpenseType = 0 --排除特殊费用类型
      and a.CFProjectID = projectID
      and b.CFProCostStructure = proCostStructureID 
      and to_char(a.FBizDate,'yyyy-mm-dd') >= startDate 
      and to_char(a.FBizDate,'yyyy-mm-dd') <= endDate 
      group by b.CFProCostAccountID
      
      union all
      --其他费用登记（是否统计成本）
      select b.CFProCostAccountID FProCostAccountID,sum(nvl(b.CFTaxInAmount,0)) actAmount,sum(nvl(b.CFTAmount,0)) actNonTaxAmount ,0 qty from CT_INV_OtherCostReg a 
      left join CT_INV_OtherCostRegEntry b on a.fid = b.FParentID
      where a.CFBillState >= '03' 
      and b.CFJGexpenseType = 0 --排除特殊费用类型
      and a.CFIfCost = 1 --是否统计成本
      and a.CFProjectOrgID = (select distinct FProjectOrgID from T_EC_Project where fid = projectID)
      and b.CFProCostStructure = proCostStructureID 
      and to_char(a.FBizDate,'yyyy-mm-dd') >= startDate 
      and to_char(a.FBizDate,'yyyy-mm-dd') <= endDate 
      group by b.CFProCostAccountID
      
      union all
      --差旅及公司费用报销单（是否统计成本）
      select b.CFProCostAccountID FProCostAccountID,sum(nvl(b.CFExpAmount,0)) actAmount,sum(nvl(b.CFExpAmount,0)) actNonTaxAmount ,0 qty from CT_EXP_ExpenseApply a 
      left join CT_EXP_ExpenseApplyEntry b on a.fid = b.FParentID
      where a.CFBillState >= '03' 
      and a.CFIfCost = 1 --是否统计成本
      and a.CFProjectOrgID = (select distinct FProjectOrgID from T_EC_Project where fid = projectID)
      and to_char(a.FBizDate,'yyyy-mm-dd') >= startDate 
      and to_char(a.FBizDate,'yyyy-mm-dd') <= endDate 
      group by b.CFProCostAccountID
    ) c  group by  FProCostAccountID
) act on act.FProCostAccountID = a.fid

where a.FProjectID = projectID
order by a.flongNumber
;

-- 2 计算累计
insert into T_CS_BgDataSchemaTempSummary ( fid,FKEY,FPROJECTORGID,FPROJECTID,FPROCOSTSTRUCTUREID,FProCostAccountID,FNumber,FName,flevel,FISLEAF,FLongNumber,FBgValue,FBgQty,FBizActual,FBgBalance,FBizNonTaxActual,FBgNonTaxBalance,FQty)
--以成本科目为主表，分别查询对应的预算执行值
select a.fid, billID,a.FPROJECTORGID projectOrgID,a.FPROJECTID projectID,proCostStructureID, a.fid proCostAccount,
a.fnumber,a.fname_l2 fname,a.FLEVEL,a.fisLeaf,a.flongNumber ,
nvl(b.BGVALUE,0) bgValue,nvl(b.bgQty,0) bgQty,
nvl(act.actAmount,0) bizActual ,nvl(b.BGVALUE,0)-nvl(act.actAmount,0) BgBalance,nvl(act.actNonTaxAmount,0) BizNonTaxActual ,nvl(b.BGVALUE,0)-nvl(act.actNonTaxAmount,0) BgNonTaxBalance,nvl(act.qty,0) qty
from T_CS_PROCOSTACCOUNT a 
left join (
  --获取当前审核通过后的预算数据值
  select b.FPROCOSTACCOUNTID,sum(nvl(b.fbgvalue,0)) bgValue,sum(nvl(b.fbgqty,0)) bgQty from t_cs_bgform a left join t_cs_bgdata b on a.fid = b.fparentid 
  where 1=1 
    and a.FBillSate='03' 
    and b.FPROCOSTSTRUCTUREID = proCostStructureID 
    and a.FProjectID = projectID
  group by b.FPROCOSTACCOUNTID
) b on a.fid = b.FPROCOSTACCOUNTID

--执行预算数据扣减单据有：取含税金额及不含税金额
  --关联项目级成本科目：  材料运输合结算（CT_TRA_DevTransSettleBill），劳务协议结算 ，专业分包合同结算单（T_EC_ContractSettleBill），设备周村及租赁合同结算单
  --材料出库单（CT_INV_MatStockOut），零星材料登记，其他费用登记（是否统计成本），差旅及公司费用报销单（是否统计成本），排除特殊费用类型
left join (
    select FProCostAccountID,sum(nvl(actAmount,0)) actAmount,sum(nvl(actNonTaxAmount,0)) actNonTaxAmount,sum(nvl(qty,0)) qty from (
      --材料运输结算单
      select b.CFProCostAccountID FProCostAccountID,sum(nvl(b.CFAmount,0)) actAmount,sum(nvl(b.CFNonTaxAmount,0)) actNonTaxAmount,sum(nvl(b.CFQty,0)) qty from CT_TRA_DevTransSettleBill a 
      left join CT_TRA_DevTransSettleBillEntry b on a.fid = b.FParentID
      where a.CFBillSate >= '03' 
      and b.CFExpenseType = 0 --排除特殊费用类型
      and a.CFProjectID = projectID
      and b.CFPROCOSTSTRUCTURE = proCostStructureID 
      --and to_char(a.FBizDate,'yyyy-mm-dd') >= startDate 
      --and to_char(a.FBizDate,'yyyy-mm-dd') <= endDate 
      group by b.CFProCostAccountID
      
      union all
      --劳务协议结算,劳务清单结算是累计，这个可能会有Bug
      select a.CFProCostAccountID FProCostAccountID,sum(nvl(a.CFCurrTaxAmount,0)) actAmount,sum(nvl(a.CFCurrAmount,0)) actNonTaxAmount ,sum(nvl(b.CFCurrQty,0)) qty from CT_LAB_LabourSettleBill a
      left join CT_LAB_LabourSettleBillEntry b on a.fid = b.FParentID
      where a.CFBillSate >= '03' 
      and a.CFSettlementType = 1 --清单结算
      and a.CFProjectID = projectID
      and a.CFProCostStructure = proCostStructureID 
      --and to_char(a.FBizDate,'yyyy-mm-dd') >= startDate 
      --and to_char(a.FBizDate,'yyyy-mm-dd') <= endDate 
      group by a.CFProCostAccountID
      
      union all
      --劳务协议结算,月结算
      select b.CFProCostAccountID FProCostAccountID,sum(nvl(b.CFOriginalAmount,0)) actAmount,sum(nvl(b.CFNonTaxAmount,0)) actNonTaxAmount ,sum(nvl(b.CFQty,0)) qty from CT_LAB_LabourSettleBill a
      left join CT_LAB_LabourSettleBillMonths b on a.fid = b.FParentID
      where a.CFBillSate >= '03' 
      and a.CFSettlementType = 0 --月结算
      and b.CFExpenseType = 0 --特殊费用类型
      and a.CFProjectID = projectID
      and b.CFProCostStructure = proCostStructureID 
      --and to_char(a.FBizDate,'yyyy-mm-dd') >= startDate 
      --and to_char(a.FBizDate,'yyyy-mm-dd') <= endDate 
      group by b.CFProCostAccountID
      
      union all
      --专业分包合同结算单 T_EC_ContractSettleBill T_EC_ContractSettleEntry
      select b.FProCostAccountID FProCostAccountID,sum(nvl(b.FThisAmount,0)) actAmount,sum(nvl(b.CFNonTaxAmount,0)) actNonTaxAmount ,sum(nvl(b.FThisQty,0)) qty from T_EC_ContractSettleBill a
      left join T_EC_ContractSettleEntry b on a.fid = b.FSettleBillID 
      where a.FBillSate >= '03' 
      and b.CFExpenseType = 0 --特殊费用类型
      and a.FProjectID = projectID
      and b.FProCostStructureID = proCostStructureID 
      --and to_char(a.FBizDate,'yyyy-mm-dd') >= startDate 
      --and to_char(a.FBizDate,'yyyy-mm-dd') <= endDate 
      group by b.FProCostAccountID
      
      union all
      --专业分包合同结算单 T_EC_ContractSettleBill T_EC_ContractSettleItems
      select b.FProCostAccountID FProCostAccountID,sum(nvl(b.FThisAmount,0)) actAmount,sum(nvl(b.FNonTaxAmount,0)) actNonTaxAmount ,0 qty from T_EC_ContractSettleBill a
      left join T_EC_ContractSettleItems b on a.fid = b.FSettleBillID 
      where 1=1 
      and a.FBillSate >= '03' 
      and b.CFExpenseType = 0 --特殊费用类型
      and a.FProjectID = projectID
      and b.FProCostStructureID = proCostStructureID 
      --and to_char(a.FBizDate,'yyyy-mm-dd') >= startDate 
      --and to_char(a.FBizDate,'yyyy-mm-dd') <= endDate 
      group by b.FProCostAccountID
      
      union all
      --设备周村及租赁合同结算单
      select b.CFProCostAccountID FProCostAccountID,sum(nvl(b.CFAmount,0)) actAmount,sum(nvl(b.CFNonTaxAmount,0)) actNonTaxAmount ,sum(nvl(b.CFQty,0)) qty from CT_LB_LeaseSettleBill a 
      left join CT_LB_LeaseSettleBillEntry b on a.fid = b.FParentID
      where a.CFBillSate >= '03' 
      and b.CFExpenseType = 0 --排除特殊费用类型
      and a.CFProjectID = projectID
      and b.CFPROCOSTSTRUCTURE = proCostStructureID 
      --and to_char(a.FBizDate,'yyyy-mm-dd') >= startDate 
      --and to_char(a.FBizDate,'yyyy-mm-dd') <= endDate 
      group by b.CFProCostAccountID
      
      union all
      --租赁清单导入，没有税额
      select b.CFProCostAccountID FProCostAccountID,sum(nvl(b.CFAmount,0)) actAmount,sum(nvl(b.CFAmount,0)) actNonTaxAmount ,sum(nvl(b.CFQty,0)) qty from CT_LB_LeaseSettleBill a 
      left join CT_LB_LeaseSettleBillList b on a.fid = b.FParentID
      where a.CFBillSate >= '03' 
      and b.CFExpenseType = 0 --排除特殊费用类型
      and a.CFProjectID = projectID
      and b.CFPROCOSTSTRUCTURE = proCostStructureID 
      --and to_char(a.FBizDate,'yyyy-mm-dd') >= startDate 
      --and to_char(a.FBizDate,'yyyy-mm-dd') <= endDate 
      group by b.CFProCostAccountID
      
      union all
      --材料出库单（CT_INV_MatStockOut） 没有工程项目，只能通过工程项目取组织ID
      select b.CFProCostAccountID FProCostAccountID,sum(nvl(b.CFTaxinAmount,0)) actAmount,sum(nvl(b.CFNotaxAmount,0)) actNonTaxAmount ,sum(nvl(b.CFQty,0)) qty from CT_INV_MatStockOut a 
      left join CT_INV_MatStockOutEntry b on a.fid = b.FParentID
      where a.CFBillState >= '03' 
      and b.CFJGexpenseType = 0 --排除特殊费用类型
      -- @@and a.CFProjectID = '3K+CMEgqQ4KceiJpZ5YSOsgrxyQ='--projectID
      and a.CFProjectOrgID = (select distinct FProjectOrgID from T_EC_Project where fid = projectID)
      and b.CFProCostStructure = proCostStructureID 
      --and to_char(a.FBizDate,'yyyy-mm-dd') >= startDate 
      --and to_char(a.FBizDate,'yyyy-mm-dd') <= endDate 
      group by b.CFProCostAccountID
      
      union all
      --零星材料登记 CT_INV_SporadicMatReg
      select b.CFProCostAccountID FProCostAccountID,sum(nvl(b.CFTaxInAmount,0)) actAmount,sum(nvl(b.CFTAmount,0)) actNonTaxAmount ,sum(nvl(b.CFQuantity,0)) qty from CT_INV_SporadicMatReg a 
      left join CT_INV_SporadicMatRegEntry b on a.fid = b.FParentID
      where a.CFBillState >= '03' 
      and b.CFJGexpenseType = 0 --排除特殊费用类型
      and a.CFProjectID = projectID
      and b.CFProCostStructure = proCostStructureID 
      --and to_char(a.FBizDate,'yyyy-mm-dd') >= startDate 
      --and to_char(a.FBizDate,'yyyy-mm-dd') <= endDate 
      group by b.CFProCostAccountID
      
      union all
      --其他费用登记（是否统计成本）
      select b.CFProCostAccountID FProCostAccountID,sum(nvl(b.CFTaxInAmount,0)) actAmount,sum(nvl(b.CFTAmount,0)) actNonTaxAmount ,0 qty from CT_INV_OtherCostReg a 
      left join CT_INV_OtherCostRegEntry b on a.fid = b.FParentID
      where a.CFBillState >= '03' 
      and b.CFJGexpenseType = 0 --排除特殊费用类型
      and a.CFIfCost = 1 --是否统计成本
      and a.CFProjectOrgID = (select distinct FProjectOrgID from T_EC_Project where fid = projectID)
      and b.CFProCostStructure = proCostStructureID 
      --and to_char(a.FBizDate,'yyyy-mm-dd') >= startDate 
      --and to_char(a.FBizDate,'yyyy-mm-dd') <= endDate 
      group by b.CFProCostAccountID
      
      union all
      --差旅及公司费用报销单（是否统计成本）
      select b.CFProCostAccountID FProCostAccountID,sum(nvl(b.CFExpAmount,0)) actAmount,sum(nvl(b.CFExpAmount,0)) actNonTaxAmount ,0 qty from CT_EXP_ExpenseApply a 
      left join CT_EXP_ExpenseApplyEntry b on a.fid = b.FParentID
      where a.CFBillState >= '03' 
      and a.CFIfCost = 1 --是否统计成本
      and a.CFProjectOrgID = (select distinct FProjectOrgID from T_EC_Project where fid = projectID)
      --and to_char(a.FBizDate,'yyyy-mm-dd') >= startDate 
      --and to_char(a.FBizDate,'yyyy-mm-dd') <= endDate 
      group by b.CFProCostAccountID
    ) c  group by  FProCostAccountID
) act on act.FProCostAccountID = a.fid

where a.FProjectID = projectID
order by a.flongNumber
;

--3 合并数据
insert into T_CS_BgDataSchemaTemp ( fid,FKEY,FPROJECTORGID,FPROJECTID,FPROCOSTSTRUCTUREID,FProCostAccountID,FNumber,FName,flevel,FISLEAF,FLongNumber,FBgValue,FbgQty,FBizActual,FBgBalance,FBizNonTaxActual,FBgNonTaxBalance,FQty,FmBizActual,FmBgBalance,FmBizNonTaxActual,FmBgNonTaxBalance,FmQty)
select fid,FKEY,FPROJECTORGID,FPROJECTID,FPROCOSTSTRUCTUREID,FProCostAccountID,FNumber,FName,flevel,FISLEAF,FLongNumber,
  sum(nvl(a.FBGVALUE,0)) bgvalue,sum(nvl(a.FbgQty,0)) bgQty, sum(nvl(a.FBIZACTUAL,0)) BIZACTUAL,sum(nvl(a.FBGBALANCE,0)) BGBALANCE , sum(nvl(a.FBizNonTaxActual,0)) FBizNonTaxActual ,sum(nvl(a.FBgNonTaxBalance,0)) FBgNonTaxBalance ,sum(nvl(a.FQty,0)) FQty ,
  sum(nvl(a.FmBIZACTUAL,0)) mBIZACTUAL,sum(nvl(a.FmBGBALANCE,0)) mBGBALANCE , sum(nvl(a.FmBizNonTaxActual,0)) FmBizNonTaxActual ,sum(nvl(a.FmBgNonTaxBalance,0)) FmBgNonTaxBalance ,sum(nvl(a.FmQty,0)) FmQty  
from T_CS_BgDataSchemaTempSummary a
group by fid,FKEY,FPROJECTORGID,FPROJECTID,FPROCOSTSTRUCTUREID,FProCostAccountID,FNumber,FName,flevel,FISLEAF,FLongNumber ;

--4、汇总出上级所有数据
--先用层次查询查出树形结构，要想统计一个节点下的汇总，需要用到connect_by_root，同一个节点下的connect_by_root是一样的，然后再group by。
insert into T_CS_BgDataSchema ( fid,FKEY,FPROJECTID,FPROJECTORGID,FPROCOSTSTRUCTUREID,FProCostAccountID,FNumber,FName,flevel,FISLEAF,FLongNumber,FBgValue,FBgQty,FBizActual,FBgBalance,FBizNonTaxActual,FBgNonTaxBalance,FQty,FmBizActual,FmBgBalance,FmBizNonTaxActual,FmBgNonTaxBalance,FmQty)
with temp as (
  select a.FPROCOSTACCOUNTID,b.fnumber,b.rootid,b.flongnumber,b.fisleaf,nvl(a.FBGVALUE,0) bgvalue,nvl(a.FBGqty,0) bgqty,
  nvl(a.FBIZACTUAL,0) BIZACTUAL,nvl(a.FBGBALANCE,0) BGBALANCE , nvl(a.FBizNonTaxActual,0) FBizNonTaxActual ,nvl(a.FBgNonTaxBalance,0) FBgNonTaxBalance ,nvl(a.FQty,0) FQty ,
  nvl(a.FmBIZACTUAL,0) mBIZACTUAL,nvl(a.FmBGBALANCE,0) mBGBALANCE , nvl(a.FmBizNonTaxActual,0) FmBizNonTaxActual ,nvl(a.FmBgNonTaxBalance,0) FmBgNonTaxBalance ,nvl(a.FmQty,0) FmQty 
  from T_CS_BgDataSchemaTemp a
  left join (
      select b.fid,connect_by_root(b.fid) rootid,b.fnumber,b.flongnumber,b.fisleaf
      from T_CS_PROCOSTACCOUNT b 
      left join T_CS_PROCOSTACCOUNT c on c.fid = b.cfparentid
      --start with b.FPROJECTID = projectID
      connect by prior b.fid = b.CFPARENTID
      order by b.flongnumber
  )  b on b.fid = a.FPROCOSTACCOUNTID
 
  where a.FPROCOSTSTRUCTUREID = proCostStructureID
  order by b.flongnumber
),temp1 as (select rootid,sum(bgvalue) bgvalue,sum(bgqty) bgqty,sum(BIZACTUAL) BIZACTUAL,sum(BGBALANCE) BGBALANCE,sum(FBizNonTaxActual) FBizNonTaxActual,sum(FBgNonTaxBalance) FBgNonTaxBalance,sum(FQty) FQty ,
                                              sum(mBIZACTUAL) mBIZACTUAL,sum(mBGBALANCE) mBGBALANCE,sum(FmBizNonTaxActual) FmBizNonTaxActual,sum(FmBgNonTaxBalance) FmBgNonTaxBalance,sum(FmQty) FMQty 
            from temp where fisleaf <> 0 group by rootid),
temp3 as ( ----加上temp3纯粹是为了阅读方便
  select d.fid,
  cast(lpad(' ', level * 2 - 1) || d.fname_l2 as varchar2(500)) fname,d.fnumber,d.flevel,d.FISLEAF,d.FPROJECTORGID,
  d.flongnumber
  from T_CS_PROCOSTACCOUNT d
  start with d.CFPARENTID is null
  connect by prior d.fid = d.CFPARENTID
)
select newbosid('168E44B9'),billID,projectID,t3.FPROJECTORGID,proCostStructureID, t3.fid,t3.fnumber,t3.fname,t3.flevel,t3.FISLEAF,t3.FLongNumber,t1.bgvalue ,t1.bgqty ,
      t1.BIZACTUAL,t1.BGBALANCE,t1.FBizNonTaxActual,t1.FBgNonTaxBalance,t1.FQty,
      t1.mBIZACTUAL,t1.mBGBALANCE,t1.FmBizNonTaxActual,t1.FmBgNonTaxBalance,t1.FmQty
from temp1 t1
left join temp3 t3 on t1.rootid = t3.fid
order by t3.flongnumber
;

--5 关联更新预算数据，只更新父节点
UPDATE T_CS_BgDataSchemaTemp a
  set  (FBGVALUE,FBGQTY,FBIZACTUAL,FBGBALANCE,FBizNonTaxActual,FBgNonTaxBalance,FQty,
                FmBIZACTUAL,FmBGBALANCE,FmBizNonTaxActual,FmBgNonTaxBalance,FmQty) 
      = 
      (select b.FBGVALUE,b.FBGQTY,b.FBIZACTUAL,b.FBGBALANCE,FBizNonTaxActual,FBgNonTaxBalance,FQty,
                        b.FmBIZACTUAL,b.FmBGBALANCE,FmBizNonTaxActual,FmBgNonTaxBalance,FmQty
        from T_CS_BgDataSchema b
        where b.FPROCOSTACCOUNTID = a.FPROCOSTACCOUNTID)
  where exists (select 1
    from T_CS_BgDataSchema b
    where b.FPROCOSTACCOUNTID = a.FPROCOSTACCOUNTID and b.fisleaf=0
  )
  and a.FPROJECTID = projectID 
  and a.FKEY = billID
  and a.FPROCOSTSTRUCTUREID = proCostStructureID
  ;

-- 6 设置科目级别自动下降一级,并添加部位为上级节点
update T_CS_BgDataSchemaTemp set flevel = flevel+1,FLongNumber = longNumber||FLongNumber where FPROCOSTSTRUCTUREID=proCostStructureID  and FPROJECTID = projectID;
insert into T_CS_BgDataSchemaTemp ( fid,FKEY,FPROJECTORGID,FPROJECTID,FPROCOSTSTRUCTUREID,FProCostAccountID,FNumber,FName,flevel,FISLEAF,FLongNumber,FBgValue,FBgQty,FBizActual,FBgBalance,FBizNonTaxActual,FBgNonTaxBalance,FQty,FmBizActual,FmBgBalance,FmBizNonTaxActual,FmBgNonTaxBalance,FmQty)
select fid,billID FKEY,FPROJECTORGID,projectID,fid,null,FNumber,FNAME_L2,1,0,longNumber,1,1,0,0,0,0,0,0,0,0,0,0 from T_CS_PROCOSTSTRUCTURE where fid = proCostStructureID;

--清空缓存表
delete from T_CS_BgDataSchema where fkey = billID and FPROJECTID = projectID  and FPROCOSTSTRUCTUREID = proCostStructureID;

commit;
end proc_calcBgActualData;
/

