create procedure proc_calcReceivableBillSum
(
companyNumber in varchar2 default '' ,
startDate in varchar2 default '',
endDate in varchar2 default ''
)
as
begin 
--清空缓存表
delete from T_NTReceivableBillSumTemp ;
delete from t_ntreceivablebillsumkey ;

--构建主表
insert into t_ntreceivablebillsumkey (companyid,companyname,nttypeid,nttypename,billmediumid,billmediumname)
select * from 
(select fid companyId,FNAME_L2 组织名称 from T_ORG_Company
  where  substr(fnumber,0,length(companyNumber))=companyNumber )a ,--包括下级
(select  fid nttypeid,FNAME_L2 票据种类 from T_NT_NTType where FSUPERGROUP=4) b,
(
select 1,'纸质' 票据类型 from dual
UNION
select 2,'电子' from dual
) billtype
order by 组织名称,票据种类,票据类型
;

insert into T_NTReceivableBillSumTemp (COLUMN1,COLUMN2,COLUMN3,COLUMN4,COLUMN5,COLUMN6,COLUMN7,COLUMN8,COLUMN9,COLUMN10,COLUMN11,COLUMN12,COLUMN13,COLUMN14,COLUMN15,COLUMN16,COLUMN17,COLUMN18,COLUMN19,COLUMN20)
select org.companyname, org.nttypename,org.billmediumname,
  nvl(init1.billamt,0) - nvl(init2.billamt,0) ,nvl(curMonthEX.billamt,0)-nvl(curMonthIN.billamt,0) wbamt,nvl(curMonthIN.billamt,0) nbamt,
  nvl(curMonthHold.billamt,0),nvl(curMonthTranEX.billamt,0),nvl(curMonthTranIN.billamt,0),nvl(curMonthDisc.billamt,0),nvl(curMonthDiscWb.billamt,0) curDiscWb ,0,
  nvl(totTranEx.billamt,0),nvl(totDiscEx.billamt,0),
  nvl(totTranIN1.billamt,0) - nvl(totTranIN2.billamt,0) - nvl(totTranIN3.billamt,0) tottranin,nvl(totTranIN2.billamt,0) - nvl(totTranIN4.billamt,0) ,nvl(totTranIN4.billamt,0),0,'',''

from t_ntreceivablebillsumkey org 

left join 
(
	-- 条件1 收票日期小于开始日期的部分
	select FCompanyID,FNtTypeID,FBillMedium,sum(FBillAmt) billamt from  T_NT_ReceivableBill bill 
	where  FCompanyID in (select distinct companyid from t_ntreceivablebillsumkey)
	  and TO_CHAR(bill.FTakeDate, 'YYYY-MM-DD') < startDate -- endDate
	group by FCompanyID,FNtTypeID,FBillMedium
) init1 on org.companyid = init1.FCompanyID and org.nttypeid = init1.FNtTypeID and org.billmediumid = init1.FBillMedium



left join
(
	--条件2 转出日期小于开始日期的部分
	select FCompanyID,FNtTypeID,FBillMedium,sum(FBillAmt) billamt from  T_NT_ReceivableBill bill 
	where  FCompanyID in (select distinct companyid from t_ntreceivablebillsumkey)
	  and TO_CHAR(bill.FTransferDate, 'YYYY-MM-DD') < startDate-- endDate
	group by FCompanyID,FNtTypeID,FBillMedium
) init2 on org.companyid = init2.FCompanyID and org.nttypeid = init2.FNtTypeID and org.billmediumid = init2.FBillMedium

left join 
(
	--本月外部收入
	--本月外部收入	条件1 应收票据表中，收票日期在时间范围内			条件1-条件2
	--条件2：内部收入			

	select FCompanyID,FNtTypeID,FBillMedium,sum(FBillAmt) billamt from  T_NT_ReceivableBill bill 
	where  FCompanyID in (select distinct companyid from t_ntreceivablebillsumkey)
	  and TO_CHAR(bill.FTakeDate, 'YYYY-MM-DD') >= startDate -- startDate
	  and TO_CHAR(bill.FTakeDate, 'YYYY-MM-DD') <= endDate -- endDate
	group by FCompanyID,FNtTypeID,FBillMedium
) curMonthEX on org.companyid = curMonthEX.FCompanyID and org.nttypeid = curMonthEX.FNtTypeID and org.billmediumid = curMonthEX.FBillMedium

left join 
(
	--本月内部收入 本月内部收入	背书单中被背书公司为当前组织,关联应收票据获取票据类型信息，背书日期在时间范围内的数据				

	select a.FEndorsedCompanyID FCompanyID,bill.FNtTypeID,bill.FBillMedium,sum(bill.FBillAmt) billamt from T_NT_EndorsementBill  a 
	left join T_NT_ReceivableBill bill on a.fid = bill.FEndorseBillId
	where  a.FEndorsedCompanyID in (select distinct companyid from t_ntreceivablebillsumkey)
	  and TO_CHAR(a.FEndorseDate, 'YYYY-MM-DD') >= startDate -- startDate
	  and TO_CHAR(a.FEndorseDate, 'YYYY-MM-DD') <= endDate -- endDate
	group by a.FEndorsedCompanyID,bill.FNtTypeID,bill.FBillMedium
) curMonthIN on org.companyid = curMonthIN.FCompanyID and org.nttypeid = curMonthIN.FNtTypeID and org.billmediumid = curMonthIN.FBillMedium

left join 
(
	--保存=0,登记=1,审批=8,对内背书=7,对外背书=2,贴现=3,收款=4,作废=9,转贷款=10,入池质押=11,入池托管=12
	--本月持票到期兑付 应收票据收款查询中本月收款的票据金额合计。
	select FCompanyID,FNtTypeID,FBillMedium,sum(FBillAmt) billamt from  T_NT_ReceivableBill bill 
	where  FCompanyID in (select distinct companyid from t_ntreceivablebillsumkey)
	  and FBillState=4
	  and TO_CHAR(bill.FTransferDate, 'YYYY-MM-DD') >= startDate -- startDate
	  and TO_CHAR(bill.FTransferDate, 'YYYY-MM-DD') <= endDate-- endDate
	group by FCompanyID,FNtTypeID,FBillMedium
) curMonthHold on org.companyid = curMonthHold.FCompanyID and org.nttypeid = curMonthHold.FNtTypeID and org.billmediumid = curMonthHold.FBillMedium

left join
(
	--本月转让（外部） 应收票据背书查询中本月对外背书的票据金额合计。
	select FCompanyID,FNtTypeID,FBillMedium,sum(FBillAmt) billamt from  T_NT_ReceivableBill bill 
	where  FCompanyID in (select distinct companyid from t_ntreceivablebillsumkey)
	  and FBillState=2
	  and TO_CHAR(bill.FTransferDate, 'YYYY-MM-DD') >= startDate -- startDate
	  and TO_CHAR(bill.FTransferDate, 'YYYY-MM-DD') <= endDate-- endDate
	group by FCompanyID,FNtTypeID,FBillMedium
) curMonthTranEX on org.companyid = curMonthTranEX.FCompanyID and org.nttypeid = curMonthTranEX.FNtTypeID and org.billmediumid = curMonthTranEX.FBillMedium

left join
(
	--本月转让（内部） 应收票据背书查询中本月对内背书的票据金额合计。
	select FCompanyID,FNtTypeID,FBillMedium,sum(FBillAmt) billamt from  T_NT_ReceivableBill bill 
	where  FCompanyID in (select distinct companyid from t_ntreceivablebillsumkey)
	  and FBillState=7
	  and TO_CHAR(bill.FTransferDate, 'YYYY-MM-DD') >= startDate -- startDate
	  and TO_CHAR(bill.FTransferDate, 'YYYY-MM-DD') <= endDate-- endDate
	group by FCompanyID,FNtTypeID,FBillMedium
) curMonthTranIN on org.companyid = curMonthTranIN.FCompanyID and org.nttypeid = curMonthTranIN.FNtTypeID and org.billmediumid = curMonthTranIN.FBillMedium

left join 
(

	--本月贴现（默认为外部贴现） 应收票据贴现查询中本月贴现的票据金额合计。
	select FCompanyID,FNtTypeID,FBillMedium,sum(FBillAmt) billamt from  T_NT_ReceivableBill bill 
	where  FCompanyID in (select distinct companyid from t_ntreceivablebillsumkey)
	  and FBillState=3
	  and TO_CHAR(bill.FTransferDate, 'YYYY-MM-DD') >= startDate -- startDate
	  and TO_CHAR(bill.FTransferDate, 'YYYY-MM-DD') <= endDate-- endDate
	group by FCompanyID,FNtTypeID,FBillMedium
) curMonthDisc on org.companyid = curMonthDisc.FCompanyID and org.nttypeid = curMonthDisc.FNtTypeID and org.billmediumid = curMonthDisc.FBillMedium

left join 
(
	--内部贴现：背书单当前组织下，背书日期在范围内，且被背书人等于结算中心 ，摘要包含 贴现 
	select a.FCOMPANYID FCompanyID,bill.FNtTypeID,bill.FBillMedium,sum(bill.FBillAmt) billamt from T_NT_EndorsementBill  a 
	left join T_NT_ReceivableBill bill on a.fid = bill.FEndorseBillId
	where  a.FEndorsedCompanyID ='mbUAAAALkZLM567U' --结算中心 这里表示，所有背书给结算中心的票据
	 and a.FDESCRIPTION like '%贴现%'
	 and a.FCOMPANYID in (select distinct companyid from t_ntreceivablebillsumkey) --这里表示当前组织的票
	 and TO_CHAR(a.FEndorseDate, 'YYYY-MM-DD') > endDate-- endDate
	 and TO_CHAR(a.FEndorseDate, 'YYYY-MM-DD') <= endDate-- endDate --转出日期 小于等于 结束日期
	group by a.FCOMPANYID,bill.FNtTypeID,bill.FBillMedium
) curMonthDiscWb on org.companyid = curMonthDiscWb.FCompanyID and org.nttypeid = curMonthDiscWb.FNtTypeID and org.billmediumid = curMonthDiscWb.FBillMedium

left join 
(
	--累计未到期外部转出 应收票据背书查询中累计对外背书，且到期日为当日之后（不包含当日）的金额合计。
	select FCompanyID,FNtTypeID,FBillMedium,sum(FBillAmt) billamt from  T_NT_ReceivableBill bill 
	where  FCompanyID in (select distinct companyid from t_ntreceivablebillsumkey)
	  and FBillState=2
	  and TO_CHAR(bill.FExpiredDate, 'YYYY-MM-DD') > endDate-- endDate
	group by FCompanyID,FNtTypeID,FBillMedium
) totTranEx on org.companyid = totTranEx.FCompanyID and org.nttypeid = totTranEx.FNtTypeID and org.billmediumid = totTranEx.FBillMedium

left join
(
	--累计未到期外部贴现 应收票据贴现查询中累计贴现，且到期日为当日之后（不包含当日）的金额合计
	select FCompanyID,FNtTypeID,FBillMedium,sum(FBillAmt) billamt from  T_NT_ReceivableBill bill 
	where  FCompanyID in (select distinct companyid from t_ntreceivablebillsumkey)
	  and FBillState=3
	  and TO_CHAR(bill.FExpiredDate, 'YYYY-MM-DD') > endDate-- endDate
	group by FCompanyID,FNtTypeID,FBillMedium
) totDiscEx on org.companyid = totDiscEx.FCompanyID and org.nttypeid = totDiscEx.FNtTypeID and org.billmediumid = totDiscEx.FBillMedium

left join 
(
	--累计未到期内部转出（不含结算中心） 应收票据背书查询中累计对内背书，
	--且到期日为当日之后（不包含当日）的金额且不包含内部背书给结算中心的金额; 转出日期 小于等于 结束日期
	--减去收到的背书单且到期日为当日之后的合计金额之差。
	--条件1 -条件2 -条件3
	-- 对内背书条件1 
	select FCompanyID,FNtTypeID,FBillMedium,sum(FBillAmt) billamt from  T_NT_ReceivableBill bill 
	where  FCompanyID in (select distinct companyid from t_ntreceivablebillsumkey)
	  and FBillState=7 --对内背书=7
	  and TO_CHAR(bill.FExpiredDate, 'YYYY-MM-DD') > endDate-- endDate
	  and TO_CHAR(bill.FTransferDate, 'YYYY-MM-DD') <= endDate-- endDate --转出日期 小于等于 结束日期
	group by FCompanyID,FNtTypeID,FBillMedium
) totTranIN1 on org.companyid = totTranIN1.FCompanyID and org.nttypeid = totTranIN1.FNtTypeID and org.billmediumid = totTranIN1.FBillMedium

left join 
(
	--应收票据-到期日>结束时间并票据关联背书单-被 背书人全称 为结算中心 （不勾选收到的背书单）
	--条件2
	select a.FCOMPANYID FCompanyID,bill.FNtTypeID,bill.FBillMedium,sum(bill.FBillAmt) billamt from T_NT_EndorsementBill  a 
	left join T_NT_ReceivableBill bill on a.fid = bill.FEndorseBillId
	where  a.FEndorsedCompanyID ='mbUAAAALkZLM567U' --结算中心 这里表示，所有背书给结算中心的票据
	 and a.FCOMPANYID in (select distinct companyid from t_ntreceivablebillsumkey) --这里表示当前组织的票
	 and TO_CHAR(bill.FExpiredDate, 'YYYY-MM-DD') > endDate-- endDate
	 and TO_CHAR(bill.FTransferDate, 'YYYY-MM-DD') <= endDate-- endDate --转出日期 小于等于 结束日期
	group by a.FCOMPANYID,bill.FNtTypeID,bill.FBillMedium
) totTranIN2 on org.companyid = totTranIN2.FCompanyID and org.nttypeid = totTranIN2.FNtTypeID and org.billmediumid = totTranIN2.FBillMedium

left join 
(
	--应收票据-到期日>结束时间并票据关联背书单状态勾选收到的背书单
	--条件3
	select a.FEndorsedCompanyID FCompanyID,bill.FNtTypeID,bill.FBillMedium,sum(bill.FBillAmt) billamt from T_NT_EndorsementBill  a 
	left join T_NT_ReceivableBill bill on a.fid = bill.FEndorseBillId
	where  a.FEndorsedCompanyID in (select distinct companyid from t_ntreceivablebillsumkey) --勾选 收到的背书单
	 and TO_CHAR(bill.FExpiredDate, 'YYYY-MM-DD') > endDate-- endDate
	 and TO_CHAR(bill.FTakeDate, 'YYYY-MM-DD') <= endDate-- endDate --收票日期 小于等于 结束日期
	group by a.FEndorsedCompanyID,bill.FNtTypeID,bill.FBillMedium
) totTranIN3 on org.companyid = totTranIN3.FCompanyID and org.nttypeid = totTranIN3.FNtTypeID and org.billmediumid = totTranIN3.FBillMedium

left join 
(
	--累计未到期内部贴现：背书单当前组织下，背书日期在范围内，且被背书人等于结算中心 ，摘要包含 贴现 
	select a.FCOMPANYID FCompanyID,bill.FNtTypeID,bill.FBillMedium,sum(bill.FBillAmt) billamt from T_NT_EndorsementBill  a 
	left join T_NT_ReceivableBill bill on a.fid = bill.FEndorseBillId
	where  a.FEndorsedCompanyID ='mbUAAAALkZLM567U' --结算中心 这里表示，所有背书给结算中心的票据
	 and a.FDESCRIPTION like '%贴现%'
	 and a.FCOMPANYID in (select distinct companyid from t_ntreceivablebillsumkey) --这里表示当前组织的票
	  and TO_CHAR(bill.FExpiredDate, 'YYYY-MM-DD') > endDate-- endDate
	 and TO_CHAR(bill.FTransferDate, 'YYYY-MM-DD') <= endDate-- endDate --转出日期 小于等于 结束日期
	group by a.FCOMPANYID,bill.FNtTypeID,bill.FBillMedium
) totTranIN4 on org.companyid = totTranIN4.FCompanyID and org.nttypeid = totTranIN4.FNtTypeID and org.billmediumid = totTranIN4.FBillMedium

--内部转让给结算中心 =  应收票据条件2 totTranIN2 - 累计未到期内部贴现 totTranIN4

order by org.companyname,org.nttypename,org.billmediumid
;

--累计未到期内部转让给结算中心 应收票据-到期日>结束时间并票据关联背书单-被 背书人全称 为结算中心 （条件2）
/**
select a.FEndorsedCompanyID,bill.FNtTypeID,bill.FBillMedium,sum(bill.FBillAmt) billamt from T_NT_EndorsementBill  a 
left join T_NT_ReceivableBill bill on a.fid = bill.FEndorseBillId
where  a.FEndorsedCompanyID ='mbUAAAALkZLM567U' --结算中心
 and TO_CHAR(bill.FExpiredDate, 'YYYY-MM-DD') > endDate-- endDate
group by a.FEndorsedCompanyID,bill.FNtTypeID,bill.FBillMedium
;
**/

--计算合计行
update T_NTReceivableBillSumTemp set 
	COLUMN12 = (nvl(COLUMN4,0) + nvl(COLUMN5,0) + nvl(COLUMN6,0)) - (nvl(COLUMN7,0) + nvl(COLUMN8,0) + nvl(COLUMN9,0) + nvl(COLUMN10,0)  + nvl(COLUMN11,0) ) --(456-78910 11)
;

update T_NTReceivableBillSumTemp set 
	COLUMN18 =  nvl(COLUMN13,0) + nvl(COLUMN14,0) + nvl(COLUMN15,0) + nvl(COLUMN16,0) + nvl(COLUMN17,0) -- 13~17
;

delete T_NTReceivableBillSumTemp where COLUMN12 = 0 and COLUMN18 = 0 ;

commit;

end proc_calcReceivableBillSum;
/

