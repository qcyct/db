create view V_PERSONACCOUNT as
SELECT A.FID,a.fnumber
,max(decode(d1.fnumber||c1.fnumber,'Insu001Base_insu',d.FVALUE,null)) as Insu001Base_insu
,max(decode(d1.fnumber||c1.fnumber,'Insu001Emp_insu',d.FVALUE,null)) as Insu001Emp_insu
,max(decode(d1.fnumber||c1.fnumber,'Insu001Com_insu',d.FVALUE,null)) as Insu001Com_insu
,max(decode(d1.fnumber||c1.fnumber,'Insu002Base_insu',d.FVALUE,null)) as Insu002Base_insu
,max(decode(d1.fnumber||c1.fnumber,'Insu002Emp_insu',d.FVALUE,null)) as Insu002Emp_insu
,max(decode(d1.fnumber||c1.fnumber,'Insu002Com_insu',d.FVALUE,null)) as Insu002Com_insu
,max(decode(d1.fnumber||c1.fnumber,'Insu003Base_insu',d.FVALUE,null)) as Insu003Base_insu
,max(decode(d1.fnumber||c1.fnumber,'Insu003Emp_insu',d.FVALUE,null)) as Insu003Emp_insu
,max(decode(d1.fnumber||c1.fnumber,'Insu003Com_insu',d.FVALUE,null)) as Insu003Com_insu
,max(decode(d1.fnumber||c1.fnumber,'Insu006Base_insu',d.FVALUE,null)) as Insu006Base_insu
,max(decode(d1.fnumber||c1.fnumber,'Insu006Emp_insu',d.FVALUE,null)) as Insu006Emp_insu
,max(decode(d1.fnumber||c1.fnumber,'Insu006Com_insu',d.FVALUE,null)) as Insu006Com_insu
FROM T_BD_Person A 
left join T_HR_Account b on a.fid=b.FPERSONID --取人员账号
left join T_HR_AccountDetail c on b.fid=c.FAccountID--取人员账号明细
left join T_HR_AccountItemInput d on d.FAccountDetailID=c.fid --通过明细账号ID关联基数数据
left join T_HR_Item b1 on b1.fid=d.FItemID --关联险种
left join T_HR_Benefit d1 on d1.fid=b1.FBenefitID --险种
left join T_HR_BenefitItem c1 on c1.fid=b1.FItemID --险种项目
where c.FPayState=10 and c.FAccountTypeID='c4VJVwEbEADgA1iZChZiAok/9WQ=' --and a.fnumber='00131'--FPayState	账户缴纳状态	正常缴纳=10,停止缴纳=20,封存=30
group by A.FID,a.fnumber
/

