create procedure AssessProjectSummary_Main(
v_CompanyOrgID in varchar2 default '' ) is
cursor cc is    select distinct d.cfprojectorgid projectorgid from  CT_ASS_AssessProject d
where d.cfcompanyorgid=v_CompanyOrgID ;

tt cc%rowtype;
v_billstate NVARCHAR2(44);
v_ProjectOrgID NVARCHAR2(44);
v_ProjManagerAct NVARCHAR2(44);
v_CreateTime timestamp(6);
v_BizDate timestamp(6);
v_ProjCapitalClass NVARCHAR2(44);
v_ProjectState NVARCHAR2(44);
v_ContractCost NUMERIC(20,6);
v_Constartdate timestamp(6);
v_Confinishdate timestamp(6);
v_FinishValueSum NUMERIC(20,6);
v_ConfirmValueSum NUMERIC(20,6);
v_ConReceivePercent NUMERIC(20,6);
v_ReceivableAmountSum NUMERIC(20,6);
v_ActRecAmountSum NUMERIC(20,6);
v_UnRecAmount NUMERIC(20,6);
v_TotCostSum NUMERIC(20,6);
v_TotPaySum NUMERIC(20,6);
v_ActUnPaySum NUMERIC(20,6);
v_LoanBalanceSum NUMERIC(20,6);
v_SkczPC NUMERIC(20,6);
v_SkqrczPC NUMERIC(20,6);
v_ZccbPC NUMERIC(20,6);
v_ZcskPC NUMERIC(20,6);
v_WlPC NUMERIC(20,6);
v_YeczPC NUMERIC(20,6);
v_CbczPC NUMERIC(20,6);
v_engineerdepscore NUMERIC(20,6);
v_financedepscore NUMERIC(20,6);
v_costdepscore NUMERIC(20,6);
v_hrdepscore NUMERIC(20,6);
v_lawdepscore NUMERIC(20,6);
v_totscorcsum NUMERIC(20,6);
v_scorechecked number(10); 
begin
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;
  v_ContractCost := 0;
  v_FinishValueSum := 0;
  v_ConfirmValueSum := 0;
  v_ConReceivePercent := 0;
  v_ReceivableAmountSum := 0;
  v_ActRecAmountSum := 0;
  v_UnRecAmount := 0;
  v_TotCostSum := 0;
  v_TotPaySum := 0;
  v_ActUnPaySum := 0;
  v_LoanBalanceSum := 0;
  v_SkczPC := 0;
  v_SkqrczPC := 0;
  v_ZccbPC := 0;
  v_ZcskPC := 0;
  v_WlPC := 0;
  v_YeczPC := 0;
  v_CbczPC := 0;


   select  aa.CFProjectOrgID,aa.CFProjManagerAct,aa.fcreatetime,aa.fbizdate,aa.CFProjCapitalClass,aa.CFProjectState,
                  nvl(aa.CFContractCost,0) ,aa.CFConstartdate ,aa.CFConfinishdate ,nvl(aa.CFFinishValueSum,0) ,nvl(aa.CFConfirmValueSum,0),nvl(aa.CFConReceivePercent,0),
                  nvl(aa.CFReceivableAmountSum,0) ,nvl(aa.CFActRecAmountSum,0) ,nvl(aa.CFTotCostSum,0) ,nvl(aa.CFTotPaySum,0) ,
                  nvl(aa.CFLoanBalanceSum,0) ,nvl(aa.CFSkczPC,0) ,nvl(aa.CFSkqrczPC,0) ,nvl(aa.CFZccbPC,0) ,nvl(aa.CFZcskPC,0) ,nvl(aa.CFWlPC,0),nvl(aa.CFYeczPC,0) ,nvl(aa.CFCbczPC,0),
                  aa.cfbillstate,aa.Cfengineerdepscore,aa.Cffinancedepscore,aa.Cfcostdepscore,aa.Cfhrdepscore,aa.Cflawdepscore,aa.Cftotscorcsum, nvl(aa.Cfscorechecked,0)
           into v_ProjectOrgID,v_ProjManagerAct,v_CreateTime,v_BizDate,v_ProjCapitalClass,v_ProjectState,
                  v_ContractCost ,v_Constartdate ,v_Confinishdate , v_FinishValueSum ,v_ConfirmValueSum,v_ConReceivePercent,
                  v_ReceivableAmountSum ,v_ActRecAmountSum ,v_TotCostSum ,v_TotPaySum ,
                  v_LoanBalanceSum ,v_SkczPC ,v_SkqrczPC ,v_ZccbPC ,v_ZcskPC ,v_WlPC,v_YeczPC ,v_CbczPC,v_billstate,
                  v_engineerdepscore,v_financedepscore,v_costdepscore,v_hrdepscore,v_lawdepscore,v_totscorcsum,v_scorechecked
   from (
           select d.cfcompanyorgid,d.cfprojectorgid,d.Cfprojmanageract,d.fcreatetime,d.fbizdate,d.cfprojcapitalclass,d.Cfprojectstate,
                  d.Cfcontractcost,d.cfconstartdate,d.cfconfinishdate, d.Cffinishvaluesum,d.Cfconfirmvaluesum,d.Cfconreceivepercent,
                  d.Cfreceivableamountsum,d.Cfactrecamountsum,d.Cftotcostsum,d.Cftotpaysum,
                  d.Cfloanbalancesum,d.Cfskczpc,d.Cfskqrczpc,d.Cfzccbpc,d.Cfzcskpc,d.Cfwlpc,d.Cfyeczpc,d.Cfcbczpc,d.cfbillstate,
                  d.Cfengineerdepscore,d.Cffinancedepscore,d.Cfcostdepscore,d.Cfhrdepscore,d.Cflawdepscore,d.Cftotscorcsum,
                  d.Cfscorechecked
                  from CT_ASS_AssessProject d
                  where d.cfcompanyorgid=v_CompanyOrgID and d.cfprojectorgid=tt.projectorgid
                  order by d.fbizdate desc) aa
    where rownum=1;
    v_UnRecAmount:=v_ReceivableAmountSum-v_ActRecAmountSum;
    v_ActUnPaySum:=v_TotCostSum-v_TotPaySum;

   insert into AssessProjectSummary_temp(CFCompanyOrgID,Cfprojectorgid,Cfprojmanageract,Cfcreatetime,Cfbizdate,Cfprojcapitalclass,Cfprojectstate,Cfcontractcost,Cfconstartdate,Cfconfinishdate,
                  Cffinishvaluesum,Cfconfirmvaluesum,Cfconreceivepercent,Cfreceivableamountsum,Cfactrecamountsum,Cfunrecamount,Cftotcostsum,Cftotpaysum,Cfactunpaysum,Cfloanbalancesum,Cfskczpc,
                  Cfskqrczpc,Cfzccbpc, Cfzcskpc,Cfwlpc,Cfyeczpc,Cfcbczpc,Cfbillstate,Cfengineerdepscore,Cffinancedepscore,Cfcostdepscore,Cfhrdepscore,Cflawdepscore,Cftotscorcsum,Cfscorechecked)
               values(v_CompanyOrgID,v_ProjectOrgID,v_ProjManagerAct,v_CreateTime,v_BizDate,v_ProjCapitalClass,v_ProjectState,v_ContractCost,v_Constartdate,v_Confinishdate,v_FinishValueSum,
                  v_ConfirmValueSum,v_ConReceivePercent,v_ReceivableAmountSum,v_ActRecAmountSum,v_UnRecAmount,v_TotCostSum,v_TotPaySum,v_ActUnPaySum,v_LoanBalanceSum,v_SkczPC,v_SkqrczPC,v_ZccbPC,
                  v_ZcskPC,v_WlPC,v_YeczPC,v_CbczPC,v_billstate,v_engineerdepscore,v_financedepscore,v_costdepscore,v_hrdepscore,v_lawdepscore,v_totscorcsum,v_scorechecked);

  end loop;
  close cc;

end AssessProjectSummary_Main;
/

