create procedure JGCustomer_Assign_batch(
v_csinfoID in varchar2 ) is
cursor cc is   select  cfcontrolunitorgid cuorgid from CT_SPB_SupplierAssignOrg;

tt cc%rowtype;
v_cuid varchar2(44); 
i integer;
begin
  v_cuid:='00000000-0000-0000-0000-000000000000CCE7AED4';     
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;
  
  --基础资料分配记录 客户bostype BF0C040E
  select count(fid) into i from t_bd_databasedassign where fdatabasedid=v_csinfoID and fassigncuid=tt.cuorgid and FControlUnitID=v_cuid ;
  if i=0 then
    insert into t_bd_databasedassign(fid,fdatabasedid,fassigncuid,fbosobjecttype,FControlUnitID) 
							 values (newbosid('BF0C040E'),v_csinfoID,tt.cuorgid,'BF0C040E' ,v_cuid) ;
  end if;

  --客户财务信息   bostype  7751B8D7 
  select count(fid) into i from T_BD_CustomerCompanyInfo  where fcomorgid=tt.cuorgid and Fcontrolunitid=tt.cuorgid and Fcustomerid=v_csinfoID ;
  if i=0 then         
     insert into T_BD_CustomerCompanyInfo  (fid,fcomorgid,Fsettlementcurrencyid,Feffectedstatus,Fusingstatus,Fcontrolunitid,
    				     Fcreatorid,Fcreatetime,Flastupdateuserid,Flastupdatetime,Fcustomerid  )
    				     values (newbosid('7751B8D7'),tt.cuorgid,'dfd38d11-00fd-1000-e000-1ebdc0a8100dDEB58FDC','2','0', 
    				     tt.cuorgid ,'256c221a-0106-1000-e000-10d7c0a813f413B7DE7F',systimestamp,
                 '256c221a-0106-1000-e000-10d7c0a813f413B7DE7F',systimestamp,v_csinfoID );            
  end if;      
  
  end loop;
  close cc;
end JGCustomer_Assign_batch;
/

