create PROCEDURE PROC_TRANSFORMINVOICEAPI 
(	
	isSyncHead in varchar2 default '0'
)
AS 
BEGIN

MERGE INTO CT_II_InvoiceBill a --发票池中的发票
USING T_API_INVOICEBILL b  --临时发票数据
ON ( a.CFINVOICETYPECODE=b.CFinvoiceTypeCode 
    and a.CFINVOICENUMBER=b.CFinvoiceNumber)
WHEN MATCHED THEN
    update  set a.CFBillStatus=b.CFBillStatus,--更新发票状态
    a.CFisAuth = b.CFIsAuth,--如果认证日期为空取原值不更新，不为空取1，表示已认证
    -- a.CFauthType = DECODE(b.FAuthType,NULL,-1,b.FAuthType), --认证方式 ,如果为空，默认为-1 未认证，不为空取更新后的状态 0:扫描认证            1:系统推送（勾选认证）            2:不予退税
    a.CFauthDate = TO_DATE(b.FAUTHDATE, 'YYYY-MM-DD HH24:MI:SS'), --DECODE(b.FAuthDate,NULL,a.CFauthDate,TO_DATE(b.FAuthDate, 'YYYY-MM-DD HH24:MI:SS')),--认证日期
    --a.CFAuthMonth = b.CFAuthMonth, -- DECODE(b.FAuthMonth,NULL,a.CFAuthMonth,b.FAuthMonth), --认证月份
    --a.CFCHECKSTATUS = b.CFCheckStatus,--nvl(b.FCHECKSTATUS,0) ,--勾选状态 0 未勾选
    --a.FCHECKDATE = TO_DATE( b.FCHECKDATE, 'YYYY-MM-DD HH24:MI:SS'),--DECODE(b.FCHECKDATE,NULL,a.FCHECKDATE,TO_DATE(b.FCHECKDATE, 'YYYY-MM-DD HH24:MI:SS')) ,--勾选日期
    --a.FGOODSNAME = b.FGoodsName, -- 货物名称
    --a.FTAXRATE = b.CFBillTaxRate, -- 税率
    --a.CFINVOICEBASETYPE = b.CFInvoiceBaseType, -- 发票类型	String	2	是	增值税专用发票：01 机动车销售统一发票：03 通行费电子发票：14
    a.CFAUTHMODE = b.FAuthMode , --认证类型	String	1	否	0-未抵扣 1-抵扣 2-退税 3-代 理退税 4-不抵扣
    a.CFISDBTS = b.FIsDbts ,-- 是否代办退税	String	1	否	0-否 1-是
    a.CFMANAGERTYPE = nvl(b.CFManagerType,0) --管理状态 0:正常            1:非正常

   -- where b.CFINVOICEBASETYPE = '01'
   --WHEN NOT MATCHED THEN --添加只针对单表，不适合用于有分录的数据
   -- INSERT (column_list) VALUES (column_values)    
;

if isSyncHead = '0' then 
-- 1 表示状态更新，0 表示全表更新
--获取新发票数据 
--临时表 与比较 发票池表 的增量差异，取增量部分 不用ID是因为ID每次动态生成
DELETE T_MINUS_InvoiceBill;
INSERT /*+ append */ INTO T_MINUS_InvoiceBill(FinvoiceTypeCode,FinvoiceNumber)
select CFinvoiceTypeCode,CFinvoiceNumber from T_API_INVOICEBILL 
minus 
SELECT CFINVOICETYPECODE,CFINVOICENUMBER FROM CT_II_InvoiceBill;
commit;

--insert head
INSERT /*+ append */ INTO CT_II_InvoiceBill nologging (FID,FCREATORID,FCREATETIME,FLASTUPDATEUSERID,FLASTUPDATETIME,FCONTROLUNITID,FNUMBER,FBIZDATE,CFNAME,CFBILLSATE,CFINVOICETYPEID,CFINVOICENUMBER,CFINVOICEDATE,CFINVOICETYPECODE,cfpurchaseName,CFPDUTYCODE,CFPADDRESSTELL,CFPBANKACCOUNT,CFSDUTYCODE,CFSADDRESSTELL,CFSBANKACCOUNT,CFTOTAMOUNT,CFNONTAXAMOUNT,CFTAX,CFEXPIREDATE,CFAUTHTYPE,CFINVOICEUNIT,CFUNPAYAMOUNT,CFPAYAMOUNT,CFISAUTH,CFBILLSTATUS,CFCapTotAmout,cfispayreq,CFauthDate,CFAuthMonth,CFTransfer,CFIsSplit,cfisDirectPay ,FTAXRATE,CFCOUNT,CFCHECKSTATUS,FCHECKDATE,CFMANAGERTYPE,CFINVOICEBASETYPE,CFAUTHMODE,CFISDBTS,CFACTTAX,CFIsSyncDetail )
SELECT  FID,'256c221a-0106-1000-e000-10d7c0a813f413B7DE7F',sysdate,'256c221a-0106-1000-e000-10d7c0a813f413B7DE7F',sysdate,'c4VJVwEbEADgAE/0ChZiAsznrtQ=',a.CFINVOICENUMBER,TO_DATE(FInvoiceDate, 'YYYY-MM-DD HH24:MI:SS'),CFINVOICEUNIT,'00','mbUAAAAiFq7NeSoF',a.CFINVOICENUMBER,TO_DATE(FInvoiceDate, 'YYYY-MM-DD HH24:MI:SS'),a.CFINVOICETYPECODE,CFPURCHASENAME,CFPDUTYCODE,CFPADDRESSTELL,CFPBANKACCOUNT,CFSDUTYCODE,CFSADDRESSTELL,CFSBANKACCOUNT,CFTOTAMOUNT,FNONTAXAMOUNT,FTax,TO_DATE(FInvoiceDate, 'YYYY-MM-DD HH24:MI:SS')+365,1 FAuthType,CFINVOICEUNIT,CFTOTAMOUNT,0,CFISAUTH,a.CFBILLSTATUS,money_to_chinese(CFTOTAMOUNT),0,TO_DATE(FAUTHDATE, 'YYYY-MM-DD HH24:MI:SS'),a.CFAUTHMONTH,0,0,0,CFBILLTAXRATE,1,a.CFCHECKSTATUS,TO_DATE(a.FCHECKDATE, 'YYYY-MM-DD HH24:MI:SS'),a.cFMANAGERTYPE,a.CFINVOICEBASETYPE,a.FAUTHMODE,a.FISDBTS,a.FACTTAX,a.CFIsSyncDetail  FROM T_API_INVOICEBILL a
inner join  T_MINUS_InvoiceBill panda on panda.FinvoiceTypeCode=a.cFinvoiceTypeCode and panda.FinvoiceNumber=a.CFINVOICENUMBER 
--where a.CFINVOICEBASETYPE='01' or a.CFINVOICEBASETYPE='03'
;

--insert entrys
INSERT /*+ append */ INTO CT_II_INVOICEBILLENTRY(FSEQ, FID, FPARENTID, CFQTY, CFPRICE, CFAMOUNT, CFBILLTAXRATE, CFTAX,CFTaxInAmount,CFNAME, CFCARTYPE, CFCARNO, CFSTARTDATE ,CFENDDATE )
SELECT FSEQ,FID, FPARENTID, CFQTY ,CFPRICE,CFAMOUNT, CFBILLTAXRATE, CFTAX,CFTAXINAMOUNT,CFNAME,CFCARTYPE,CFCARNO, TO_DATE(CFSTARTDATE, 'YYYY-MM-DD HH24:MI:SS'),TO_DATE(CFENDDATE, 'YYYY-MM-DD HH24:MI:SS') FROM T_API_INVOICEBILLENTRY 
where FPARENTID in 
(select a.fid from T_API_INVOICEBILL a inner join  T_MINUS_InvoiceBill panda on panda.FinvoiceTypeCode=a.cFinvoiceTypeCode and panda.FinvoiceNumber=a.CFINVOICENUMBER 
    --where a.CFINVOICEBASETYPE='01'
) ;

commit;

end if;


update ct_ii_invoicebill set  CFUNPAYAMOUNT = CFTOTAMOUNT,CFPAYAMOUNT = 0 where CFUNPAYAMOUNT is null ;--处理存在未付款金额数据

--处理勾选了，状态更新掉归属期问题
update ct_ii_invoicebill set  CFAUTHMONTH = to_char(FCHECKDATE,'yyyymm') where FCHECKDATE is not null  and CFAUTHMONTH is null ;


--状态更新掉归属期问题，有归属期，未勾选状态
update ct_ii_invoicebill set  FCHECKDATE = CFauthDate,CFCHECKSTATUS=CFisAuth
where CFauthDate is not null  and FCHECKDATE is null ;


commit;

END PROC_TRANSFORMINVOICEAPI;
/

