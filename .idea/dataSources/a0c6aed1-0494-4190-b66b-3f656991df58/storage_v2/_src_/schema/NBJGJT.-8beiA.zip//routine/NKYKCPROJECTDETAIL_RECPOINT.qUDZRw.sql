create procedure NkyKCProjectDetail_recPoint(
v_contractid in varchar2 default '' ,
v_receivePoint out varchar2) is
cursor cc is   select g.cfreceivepoint  from  Ct_Kc_Nkyownercontractentry g where g.fparentid=v_contractid order by g.fseq asc ;

tt cc%rowtype;
v_seqNum integer;
begin
  v_seqNum:= 1;
  v_receivePoint:=null;
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;

       v_receivePoint:=v_receivePoint||chr(10)||chr(13)||v_seqNum||'. '||tt.cfreceivepoint;
        v_seqNum:= v_seqNum+1;

  end loop;
  close cc;

end NkyKCProjectDetail_recPoint;
/

