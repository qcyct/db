create FUNCTION bosuuid2new (oldbosid VARCHAR2) RETURN VARCHAR2
IS
guid RAW(32);
s_guid VARCHAR2(32);
g_hex VARCHAR(22);
typeString VARCHAR(8);
BEGIN
IF LENGTH(oldbosid) = 44 THEN
DBMS_OUTPUT.put_line('oldbosid is '|| LENGTH(oldbosid));
g_hex :='0123456789ABCDEFabcdef';
s_guid := REPLACE(SUBSTR(oldbosid,1,36),'-','');
guid := HEXTORAW(s_guid);
typeString := SUBSTR(oldbosid,37,8);
FOR i IN 1 .. 8 LOOP
IF INSTR(g_hex,SUBSTR(typeString,i,1),1,1) = 0 THEN
GOTO old_form;
END IF;
END LOOP;
RETURN UTL_RAW.cast_to_varchar2(UTL_ENCODE.base64_encode(UTL_RAW.CONCAT(guid,HEXTORAW(typeString))));
END IF;
<<old_form>>
RETURN oldbosid;
END;

/

