create PACKAGE GetResultSetPACKAGE AS
  TYPE ResultSet_CURSOR IS REF CURSOR;
end GetResultSetPACKAGE;

/

