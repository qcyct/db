create view INVPERIOD as
select a.fid FID, b.fnumber 项目组织编号,b.FNAME_L2 项目组织名称, c.fnumber 项目编号,c.FNAME_L2 项目名称,d.fnumber 期间,f.fname_l2 供应商,e.fnumber 物料编号,e.FNAME_L2 物料名称, 
finbeginqty 期初入库数量, finbeginamount 期初入库金额, foutbeginqty 期初出库数量, foutbeginamount 期初出库金额, finqty 本期入库数量, finamount 本期入库金额, foutqty 本期出库数量, 
foutamount 本期出库金额, finendqty 期末入库累计数量, finendamount 期末入库累计金额, foutendqty 期末出库累计数量, foutendamount 期末出库累计金额，a.FQTY 结余数量，a.FAmount 结余金额
from t_inv_invperiodclose a
left join T_ORG_Transport b on b.fid=a.fprojectorgid
LEFT JOIN T_EC_Project c on c.fid=a.fprojectid
LEFT JOIN T_BD_Period d on d.fid=a.fperiodid
LEFT JOIN T_EC_ResourceItem e on e.fid=a.fmaterialid
LEFT JOIN T_BD_Supplier f on f.fid=a.FSUPPLIERID
/

