create procedure mat_inaccountrpt_perAmount(
v_projectorg in varchar2 default '' ,
v_billtypeInv in varchar2,
v_billtypeAdj in varchar2,
v_transtypeAdj in varchar2,
v_contract in varchar2,
v_supplier in varchar2,
v_startperiod in NUMBER,
v_endperiod in NUMBER,
v_matid in varchar,
v_MATERIALNUMBER in varchar,
v_MATERIALNAME in varchar,
v_MEASUREUNITNAME in varchar,
v_startqty in NUMBER,
v_startamount in NUMBER,
v_serino in out integer) is

TYPE cc_type is REF CURSOR ;
cc cc_type;
v_insql varchar2(2000);
v_adjsql varchar2(2000);
v_totsql varchar2(4000);
v_PERIODNUMBER varchar2(60);
v_ENTRYSQTY number(28,10);
v_ENTRYSPRICE number(28,10);
v_ENTRYSAMOUNT number(28,10);
v_SUPPLIERNAME varchar2(255);
v_CONTRACTNAME varchar2(255);
v_BILLTYPENAME varchar2(255);
v_FNUMBER varchar2(255);
v_BIZDATE timestamp(6);
v_perqty number(28,10);
v_peramount number(28,10);
v_peraprice number(28,10);
v_totqty number(28,10);
v_totamount number(28,10);
v_totaprice number(28,10);

begin
  v_insql:= 'SELECT  PERIOD.FNumber  PERIODNUMBER,ENTRYS.FQty  ENTRYSQTY,ENTRYS.FPrice  ENTRYSPRICE,ENTRYS.FAmount  ENTRYSAMOUNT,PROVIDER.Fname_L2 SUPPLIERNAME,
                     CONTRACT.Fname  CONTRACTNAME, BILLTYPE.FName_l2  BILLTYPENAME,PURINWAREHSBILL.FNumber  FNUMBER, PURINWAREHSBILL.FBizDate  BIZDATE
                   FROM T_EC_MaterialInvBill  PURINWAREHSBILL
                   LEFT OUTER JOIN T_EC_MaterialInvBillEntry  ENTRYS ON PURINWAREHSBILL.FID = ENTRYS.FParentID
                   LEFT OUTER JOIN T_BD_Period  PERIOD ON PURINWAREHSBILL.FPeriodID = PERIOD.FID
                   LEFT OUTER JOIN T_EC_ContractBill  CONTRACT ON PURINWAREHSBILL.FContractID = CONTRACT.FID
                   LEFT OUTER JOIN T_BD_Supplier  PROVIDER ON PURINWAREHSBILL.FProviderID = PROVIDER.FID
                   LEFT OUTER JOIN T_ORG_Transport  PROJECTORG ON PURINWAREHSBILL.FProjectOrgID = PROJECTORG.FID
                   LEFT OUTER JOIN T_EC_TransactionType  TRANSTYPE ON PURINWAREHSBILL.FTransTypeID = TRANSTYPE.FID
                   LEFT OUTER JOIN T_EC_ResourceItem  MATERIAL ON ENTRYS.FMaterialID = MATERIAL.FID
                   LEFT OUTER JOIN T_EC_BillType  BILLTYPE ON TRANSTYPE.FBillTypeID = BILLTYPE.FID
                   WHERE PURINWAREHSBILL.FBillSate = 03 and PURINWAREHSBILL.Fprojectorgid = '''||v_projectorg||'''' ;
  v_insql:=v_insql||' and BILLTYPE.FID ='''||v_billtypeInv||'''';
  v_insql:=v_insql||' and MATERIAL.fid='''||v_matid||'''';
  v_insql:=v_insql||' and PERIOD.Fnumber>='''||v_startperiod||'''';
  v_insql:=v_insql||' and PERIOD.Fnumber<='''||v_endperiod||'''';

  v_adjsql:='SELECT  PERIOD.FNumber  PERIODNUMBER,ENTRYS.CFQty  ENTRYSQTY,ENTRYS.CFPrice  ENTRYSPRICE,ENTRYS.CFAmount  ENTRYSAMOUNT,SUPPLIER.Fname_L2 SUPPLIERNAME,
                     CONTRACT.Fname  CONTRACTNAME,BILLTYPE.FName_l2  BILLTYPENAME,INVADJUST.FNumber  FNUMBER, INVADJUST.FBizDate  BIZDATE
                   FROM CT_INV_InvAdjust  INVADJUST
                   LEFT OUTER JOIN CT_INV_InvAdjustEntry  ENTRYS ON INVADJUST.FID = ENTRYS.FParentID
                   LEFT OUTER JOIN T_ORG_Transport  PROJECTORG ON INVADJUST.CFProjectOrgID = PROJECTORG.FID
                   LEFT OUTER JOIN T_EC_TransactionType  TRANSTYPE ON INVADJUST.CFTransTypeID = TRANSTYPE.FID
                   LEFT OUTER JOIN T_BD_Period  PERIOD ON INVADJUST.CFPeriodID = PERIOD.FID
                   LEFT OUTER JOIN T_BD_Supplier  SUPPLIER ON INVADJUST.CFSupplierID = SUPPLIER.FID
                   LEFT OUTER JOIN T_EC_ContractBill  CONTRACT ON INVADJUST.CFContractID = CONTRACT.FID
                   LEFT OUTER JOIN T_EC_BillType  BILLTYPE ON TRANSTYPE.FBillTypeID = BILLTYPE.FID
                   LEFT OUTER JOIN T_EC_ResourceItem  MATERIAL ON ENTRYS.CFMaterialID = MATERIAL.FID
                   WHERE INVADJUST.CFBillSate = 03 and INVADJUST.Cfprojectorgid='''||v_projectorg||'''';
  v_adjsql:=v_adjsql||' and BILLTYPE.FID ='''||v_billtypeAdj||'''';
  v_adjsql:=v_adjsql||' and TRANSTYPE.FID ='''||v_transtypeAdj||'''';
  v_adjsql:=v_adjsql||' and MATERIAL.fid='''||v_matid||'''';
  v_adjsql:=v_adjsql||' and PERIOD.Fnumber>='''||v_startperiod||'''';
  v_adjsql:=v_adjsql||' and PERIOD.Fnumber<='''||v_endperiod||'''';

  if v_contract is not null then
     v_insql:= v_insql||' and PURINWAREHSBILL.Fcontractid ='''||v_contract||'''';
     v_adjsql:= v_adjsql||' and INVADJUST.Cfcontractid='''||v_contract||'''';
  end if;
  if v_supplier is not null then
     v_insql:= v_insql||' and PURINWAREHSBILL.FProviderID ='''||v_supplier||'''';
     v_adjsql:= v_adjsql||' and SUPPLIER.FID='''||v_contract||'''';
  end if;

  v_totsql:= v_insql||' union all  '||v_adjsql||'';
  v_totsql:= v_totsql||' ORDER BY BIZDATE ASC ';

  open cc for v_totsql;
  v_perqty:=0;
  v_peramount:=0;
  loop
  fetch cc into v_PERIODNUMBER,v_ENTRYSQTY,v_ENTRYSPRICE,v_ENTRYSAMOUNT,v_SUPPLIERNAME,v_CONTRACTNAME,v_BILLTYPENAME,v_FNUMBER,v_BIZDATE;
  exit when cc% notfound;
       v_perqty:=v_perqty + v_ENTRYSQTY;
       v_peramount:=v_peramount + v_ENTRYSAMOUNT;
       insert into matInAccountRpt_temp(serino,MATERIALID,MATERIALNUMBER,Materialname,Measureunitname,Periodnumber,Bizdate,Entrysqty,Entrysprice,Entrysamount,Suppliername,Contractname,Billtypename,Fnumber)
       values (v_serino,v_matid,v_MATERIALNUMBER,v_MATERIALNAME,v_MEASUREUNITNAME,v_PERIODNUMBER,v_BIZDATE,v_ENTRYSQTY,v_ENTRYSPRICE,v_ENTRYSAMOUNT,v_SUPPLIERNAME,v_CONTRACTNAME,v_BILLTYPENAME,v_FNUMBER);
       v_serino:=v_serino+1;
  end loop;
  --本期合计
      v_perqty:=nvl(v_perqty,0);
      v_peramount:=nvl(v_peramount,0);
      if v_perqty=0 then
         v_peraprice:=0;
      else
         v_peraprice:=round(v_peramount/v_perqty,2);
      end if;
      insert into matInAccountRpt_temp(serino,MATERIALID,MATERIALNUMBER,Materialname,Measureunitname,Periodnumber,Entrysqty,Entrysprice,Entrysamount)
      values (v_serino,v_matid,v_MATERIALNUMBER,v_MATERIALNAME,v_MEASUREUNITNAME,'本期合计',v_perqty,v_peraprice,v_peramount);
      v_serino:=v_serino+1;
  --期末合计
      v_totqty:=v_perqty+v_startqty;
      v_totamount:=v_peramount+v_startamount;
      if v_totqty=0 then
         v_totaprice:=0;
      else
         v_totaprice:=round(v_totamount/v_totqty,2);
      end if;
      insert into matInAccountRpt_temp(serino,MATERIALID,MATERIALNUMBER,Materialname,Measureunitname,Periodnumber,Entrysqty,Entrysprice,Entrysamount)
      values (v_serino,v_matid,v_MATERIALNUMBER,v_MATERIALNAME,v_MEASUREUNITNAME,'期末合计',v_totqty,v_totaprice,v_totamount);
      v_serino:=v_serino+1;
  close cc;
end mat_inaccountrpt_perAmount;
/

