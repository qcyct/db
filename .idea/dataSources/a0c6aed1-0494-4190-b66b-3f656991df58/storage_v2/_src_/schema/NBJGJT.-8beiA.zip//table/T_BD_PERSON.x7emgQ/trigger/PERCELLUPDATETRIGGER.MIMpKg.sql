create trigger PERCELLUPDATETRIGGER
    before update of FCELL
    on T_BD_PERSON
    for each row
BEGIN
   :new.FLastUpdateTime:=sysdate;     
END;
/

