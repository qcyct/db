create procedure mat_settlesummary_payAmount(
v_projectorg in varchar2 default '' ,
v_contractID in varchar2,
v_startperiod in date,
v_endperiod in date,
v_payAmount out NUMBER) as
i integer;
v_prepay number(28,10);--预付款
begin
  v_payAmount:=0;
  v_prepay:=0;
  if v_startperiod is null then --累计付款单

      select count(*) into i
      from CT_II_InvoicePaymentBill InvoicePaymentBill
      LEFT OUTER JOIN CT_II_InvoicePBI  InvoicePBI ON InvoicePBI.Fparentid = InvoicePaymentBill.Fid
                 where InvoicePaymentBill.Cfprojectorgid=v_projectorg
                 and InvoicePBI.Cfcfcontractid0= v_contractID
                 and InvoicePaymentBill.Cfbillsate in ('03','04','05','06')
                 and InvoicePaymentBill.Fbizdate<v_endperiod ;
      if i>0 then
      select sum(InvoicePBI.Cfcurrpayamount) into v_payAmount
      from CT_II_InvoicePaymentBill InvoicePaymentBill
      LEFT OUTER JOIN CT_II_InvoicePBI  InvoicePBI ON InvoicePBI.Fparentid = InvoicePaymentBill.Fid
                 where InvoicePaymentBill.Cfprojectorgid=v_projectorg
                 and InvoicePBI.Cfcfcontractid0= v_contractID
                 and InvoicePaymentBill.Cfbillsate in ('03','04','05','06')
                 and InvoicePaymentBill.Fbizdate<v_endperiod ;

      end if;
      --预付款
      select count(*) into i
                from CT_II_ImprestBill impay
                where
                impay.cfbillstate='03'
                and impay.cfprojectorgid= v_projectorg
                and impay.cfcontractid= v_contractID
                and impay.fbizdate<v_endperiod ;
         if i>0 then
            select sum(impay.cfimprestamount) into v_prepay
            from CT_II_ImprestBill impay
            where
            impay.cfbillstate='03'
            and impay.cfprojectorgid= v_projectorg
            and impay.cfcontractid= v_contractID
            and impay.fbizdate<v_endperiod ;
         end if;

      v_payAmount:=v_payAmount+v_prepay;

  else    --当期
      select count(*) into i
      from CT_II_InvoicePaymentBill InvoicePaymentBill
      LEFT OUTER JOIN CT_II_InvoicePBI  InvoicePBI ON InvoicePBI.Fparentid = InvoicePaymentBill.Fid
                 where InvoicePaymentBill.Cfprojectorgid=v_projectorg
                 and InvoicePBI.Cfcfcontractid0= v_contractID
                 and InvoicePaymentBill.Cfbillsate in ('03','04','05','06')
                 and InvoicePaymentBill.Fbizdate>=v_startperiod
                 and InvoicePaymentBill.Fbizdate<v_endperiod ;
      if i>0 then
      select sum(InvoicePBI.Cfcurrpayamount) into v_payAmount
      from CT_II_InvoicePaymentBill InvoicePaymentBill
      LEFT OUTER JOIN CT_II_InvoicePBI  InvoicePBI ON InvoicePBI.Fparentid = InvoicePaymentBill.Fid
                 where InvoicePaymentBill.Cfprojectorgid=v_projectorg
                 and InvoicePBI.Cfcfcontractid0= v_contractID
                 and InvoicePaymentBill.Cfbillsate in ('03','04','05','06')
                 and InvoicePaymentBill.Fbizdate>=v_startperiod
                 and InvoicePaymentBill.Fbizdate<v_endperiod  ;
      end if;
      --预付款
      select count(*) into i
                from CT_II_ImprestBill impay
                where
                impay.cfbillstate='03'
                and impay.cfprojectorgid= v_projectorg
                and impay.cfcontractid= v_contractID
                and impay.fbizdate>=v_startperiod
                and impay.fbizdate<v_endperiod ;
         if i>0 then
            select sum(impay.cfimprestamount) into v_prepay
            from CT_II_ImprestBill impay
            where
            impay.cfbillstate='03'
            and impay.cfprojectorgid= v_projectorg
            and impay.cfcontractid= v_contractID
            and impay.fbizdate>=v_startperiod
            and impay.fbizdate<v_endperiod ;
         end if;

      v_payAmount:=v_payAmount+v_prepay;



  end if;
end mat_settlesummary_payAmount;
/

