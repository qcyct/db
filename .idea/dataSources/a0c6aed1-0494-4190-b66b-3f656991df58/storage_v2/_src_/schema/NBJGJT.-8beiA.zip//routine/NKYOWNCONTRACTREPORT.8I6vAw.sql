create procedure NkyOwnContractReport(
v_startdate in varchar2 ,
v_enddate in varchar2) is
cursor cc is   select   b.cfprojectclass ,b.cfsignperson,b.fnumber,b.cfmainprojectname,a.cfcontractnumber,a.Cfcontractamount,
 b.fbizdate,b.fid,a.fid as confid,d.cfprojectaddress
from Ct_Kc_Nkyproproject b 
left outer join CT_KC_NkyOwnerContract a on a.fid=b.cfcontractnubmerid
left outer join ct_kc_nkymainproject  d on d.fid=b.cfmainprojectid
where b.fbizdate>=to_date(v_startdate,'yyyyMMdd')
and b.fbizdate<=to_date(v_enddate,'yyyyMMdd')
order by  b.cfprojectclass asc,b.fbizdate asc;
tt cc%rowtype;

num_receiveamount number(28,10);
v_receivepoint  varchar2(2000);
v_receivedate timestamp(6);
v_drdate timestamp(6);
v_finishworkload varchar2(1000);
i integer;
j integer;
begin
  DELETE FROM CT_KC_OwnContractReport_Temp;
 
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;
  num_receiveamount:=0;
  v_receivepoint:='';
  v_finishworkload:='';
  v_receivedate := null;
  v_drdate := null;
  i:=0;
  j:=0;
  select nvl(Cfperrreceiveamount,0) into num_receiveamount from 
  (select sum(f.Cfperrreceiveamount) as Cfperrreceiveamount   from CT_KC_InvoiceApplyEntry f    where f.cfnkyproprojectid=tt.fid);
  
  if tt.confid is not null then
  NkyOwnContractReport_con(tt.confid,v_receivepoint);
  end if;
  
  select count(*) into i  from CT_KC_InvoiceApplyEntry f   where f.cfnkyproprojectid=tt.fid;
  if i>0 then
   select cfreceivedate into v_receivedate
          from   (select f.cfreceivedate   from CT_KC_InvoiceApplyEntry f   where f.cfnkyproprojectid=tt.fid  order by  f.cfreceivedate desc)
          where rownum=1;
  end if;
  
  select count(*) into j from  CT_KC_DrawingStampManage e where  e.Cfproprojectnumber=tt.fid;
  if j>0 then
     select cfdrdate,cffinishworkload  into v_drdate,v_finishworkload
             from ( select e.cfdrdate,e.cffinishworkload from  CT_KC_DrawingStampManage e where  e.Cfproprojectnumber=tt.fid order by e.fbizdate desc)
             where rownum=1;
  end if;

 insert into CT_KC_OwnContractReport_Temp(CFProjectclass ,CFSignperson,CFContractNumber,CFProProjectNumber,CFMainProjectID,CFContractAmount,CFReceiveamount,CFReceivedate,CFDRDate,CFWorkload,CFReceivepoint,Fbizdate,Projectaddress )
  values (tt.cfprojectclass,tt.Cfsignperson,tt.Cfcontractnumber,tt.fnumber,tt.cfmainprojectname,tt.Cfcontractamount,num_receiveamount,v_receivedate,v_drdate,v_finishworkload,v_receivepoint,tt.fbizdate,tt.cfprojectaddress);


  end loop;
  close cc;

end NkyOwnContractReport;
/

