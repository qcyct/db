create PROCEDURE PROC_TRANSFORMINVOICE AS 
BEGIN

MERGE INTO CT_II_InvoiceBill a --发票池中的发票
USING T_TMP_InvoiceBill b  --临时发票数据
ON ( a.CFINVOICETYPECODE=b.FinvoiceTypeCode 
    and a.CFINVOICENUMBER=b.FinvoiceNumber)
WHEN MATCHED THEN
    update  set a.CFBillStatus=b.FBillStatus,--更新发票状态
    a.CFisAuth = DECODE(b.FAuthDate,null,a.CFisAuth,1),--如果认证日期为空取原值不更新，不为空取1，表示已认证
    a.CFauthType = DECODE(b.FAuthType,NULL,-1,b.FAuthType), --认证方式 ,如果为空，默认为-1 未认证，不为空取更新后的状态 0:扫描认证            1:系统推送（勾选认证）            2:不予退税
    a.CFauthDate = DECODE(b.FAuthDate,NULL,a.CFauthDate,TO_DATE(b.FAuthDate, 'YYYY-MM-DD HH24:MI:SS')),--认证日期
    a.CFAuthMonth = DECODE(b.FAuthMonth,NULL,a.CFAuthMonth,b.FAuthMonth), --认证月份
    a.CFCHECKSTATUS = nvl(b.FCHECKSTATUS,0) ,--勾选状态 0 未勾选
    a.FCHECKDATE = DECODE(b.FCHECKDATE,NULL,a.FCHECKDATE,TO_DATE(b.FCHECKDATE, 'YYYY-MM-DD HH24:MI:SS')) ,--勾选日期
    a.CFMANAGERTYPE = nvl(b.FMANAGERTYPE,0) --管理状态 0:正常            1:非正常
    ;
  
MERGE INTO CT_II_InvoiceBill a --更新发票货物名称
USING (SELECT a.fid,max(b.CFNAME) cfname FROM CT_II_InvoiceBill a 
    left join CT_II_InvoiceBillEntry b on a.fid = b.fparentid 
    where  a.FGOODSNAME is null and b.CFNAME is not null
    group by a.fid
    ) b  --临时发票数据
ON ( a.fid=b.fid)
WHEN MATCHED THEN
    update  set a.FGOODSNAME = b.CFNAME
    ;   
--commit;
--获取新发票数据 
--临时表 与比较 发票池表 的增量差异，取增量部分
DELETE T_MINUS_InvoiceBill;
INSERT /*+ append */ INTO T_MINUS_InvoiceBill(FinvoiceTypeCode,FinvoiceNumber,FBillStatus)
select FinvoiceTypeCode,FinvoiceNumber,FBillStatus from T_TMP_InvoiceBill 
minus 
SELECT CFINVOICETYPECODE,CFINVOICENUMBER,CFBillStatus FROM CT_II_InvoiceBill;
commit;

--insert head
INSERT /*+ append */ INTO CT_II_InvoiceBill nologging (FID,FCREATORID,FCREATETIME,FLASTUPDATEUSERID,FLASTUPDATETIME,FCONTROLUNITID,FNUMBER,FBIZDATE,CFNAME,CFBILLSATE,CFINVOICETYPEID,CFINVOICENUMBER,CFINVOICEDATE,CFINVOICETYPECODE,CFPURCHASEUNITID,cfpurchaseName,CFPDUTYCODE,CFPADDRESSTELL,CFPBANKACCOUNT,CFSDUTYCODE,CFSADDRESSTELL,CFSBANKACCOUNT,CFTOTAMOUNT,CFNONTAXAMOUNT,CFTAX,CFEXPIREDATE,CFAUTHTYPE,CFINVOICEUNIT,CFUNPAYAMOUNT,CFPAYAMOUNT,CFISAUTH,CFBILLSTATUS,CFCapTotAmout,cfispayreq,CFauthDate,CFAuthMonth,CFTransfer,CFIsSplit,cfisDirectPay ,FTAXRATE,CFCOUNT,CFCHECKSTATUS,FCHECKDATE,CFMANAGERTYPE) 
SELECT  FID,'256c221a-0106-1000-e000-10d7c0a813f413B7DE7F',sysdate,'256c221a-0106-1000-e000-10d7c0a813f413B7DE7F',sysdate,'c4VJVwEbEADgAE/0ChZiAsznrtQ=',a.FinvoiceNumber,TO_DATE(FInvoiceDate, 'YYYY-MM-DD HH24:MI:SS'),FInvoiceUnit,'00','mbUAAAAiFq7NeSoF',a.FinvoiceNumber,TO_DATE(FInvoiceDate, 'YYYY-MM-DD HH24:MI:SS'),a.FinvoiceTypeCode,'mbUAAABMmNYPElLw','宁波建工工程集团有限公司','91330200340554704D','浙江省宁波市鄞州区宁穿路538号0574-87206897','中国建设银行宁波市分行营业部33101983679050551865',null,NULL,NULL,FNonTaxAmount+FTax,FNonTaxAmount,FTax,TO_DATE(FInvoiceDate, 'YYYY-MM-DD HH24:MI:SS')+365,a.FAuthType,FInvoiceUnit,FNonTaxAmount+FTax,0,DECODE(a.FAuthDate,NULL,0,1),a.FBillStatus,money_to_chinese(FNonTaxAmount+FTax),0,TO_DATE(FAuthDate, 'YYYY-MM-DD HH24:MI:SS'),a.FAuthMonth,0,0,0,DECODE(round((a.FTAX/a.FNONTAXAMOUNT)*100),0,0, 1,1,3, 3, 4,4,5,5,6,6,10,10,11,11,13,13,16,16,17,17,99),1,a.FCHECKSTATUS,TO_DATE(a.FCHECKDATE, 'YYYY-MM-DD HH24:MI:SS'),a.FMANAGERTYPE FROM t_tmp_invoicebill a
inner join  T_MINUS_InvoiceBill panda on panda.FinvoiceTypeCode=a.FinvoiceTypeCode and panda.FinvoiceNumber=a.FinvoiceNumber;
commit;

--insert entrys
INSERT /*+ append */ INTO CT_II_INVOICEBILLENTRY(FSEQ, FID, FPARENTID, CFQTY, CFPRICE, CFAMOUNT, CFBILLTAXRATE, CFTAX,CFTaxInAmount )
SELECT 1,newbosid('B4094293'), a.FID,  1, a.FNonTaxAmount,a.FNonTaxAmount, DECODE(round((a.FTAX/a.FNONTAXAMOUNT)*100),0,0,1,1, 3, 3, 4,4,5,5,6,6,10,10,9,9,11,11,13,13,16,16,17,17,99),  a.FTAX,a.FNonTaxAmount+a.FTAX FROM t_tmp_invoicebill a
inner join  T_MINUS_InvoiceBill panda on panda.FinvoiceTypeCode=a.FinvoiceTypeCode and panda.FinvoiceNumber=a.FinvoiceNumber;
commit;
END PROC_TRANSFORMINVOICE;

/**
 drop table T_TMP_INVOICEBILL;
 
 CREATE TABLE T_TMP_INVOICEBILL 
 (	
  FID NVARCHAR2(50), --发票ID
	FINVOICETYPECODE NVARCHAR2(50), --发票代码
	FINVOICENUMBER NVARCHAR2(50), --发票号码
	FINVOICEDATE NVARCHAR2(10), --开票日期
	FINVOICEUNIT NVARCHAR2(80), --开票单位
	FNONTAXAMOUNT NUMBER(28,10), --不含税金额
	FTAX NUMBER(28,10), --税额
  FACTTAX NUMBER(28,10),--有效税额
	FBILLSTATUS VARCHAR2(100), --发票状态		是			0 正常            1 失控            2 作废            3 红冲            4 异常
  FINVOICETYPE NVARCHAR2(4), --发票种类	2	是			01 增值税专票             02 货物运输            03 机动车            14 通行费
  FAuthType  NUMBER(4,0), --认证方式					0:扫描认证            1:系统推送（勾选认证）            2:不予退税
	FCHECKSTATUS NUMBER(4,0), --勾选状态	1	是			0 未勾选             1已勾选
	FCHECKDATE NVARCHAR2(20), --勾选日期
	FManagerType NUMBER(4,0), --管理状态	1	是			0:正常            1:非正常
	FAUTHDATE NVARCHAR2(20), --认证日期
	FAUTHMONTH NVARCHAR2(10)	--认证月份					只有查询已认证发票存在
) ;

--MachineCode
--HasCode
FManagerType NUMBER(4,0), --管理状态	1	是			0:正常            1:非正常
Checkstatus NUMBER(4,0), --勾选状态	1	是			0 未勾选             1已勾选
	FCHECKDATE NVARCHAR2(20), --勾选日期
**/
/

