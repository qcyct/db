create procedure ProjCapPlan_Sporadic(
v_projectorg in varchar2 default '' ,
v_startdate in date,
v_enddate in date) as

v_paypercent number(28,10);--付款比例
per_matBalAmount number(28,10);--本期结算
tot_matBalAmount number(28,10);--累计结算
tot_payAmount  number(28,10);--累计付款
tot_unPayAmount number(28,10);--累计未付
v_seqNum integer;

begin
     --本期零星结算
     select sum(sp.cftotamount) into per_matBalAmount
            from CT_INV_SporadicMatReg sp
            where sp.cfprojectorgid= v_projectorg
              and sp.fbizdate>=v_startdate
              and sp.fbizdate<v_enddate
              and sp.cfbillstate in ('03','04','05','06','10');
     per_matBalAmount:= nvl(per_matBalAmount,0);--本期结算
     --累计零星结算
     select sum(sp.cftotamount) into tot_matBalAmount
            from CT_INV_SporadicMatReg sp
            where sp.cfprojectorgid= v_projectorg
              and sp.fbizdate<v_enddate
              and sp.cfbillstate in ('03','04','05','06','10');
     tot_matBalAmount:= nvl(tot_matBalAmount,0);--累计结算
     --累计付款
     select sum(InvoicePBI.Cfcurrpayamount) into tot_payAmount
            from CT_II_InvoicePaymentBill InvoicePaymentBill
             LEFT OUTER JOIN CT_II_InvoicePBI  InvoicePBI ON InvoicePBI.Fparentid = InvoicePaymentBill.Fid
                 where InvoicePaymentBill.Cfprojectorgid=v_projectorg
                 and InvoicePBI.Cfcontracttype='8' --合同类型 零星合同
                 and InvoicePaymentBill.Cfbillsate in ('03','04','05','06')
                 and InvoicePaymentBill.Fbizdate<v_enddate ;
    tot_payAmount:= nvl(tot_payAmount,0);--累计付款
    --累计未付 = 累计对账-累计已付
    tot_unPayAmount:= tot_matBalAmount-tot_payAmount;

    --付款比例  = 累计付款/累计对账
    if tot_matBalAmount>0 then
      v_paypercent:= round(tot_payAmount/tot_matBalAmount,2);
    else
      v_paypercent:= 0;
    end if;
    per_matBalAmount:= nvl(per_matBalAmount,0);--本期结算
    tot_matBalAmount:= nvl(tot_matBalAmount,0);--累计结算
    tot_payAmount:= nvl(tot_payAmount,0);--累计付款
    tot_unPayAmount:= nvl(tot_unPayAmount,0);--累计未付

    select count(*)+1 into v_seqNum FROM  ProjCapPlan_temp;
    insert into ProjCapPlan_temp(contractCostType,permatBalAmount,totmatBalAmount,totpayAmount,totunPayAmount,paypercent,Countsign,Seqnum )
    values('其他零星材料',per_matBalAmount,tot_matBalAmount,tot_payAmount,tot_unPayAmount,v_paypercent,'1',v_seqNum);

end ProjCapPlan_Sporadic;
/

