create procedure NkyKCContractReceList(
v_startdate in varchar2,
v_enddate in varchar2) is
cursor cc is  select  d.fname_l2 projectMGType,c.cfmainprojectname projectName,a.fnumber  contractNumber,a.cfcontractamount contractAmount,
a.fbizdate signDate,a.cfdutyperson signPerson,b.Cfreceivepoint  receivePoint,b.cfreceiveAmount receiveAmount,b.Cfreceivedate receiveDate,
a.fid confid
from CT_KC_NkyOwnerContract a
left outer join CT_KC_NkyOwnerContractEntry b on b.fparentid=a.fid
left outer join ct_kc_nkymainproject c on c.fid=a.cfmainprojectid
left outer join CT_NKY_NkyProjectType d on d.fid=c.cfprojectmgtypeid
where
a.cfbillstate='03'
and a.cfcontractstate!='04'
and a.fbizdate>=to_date(v_startdate,'yyyyMMdd')
and a.fbizdate<to_date(v_enddate,'yyyyMMdd')+1
order by a.fbizdate desc;

tt cc%rowtype;
v_totTicketAmount NUMERIC(20,2);
v_totReceiveAmount NUMERIC(20,2);
v_totPayAmount NUMERIC(20,2);
v_totActPayAmount NUMERIC(20,2);
temp_totTicketAmount NUMERIC(20,2);
temp_totReceiveAmount NUMERIC(20,2);
temp_totPayAmount NUMERIC(20,2);
temp_totActPayAmount NUMERIC(20,2);

begin
  DELETE FROM  NkyKCContractReceListl_temp;

  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;
  
   temp_totTicketAmount:=0;
   temp_totReceiveAmount:=0;
   temp_totPayAmount:=0;
   temp_totActPayAmount:=0;
   --合同对应的专业工程
   for c_proproj  in (select e.cfproprojectnumber ppfid from CT_KC_NkyOCPE e where e.fparentid=tt.confid ) loop
       select nvl(f.Cftotticketamount,0),nvl(f.Cftotreceiveamount,0),nvl(f.Cftotpayamount,0),nvl(f.Cftotactpayamount,0) into  v_totTicketAmount,v_totReceiveAmount,v_totPayAmount,v_totActPayAmount
       from CT_KC_NkyProProject f where f.fid=c_proproj.ppfid;
       temp_totTicketAmount:=temp_totTicketAmount+v_totTicketAmount;
       temp_totReceiveAmount:=temp_totReceiveAmount+v_totReceiveAmount;
       temp_totPayAmount:=temp_totPayAmount+v_totPayAmount;
       temp_totActPayAmount:=temp_totActPayAmount+v_totActPayAmount;
   end loop;
   
   insert into NkyKCContractReceListl_temp(projectMGType,Projectname,Contractnumber,Contractamount,Signdate,Signperson,Receivepoint,Receiveamount,Receivedate,
          Confid,Totticketamount,Totreceiveamount,Totpayamount,Totactpayamount)
          values(tt.Projectmgtype,tt.Projectname,tt.Contractnumber,tt.Contractamount,tt.Signdate,tt.Signperson,tt.Receivepoint,tt.Receiveamount,tt.Receivedate,
          tt.Confid,temp_totTicketAmount,temp_totReceiveAmount,temp_totPayAmount,temp_totActPayAmount);

  end loop;
  close cc;

end NkyKCContractReceList;
/

