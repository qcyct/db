create procedure ProjCapPlan_Lab_Main(
v_projectorg in varchar2 default '' ,
v_startdate in varchar2,
v_enddate in varchar2) is
cursor cc is   select c.fname_l2 contractCostType,a.cfsupplierid supplierID,b.fname_l2 supplierName,a.fid contractID,a.cfname contractName,a.cforiginalamount contractAmount,substr(a.cfpaymentterms,0,400) paymentterms,a.Cfpaytaxamount payTaxAmount
from ct_lab_labourcontract a
left outer join T_BD_Supplier b on b.fid=a.cfsupplierid
left outer join CT_BAS_ContractCostType c on c.fid=a.cfcontractcosttype
left outer join T_BAS_ContractCostTypeTREE d on d.fid= c.ftreeid
where a.cfprojectorgid=v_projectorg
and d.fnumber !='04' --非专业分包拆分合同
and a.cfcontractattribute='0' -- 原始合同
and a.cfcontractstatus in ('3','6','7','10')
order by c.fnumber asc;

tt cc%rowtype;
v_paypercent number(28,10);--付款比例
v_startperiod date;
v_endperiod date;
per_matBalAmount number(28,10);--本期结算
tot_matBalAmount number(28,10);--累计结算
tot_payAmount  number(28,10);--累计付款
tot_unPayAmount number(28,10);--累计未付
v_payAmount  number(28,10);--正常付款
v_seqNum integer;

begin
  select count(*)+1 into v_seqNum FROM  ProjCapPlan_temp;
  --插入第一行 类型 2、人工
  insert into ProjCapPlan_temp(contractCostType,Seqnum,Countsign) values ('2.人工',v_seqNum,'c2');
  v_seqNum:=v_seqNum+1;
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;

  per_matBalAmount:= 0;--本期结算
  tot_matBalAmount:= 0;--累计结算
  tot_payAmount:=0;--累计付款
  tot_unPayAmount:=0;--累计未付

  if v_startdate is not null then
    v_startperiod := to_date(v_startdate,'yyyyMMdd');
  end if;
  if v_enddate is not null then
    v_endperiod := to_date(v_enddate,'yyyyMMdd')+1;
  end if;
   --本期结算
   select nvl(sum(d.Cfcurrtaxamount),0)  into per_matBalAmount
         from ct_lab_laboursettlebill  d
          where d.cfprojectorgid=v_projectorg
          and d.cfcontractid=tt.contractID
          and d.fbizdate>=v_startperiod
          and d.fbizdate <v_endperiod
          and d.cfbillsate in ('03','04','05','06','10');
  --累计结算
  select nvl(sum(d.Cfcurrtaxamount),0)  into tot_matBalAmount
         from ct_lab_laboursettlebill  d
          where d.cfprojectorgid=v_projectorg
          and d.cfcontractid=tt.contractID
          and d.fbizdate <v_endperiod
          and d.cfbillsate in ('03','04','05','06','10');
  
  --劳务预付单 累计付款
  select nvl(sum(d.cfpayamount),0) into tot_payAmount
         from ct_lab_laboursettlebill  d
          where d.cfprojectorgid=v_projectorg
          and d.cfcontractid=tt.contractID
          and d.fbizdate <v_endperiod
          and d.cfbillsate in ('03','04','05','06','10');

   --正常付款单  累计付款
   select nvl(sum(InvoicePBI.Cfcurrpayamount),0) into v_payAmount
      from CT_II_InvoicePaymentBill InvoicePaymentBill
      LEFT OUTER JOIN CT_II_InvoicePBI  InvoicePBI ON InvoicePBI.Fparentid = InvoicePaymentBill.Fid
                 where InvoicePaymentBill.Cfprojectorgid=v_projectorg
                 and InvoicePBI.Cfcfcontractid0= tt.contractID
                 and InvoicePaymentBill.Cfbillsate in ('03','04','05','06')
                 and InvoicePaymentBill.Fbizdate<v_endperiod ;
    tot_payAmount:=tot_payAmount+v_payAmount;
    --累计未付 = 累计结算-累计付款
    tot_unPayAmount:= tot_matBalAmount-tot_payAmount;

   --付款比例  = 累计付款/累计对账
   if tot_matBalAmount>0 then
      v_paypercent:= round(tot_payAmount/tot_matBalAmount,2);
   else
      v_paypercent:= 0;
   end if;
   per_matBalAmount:= nvl(per_matBalAmount,0);--本期结算
   tot_matBalAmount:= nvl(tot_matBalAmount,0);--累计结算
   tot_payAmount:= nvl(tot_payAmount,0);--累计付款
   tot_unPayAmount:= nvl(tot_unPayAmount,0);--累计未付

   insert into ProjCapPlan_temp(contractCostType,supplierName,supplierID,contractID,contractName,contractAmount,permatBalAmount,totmatBalAmount,totpayAmount,totunPayAmount,paypercent,paymentterms,Countsign,Seqnum )
   values(tt.contractcosttype,tt.suppliername,tt.supplierid,tt.contractid,tt.contractname,tt.contractamount,per_matBalAmount,tot_matBalAmount,tot_payAmount,tot_unPayAmount,v_paypercent,tt.paymentterms,'2',v_seqNum);
   v_seqNum:=v_seqNum+1;
  end loop;
  close cc;

  --插入最后一行 小计
  insert into ProjCapPlan_temp(contractCostType,contractAmount,permatInAmount,totmatInAmount,permatBalAmount,totmatBalAmount,totInvAmount,totpayAmount,totunPayAmount,Countsign,Seqnum)
              select  '小计', sum(a.contractamount) contractAmount,sum(a.permatinamount) permatInAmount,sum(a.Totmatinamount) totmatInAmount,
                      sum(a.totmatbalamount) permatBalAmount,sum(a.Totmatbalamount) totmatBalAmount,
                      sum(a.Totinvamount) totInvAmount,sum(a.Totpayamount) totpayAmount,sum(a.Totunpayamount) totunPayAmount ,'c2',v_seqNum
                      from ProjCapPlan_temp a where a.countsign='2' ;

end ProjCapPlan_Lab_Main;
/

