create procedure NkyOwnerContract_TempTest
is
cursor cc is    select a.cfproprojectnumber,a.fparentid,g.cfcontractname,g.cfcontractamount,g.cfnkycustomerid from CT_KC_NkyOCPE a
left outer join CT_KC_NkyOwnerContract g on g.fid=a.fparentid;
tt cc%rowtype;
i integer;
begin
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;
  i:=0;
  --更新专业工程
  select count(*) into i  from ct_kc_nkyproproject b where b.fid=tt.cfproprojectnumber and b.cfcontractnubmerid is null;
  if i>0  then
      update  ct_kc_nkyproproject b  set b.cfcontractnubmerid=tt.fparentid , b.cfcontractname=tt.cfcontractname, b.cfcontractamount=tt.cfcontractamount,
             b.cfnkycustomerid=tt.cfnkycustomerid   where b.fid=tt.cfproprojectnumber;
  end if;
  

  --更新施工任务通知单
  select count(*) into i  from  ct_kc_workassignment c  where c.cfproprojectnumber=tt.cfproprojectnumber and c.cfcontractnubmerid is null;
  if i>0  then
    update  ct_kc_workassignment c  set c.cfcontractnubmerid=tt.fparentid , c.cfcontractname=tt.cfcontractname, c.cfcontractamount=tt.cfcontractamount,
             c.cfnkycustomerid=tt.cfnkycustomerid   where c.cfproprojectnumber=tt.cfproprojectnumber;
  end if;
  
  --更新出图章登记
  select count(*) into i  from ct_kc_drawingstampmanage d where d.cfproprojectnumber=tt.cfproprojectnumber and d.cfcontractnubmerid is null;
   if i>0  then
      update  ct_kc_drawingstampmanage d  set d.cfcontractnubmerid=tt.fparentid , d.cfcontractamount=tt.cfcontractamount
                   where d.cfproprojectnumber=tt.cfproprojectnumber;
   end if;
  
  --更新工程费用决算单
   select count(*) into i  from  Ct_Kc_Projectcostaccounts e where e.cfproprojectnumber=tt.cfproprojectnumber and e.cfcontractnubmerid  is null;
   if i>0  then
        update  Ct_Kc_Projectcostaccounts e  set e.cfcontractnubmerid=tt.fparentid , e.cfcontractamount=tt.cfcontractamount,
            e.cfnkycustomerid=tt.cfnkycustomerid   where e.cfproprojectnumber=tt.cfproprojectnumber;
   end if ;
  
  --更新提款单
    select count(*) into i  from Ct_Kc_Nkykcpayment f  where f.cfproprojectnumber=tt.cfproprojectnumber and f.cfcontractnubmerid is null;
    if i>0  then
        update  Ct_Kc_Nkykcpayment f  set f.cfcontractnubmerid=tt.fparentid,f.cfcontractname=tt.cfcontractname , f.cfcontractamount=tt.cfcontractamount,
            f.cfnkycustomerid=tt.cfnkycustomerid   where f.cfproprojectnumber=tt.cfproprojectnumber;
    end if;

  end loop;
  close cc;

end NkyOwnerContract_TempTest;
/

