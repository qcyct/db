create FUNCTION newbosid (typeString VARCHAR2) RETURN VARCHAR2
IS
guid RAW(32);
s_guid VARCHAR2(32);
g_hex VARCHAR(22);
BEGIN
guid := SYS_GUID();
s_guid := RAWTOHEX(guid);
g_hex :='0123456789ABCDEFabcdef';
IF LENGTH(typeString) = 8 THEN
FOR i IN 1 .. 8 LOOP
IF INSTR(g_hex,SUBSTR(typeString,i,1),1,1) = 0 THEN
GOTO old_form;
END IF;
END LOOP;
RETURN UTL_RAW.cast_to_varchar2(UTL_ENCODE.base64_encode(UTL_RAW.CONCAT(guid,HEXTORAW(typeString))));
ELSIF  LENGTH(typeString) = 4 THEN
GOTO old_form;
ELSE
RETURN NULL;
END IF;
<<old_form>>
RETURN SUBSTR(s_guid, 0, 8) || '-' || SUBSTR(s_guid, 8, 4) || '-' || SUBSTR(s_guid, 12, 4)|| '-' || SUBSTR(s_guid, 16, 4)||'-' || SUBSTR(s_guid, 20, 12)|| typeString;
END;

/

