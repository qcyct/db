create procedure proc_csspBankBatchSave 
as
CURSOR cur_Stru IS SELECT * FROM T_TMP_CSSPBank ;
begin

FOR stru_row IN cur_Stru
loop
 if stru_row.FType = 1 then
  proc_csspCostomerBankBatchSave(stru_row.FPayeeID,stru_row.FPayeeBank ,stru_row.FPayeeAccountBank) ;
 ELSIF  stru_row.FType = 2 then
  proc_csspSupplierBankBatchSave(stru_row.FPayeeID,stru_row.FPayeeBank ,stru_row.FPayeeAccountBank);
end if;
end loop;
--清空临时表
delete from T_TMP_CSSPBank ;
commit;
end proc_csspBankBatchSave;
/

