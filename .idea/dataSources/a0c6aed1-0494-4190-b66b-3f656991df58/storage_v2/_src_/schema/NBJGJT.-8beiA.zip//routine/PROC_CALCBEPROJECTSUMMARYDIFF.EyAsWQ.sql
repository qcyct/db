create procedure proc_calcBEProjectSummaryDiff 
(
peroidID in varchar2 default '1',
companyID in varchar2 default '' ,
startDate in varchar2 default '',
endDate in varchar2 default ''
)
as
begin 
--清空缓存表
delete from T_BE_BEPROJECTSUMMARYTEMPDIFF ;
delete from T_BE_BEPROJECTSUMMARYTEMPBLT ;

proc_calcBEProjectSummary('0',companyID,startDate,endDate);

insert into T_BE_BEPROJECTSUMMARYTEMPBLT(acctNumber,BalanceAmt,bizAmt,projectNumber,prefixNumber,projectName)
select 科目,期末余额原币,nvl(biz.COLUMN32,0) bizAmt,projectNumber,prefixNumber,projectname from (
select b.fnumber 科目,
nvl(a.FEndBalanceFor,0) 期末余额原币,
nvl((case d.fnumber when cast('9999' as  nvarchar2(10)) then  cast('JGJF' as  nvarchar2(10)) else d.fnumber end),'JGJF') projectNumber,
nvl(SUBSTR(case d.fnumber when cast('9999' as  nvarchar2(10)) then  cast('JGJF' as  nvarchar2(10)) else d.fnumber end,0,4),'JGJF') prefixNumber,
nvl(d.fname_l2,'历史项目') projectname,
d.fnumber ||' '||  d.fname_l2 prokey
from T_BD_AccountView b left join T_GL_AssistBalance a on b.fid=a.faccountid
and a.FBalType=1 
and a.fcurrencyid='dfd38d11-00fd-1000-e000-1ebdc0a8100dDEB58FDC' 
and a.fperiodid = peroidID
and a.FOrgUnitID = companyID
left join T_BD_AssistantHG c on c.fid = a.FAssistGrpID
left join T_BD_GeneralAsstActType d on d.fid = c.FGeneralAssActType1ID
where 1=1  
and b.FCompanyID = companyID 
and substr(b.fnumber,0,4) in ('1001','1002','1003','1009')
and b.FIsLeaf = 1
order by b.fnumber,d.fnumber
) blt 
left join T_BE_BEProjectSummaryTemp biz on biz.COLUMN1 = blt.prokey --不包括18年8月前老项目及公共管理中心
order by blt.科目,blt.projectNumber
;

insert into T_BE_BEPROJECTSUMMARYTEMPDIFF(COLUMN1,COLUMN2,COLUMN3,COLUMN4,COLUMN5,COLUMN6,COLUMN7,COLUMN8,COLUMN9)
select 项目, FNAME_L2,sum( 现金1001)  现金1001,
sum(内部银行1003) 内部银行1003, 
sum(外部银行1002) 外部银行1002, 
sum(其他货币资金1009), sum(TOTAMT) TOTAMT,
max(BIZAMT) BIZAMT, sum(DIFFAMT) DIFFAMT from (
select 
case when substr(PROJECTNUMBER,0,4) = cast('JGGC' as  nvarchar2(10)) then PROJECTNUMBER||' '||PROJECTNAME
else cast('18年8月前老项目及公共管理中心' as  nvarchar2(20)) end 项目,
b.fname_l2,
SUM(case when substr(acctnumber,0,4) = '1001' then BALANCEAMT else 0 end ) 现金1001, 
SUM(case when substr(acctnumber,0,4) = '1002' then BALANCEAMT else 0 end ) 外部银行1002, 
SUM(case when substr(acctnumber,0,4) = '1003' then BALANCEAMT else 0 end ) 内部银行1003, 
SUM(case when substr(acctnumber,0,4) = '1009' then BALANCEAMT else 0 end ) 其他货币资金1009, 0 totamt, 
max(bizamt) bizamt,0 diffamt
from T_BE_BEProjectSummaryTempblt a,(select fname_l2 from t_org_company where fid = companyID) b
group by PROJECTNUMBER,PROJECTNAME,fname_l2
--order by PREFIXNUMBER
) group by 项目, FNAME_L2
;

update T_BE_BEPROJECTSUMMARYTEMPDIFF 
set COLUMN7 = COLUMN3 + COLUMN4 + COLUMN5 + COLUMN6 ;

--更新18年8月前老项目及公共管理中心数据
update T_BE_BEPROJECTSUMMARYTEMPDIFF 
set COLUMN8 = (SELECT sum(COLUMN32) publicAmt FROM T_BE_BEProjectSummaryTemp 
where 
COLUMN2 = (select fname_l2 from t_org_company where fid = companyID)--companyID
and (COLUMN1 like '%公共管理中心' or COLUMN1 like '%18年8月前老项目'))
where COLUMN1='18年8月前老项目及公共管理中心'
;

update T_BE_BEPROJECTSUMMARYTEMPDIFF 
set COLUMN9 = COLUMN8 - COLUMN7;
commit;
end proc_calcBEProjectSummaryDiff;
/

