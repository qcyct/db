create view V_AP_CHECKACCOUNTBILL1 as
SELECT bill.fbizdate FBILLDATE, bill.fcompanyid FCOMPANYID, bill.fpayeetypeid FASSTACTTYPEID, bill.fpayeeid FASSTACTID, bill.fcurrencyid FCURRENCYID, bill.FPersonID FPERSONID, bill.FAdminOrgUnitID FADMINORGUNITID, billentry.fid FENTRYID, 1 FDIRECTION, billentry.famount FDAMOUNT, billentry.flocalamount FDAMOUNTLOCAL, billentry.famount FCAMOUNT, billentry.flocalamount FCAMOUNTLOCAL FROM t_cas_paymentbill BILL INNER JOIN t_cas_paymentbillentry BILLENTRY ON bill.fid = billentry.fpaymentbillid WHERE ((bill.fsourcetype = 101 AND bill.ffivouchered = 1) AND FIsTransBill = 0)
/

