create view V_HR_YVPERSONINFO as
SELECT T_HR_PersonPosition.FJoinGroupYears, T_HR_PersonPosition.FJoinCompanyYears, T_HR_PersonPosition.FJoinBaseYears, T_HR_PersonPosition.FFormalDate, T_HR_YVPerson.FPersonID, T_HR_PersonPosition.FEnterDate, T_HR_PersonPosition.FLeftDate, T_HR_PersonPosition.FJoinDate, T_HR_PersonPosition.FJoinGroupDate FROM T_HR_YVPerson LEFT OUTER JOIN T_HR_PersonPosition ON T_HR_YVPerson.FPersonID = T_HR_PersonPosition.FPersonID
/

