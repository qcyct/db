create view V_BD_ASSTATTRTYPE as
SELECT FID, FNumber, FName_L1, FName_L2, FName_L3, FCreatorID, FCreateTime, FLastUpdateUserID, FLastUpdateTime, FControlUnitID, FDescription_L1, FDescription_L2, FDescription_L3, FSimpleName FROM T_BD_AsstAttrBasicType UNION SELECT FID, FNumber, FName_L1, FName_L2, FName_L3, FCreatorID, FCreateTime, FLastUpdateUserID, FLastUpdateTime, FControlUnitID, FDescription_L1, FDescription_L2, FDescription_L3, FSimpleName FROM T_BD_AsstAttrCompondingType
/

