create procedure NkyOwnerContract_audit (
v_confid in varchar2 default '',
v_conname in varchar2,
v_customerid in varchar2,
v_conamount in varchar2) is
cursor cc is    select a.cfproprojectnumber from CT_KC_NkyOCPE a where a.fparentid=v_confid ;
tt cc%rowtype;

num_conamount number(28,10);
begin
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;
  
  num_conamount:=nvl(to_number(v_conamount),0);   
  --更新专业工程   
  update  ct_kc_nkyproproject b  set b.cfcontractnubmerid=v_confid , b.cfcontractname=v_conname, b.cfcontractamount=num_conamount,
             b.cfnkycustomerid=v_customerid   where b.fid=tt.cfproprojectnumber;    
  --更新施工任务通知单
  update  ct_kc_workassignment c  set c.cfcontractnubmerid=v_confid , c.cfcontractname=v_conname, c.cfcontractamount=num_conamount,
             c.cfnkycustomerid=v_customerid   where c.cfproprojectnumber=tt.cfproprojectnumber;
  --更新出图章登记
   update  ct_kc_drawingstampmanage d  set d.cfcontractnubmerid=v_confid , d.cfcontractamount=num_conamount
                   where d.cfproprojectnumber=tt.cfproprojectnumber;
  --更新工程费用决算单
  update  Ct_Kc_Projectcostaccounts e  set e.cfcontractnubmerid=v_confid , e.cfcontractamount=num_conamount,
            e.cfnkycustomerid=v_customerid   where e.cfproprojectnumber=tt.cfproprojectnumber;
  --更新提款单
  update  Ct_Kc_Nkykcpayment f  set f.cfcontractnubmerid=v_confid,f.cfcontractname=v_conname , f.cfcontractamount=num_conamount,
            f.cfnkycustomerid=v_customerid   where f.cfproprojectnumber=tt.cfproprojectnumber;
 
  end loop;
  close cc;
  
end NkyOwnerContract_audit;
/

