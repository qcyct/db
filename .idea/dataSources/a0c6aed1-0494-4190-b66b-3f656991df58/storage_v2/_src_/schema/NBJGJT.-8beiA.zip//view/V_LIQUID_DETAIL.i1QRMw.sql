create view V_LIQUID_DETAIL as
SELECT FCompanyID "FCOMPANYID", CASE  WHEN ftype = 1 THEN FAccountViewID ELSE FAccountBankID END "FACCOUNTBANKID", FCurrencyID "FCURRENCYID", FCreateDate "FBIZDATE", FDebitAmount "FDEBITAMOUNT", FCreditAmount "FCREDITAMOUNT", '1' FTYPE, ftype FCASHORBANK FROM T_CAS_Journal WHERE (ftype = 1 OR ftype = 2)
/

