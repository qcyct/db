create view V_TRANSTOCOMPANY as
select fid companyID,fnumber,FNAME_L2,transportID from T_ORG_COMPANY A 
LEFT JOIN 
(
        SELECT FToUnitID companyID,FFromUnitID transportID FROM T_ORG_UnitRelation a 
                WHERE a.FTypeRelationId = (SELECT fid FROM T_ORG_TypeRelation WHERE FFromType = 24 AND FToType = 1)  
                and a.FFromUnitID in (select fid from T_ORG_Transport)
) b on b.companyID = a.fid
/

