create procedure JGCustomer_Insert is
cursor cc is    select a.cfsuppliername,a.cfcorpcreditcode,a.cfsuppliertype,a.cfsuppliertypenumber,a.cfsuppliertypetreeid,a.cfcorpnature  from jgsupplier_temp a;

tt cc%rowtype;
v_seqnum integer;
i integer;
v_number varchar2(44);
begin
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;
    select count(*) into i from ct_sup_jgcustomer  where cfcorpcreditcode like '%'||tt.cfcorpcreditcode||'%' ;
    if i=0 then
       select  cfseqnumber+1 into v_seqnum  from CT_SPB_JGSupplierCustomerSeq   where  cfcssgrouptreeid=tt.cfsuppliertypetreeid ;
       v_number:= tt.cfsuppliertypenumber||'-'||lpad(v_seqnum,6,'0');
       update CT_SPB_JGSupplierCustomerSeq  set cfseqnumber=cfseqnumber+1   where cfcssgrouptreeid=tt.cfsuppliertypetreeid ;

       insert into ct_sup_jgcustomer (fid,FNumber,cfcustomername,Cfcorpcreditcode,
                                      cfcustomertype,cfcustomertypenumber,cfcustomertypetreeid,cfcorpnature,
                                      Fcreatorid,Fcreatetime,Fbizdate,Cfbillstate,Fcontrolunitid  )
       values (newbosid('6076D442'),v_number,tt.cfsuppliername,tt.cfcorpcreditcode,
              tt.cfsuppliertype,tt.cfsuppliertypenumber,tt.cfsuppliertypetreeid,tt.cfcorpnature,
              '256c221a-0106-1000-e000-10d7c0a813f413B7DE7F',systimestamp,sysdate,'02','00000000-0000-0000-0000-000000000000CCE7AED4');
    end if;   


  end loop;
  close cc;
end JGCustomer_Insert;
/

