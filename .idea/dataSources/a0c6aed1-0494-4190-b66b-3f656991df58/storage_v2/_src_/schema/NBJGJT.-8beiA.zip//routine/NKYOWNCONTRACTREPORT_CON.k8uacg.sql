create procedure NkyOwnContractReport_con(
v_confid in varchar2 ,
v_receivepoint out varchar2) is
cursor cc is   select c.Cfreceivepoint as receivepoint from CT_KC_NkyOwnerContractEntry c where c.fparentid=v_confid;
tt cc%rowtype;

i integer;
begin
    i:= 1;
    v_receivepoint:='';
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;

  v_receivepoint:=v_receivepoint||i||'、'||tt.receivepoint||'  ';

  i:=i+ 1;
  end loop;
  close cc;

end NkyOwnContractReport_con;
/

