create PROCEDURE GetResultSet(querysql IN VARCHAR2,
                                         p_CURSOR out GetResultSetPACKAGE.ResultSet_CURSOR) IS

BEGIN

  OPEN p_CURSOR FOR querysql;

END GetResultSet;


/

