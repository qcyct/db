create PROCEDURE XALTER_TABLE
(
tablename in VARCHAR,
methods in VARCHAR
)
IS
pre integer := 1;
now integer := 0;
strlen integer := LENGTH(methods);
tempPre integer := 0;
tempP integer := 0;
ch char;
tempMethod VARCHAR(32767);
BEGIN
WHILE now<=strlen LOOP
BEGIN
WHILE 1=1 LOOP
BEGIN
now := now+1;
ch := SUBSTR(methods,now,1);
IF ch='(' THEN
BEGIN
pre:=now;
tempPre:=tempP;
tempP:=tempP+1;
EXIT;
END;
ELSE
BEGIN
EXIT WHEN now>=strlen;
END;
END IF;
END;
END LOOP;
EXIT WHEN now>=strlen;
WHILE 1=1 LOOP
BEGIN
now:=now+1;
ch := SUBSTR(methods,now,1);
IF ch='(' THEN
BEGIN
tempP:=tempP+1;
END;
ELSIF ch=')' THEN
BEGIN
tempP:=tempP-1;
EXIT WHEN tempP=tempPre;
END;
END IF;
END;
END LOOP;
tempMethod := 'alter table '||tablename||' '||SUBSTR(methods,pre+1,now-pre-1);
EXECUTE IMMEDIATE tempMethod;
END;
END LOOP;
END XALTER_TABLE;
/

