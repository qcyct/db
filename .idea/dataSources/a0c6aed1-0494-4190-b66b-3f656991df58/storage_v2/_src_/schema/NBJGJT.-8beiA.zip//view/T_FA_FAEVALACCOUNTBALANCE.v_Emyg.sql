create view T_FA_FAEVALACCOUNTBALANCE as
(SELECT k."PREPID",k."PREPYEAR",k."PREPNUMBER",k."CURPID",k."CURPYEAR",k."CURPNUMBER",k."CARDID",k."CNUMBER",k."FREALENDBALANCEFOR",k."FDEPREENDBALANCEFOR",k."FDECVALUEENDBALANCEFOR",k."FEVALUEENDBALANCEFOR",k."FPERIODID",k."COMPANYID",
CASE
WHEN m.fevalassetvalue IS NULL
THEN bak.fevalassetvalue
ELSE m.fevalassetvalue
END frealbeginbalancefor,
CASE
WHEN m.fevaladddepr IS NULL
THEN bak.fevaladddepr
ELSE m.fevaladddepr
END fdeprebeginbalancefor,
CASE
WHEN m.fevaldecvalue IS NULL
THEN bak.fevaldecvalue
ELSE m.fevaldecvalue
END fdecvaluebeginbalancefor,
CASE
WHEN m.finitevalvalue IS NULL
THEN bak.finitevalvalue
ELSE m.finitevalvalue
END fevaluebeginbalancefor
FROM (SELECT p.fid prepid, p.fperiodyear prepyear,
p.fperiodnumber prepnumber, a.fid curpid,
a.fperiodyear curpyear, a.fperiodnumber curpnumber,
c.fid cardid, c.fnumber cnumber,
c.fevalassetvalue frealendbalancefor,
c.fevaladddepr fdepreendbalancefor,
c.fevaldecvalue fdecvalueendbalancefor,
c.finitevalvalue fevalueendbalancefor,
c.fperiodid fperiodid, a.fcompanyid companyid
FROM t_bd_period p, (SELECT period.fid fid,
period.fperiodyear fperiodyear,
period.fperiodnumber fperiodnumber,
ssc.fcompanyid fcompanyid,
period.ftypeid ftypeid
FROM t_bd_systemstatusctrol ssc INNER JOIN t_bd_systemstatus ss ON ss.fid =
ssc.fsystemstatusid
INNER JOIN t_bd_period period ON period.fid =
ssc.fcurrentperiodid
WHERE ss.fname = 14) a LEFT OUTER JOIN t_fa_facurcard c ON c.fcompanyid =
a.fcompanyid
WHERE (       p.fperiodyear = a.fperiodyear
AND p.fperiodnumber = a.fperiodnumber - 1
AND a.fperiodnumber != 1
OR     p.fperiodyear = a.fperiodyear - 1
AND p.fperiodnumber = 12
AND a.fperiodnumber = 1
)
AND p.ftypeid = a.ftypeid) k LEFT OUTER JOIN t_fa_famoncard m ON m.ffacurcardid =
k.cardid
AND (   m.ffaperiodid =
k.prepid
OR     m.ffaperiodid IS NULL
AND k.curpid =
k.fperiodid
)
LEFT OUTER JOIN t_fa_fabakcard bak ON bak.ffacurcardid = k.cardid
AND k.curpid = bak.fperiodid
AND bak.foriginflag != 0
AND bak.fbilltype = 1
UNION ALL
SELECT k."PREPID",k."PREPYEAR",k."PREPNUMBER",k."CURPID",k."CURPYEAR",k."CURPNUMBER",k."CARDID",k."CNUMBER",k."FREALENDBALANCEFOR",k."FDEPREENDBALANCEFOR",k."FDECVALUEENDBALANCEFOR",k."FEVALUEENDBALANCEFOR",k."FPERIODID",k."COMPANYID", m.fevalassetvalue frealbeginbalancefor,
m.fevaladddepr fdeprebeginbalancefor,
m.fevaldecvalue fdecvaluebeginbalancefor,
m.finitevalvalue fevaluebeginbalancefor
FROM (SELECT p.fid prepid, p.fperiodyear prepyear,
p.fperiodnumber prepnumber, a.fid curpid,
a.fperiodyear curpyear, a.fperiodnumber curpnumber,
c.ffacurcardid cardid, c.fnumber cnumber,
c.fevalassetvalue frealendbalancefor,
c.fevaladddepr fdepreendbalancefor,
c.fevaldecvalue fdecvalueendbalancefor,
c.finitevalvalue fevalueendbalancefor,
c.fperiodid fperiodid, c.fcompanyid companyid
FROM t_bd_period p, t_bd_period a, t_fa_famoncard c
WHERE c.ffaperiodid = a.fid
AND (       p.fperiodyear = a.fperiodyear
AND p.fperiodnumber = a.fperiodnumber - 1
AND a.fperiodnumber != 1
OR     p.fperiodyear = a.fperiodyear - 1
AND p.fperiodnumber = 12
AND a.fperiodnumber = 1
)
AND p.fnumber >=
(SELECT period.fnumber
FROM t_bd_systemstatusctrol ssc INNER JOIN t_bd_systemstatus ss ON ss.fid =
ssc.fsystemstatusid
INNER JOIN t_bd_period period ON period.fid =
ssc.fstartperiodid
WHERE ss.fname = 14 AND ssc.fcompanyid = c.fcompanyid)
AND p.ftypeid = a.ftypeid) k LEFT OUTER JOIN t_fa_famoncard m ON m.ffacurcardid =
k.cardid
AND (   m.ffaperiodid =
k.prepid
OR     m.ffaperiodid IS NULL
AND k.curpid =
m.fperiodid
)
UNION ALL
SELECT k."PREPID",k."PREPYEAR",k."PREPNUMBER",k."CURPID",k."CURPYEAR",k."CURPNUMBER",k."CARDID",k."CNUMBER",k."FREALENDBALANCEFOR",k."FDEPREENDBALANCEFOR",k."FDECVALUEENDBALANCEFOR",k."FEVALUEENDBALANCEFOR",k."FPERIODID",k."COMPANYID",k."FREALBEGINBALANCEFOR",k."FDEPREBEGINBALANCEFOR",k."FDECVALUEBEGINBALANCEFOR",k."FEVALUEBEGINBALANCEFOR"
FROM (SELECT '' prepid, 0 prepyear, 0 prepnumber, a.fid curpid,
a.fperiodyear curpyear, a.fperiodnumber curpnumber,
c.ffacurcardid cardid, c.fnumber cnumber,
c.fevalassetvalue frealendbalancefor,
c.fevaladddepr fdepreendbalancefor,
c.fevaldecvalue fdecvalueendbalancefor,
c.finitevalvalue fevalueendbalancefor,
c.fperiodid fperiodid, a.fcompanyid companyid,
c2.fevalassetvalue frealbeginbalancefor,
c2.fevaladddepr fdeprebeginbalancefor,
c2.fevaldecvalue fdecvaluebeginbalancefor,
c2.finitevalvalue fevaluebeginbalancefor
FROM (SELECT period.fid fid, period.fperiodyear fperiodyear,
period.fperiodnumber fperiodnumber,
ssc.fcompanyid fcompanyid, period.ftypeid ftypeid
FROM t_bd_systemstatusctrol ssc INNER JOIN t_bd_systemstatus ss ON ss.fid =
ssc.fsystemstatusid
INNER JOIN t_bd_period period ON period.fid =
ssc.fstartperiodid
WHERE ss.fname = 14) a,
t_fa_famoncard c,
t_fa_famoncard c2
WHERE c.ffaperiodid = a.fid
AND c.fcompanyid = a.fcompanyid
AND c.ffacurcardid = c2.ffacurcardid
AND c2.ffaperiodid IS NULL) k
UNION ALL
SELECT k."PREPID",k."PREPYEAR",k."PREPNUMBER",k."CURPID",k."CURPYEAR",k."CURPNUMBER",k."CARDID",k."CNUMBER",k."FREALENDBALANCEFOR",k."FDEPREENDBALANCEFOR",k."FDECVALUEENDBALANCEFOR",k."FEVALUEENDBALANCEFOR",k."FPERIODID",k."COMPANYID",k."FREALBEGINBALANCEFOR",k."FDEPREBEGINBALANCEFOR",k."FDECVALUEBEGINBALANCEFOR",k."FEVALUEBEGINBALANCEFOR"
FROM (SELECT '' prepid, 0 prepyear, 0 prepnumber, a.fid curpid,
a.fperiodyear curpyear, a.fperiodnumber curpnumber,
c.ffacurcardid cardid, c.fnumber cnumber,
c.fevalassetvalue frealendbalancefor,
c.fevaladddepr fdepreendbalancefor,
c.fevaldecvalue fdecvalueendbalancefor,
c.finitevalvalue fevalueendbalancefor,
c.fperiodid fperiodid, a.fcompanyid companyid,
c2.fevalassetvalue frealbeginbalancefor,
c2.fevaladddepr fdeprebeginbalancefor,
c2.fevaldecvalue fdecvaluebeginbalancefor,
c2.finitevalvalue fevaluebeginbalancefor
FROM (SELECT period.fid fid, period.fperiodyear fperiodyear,
period.fperiodnumber fperiodnumber,
ssc.fcompanyid fcompanyid, period.ftypeid ftypeid
FROM t_bd_systemstatusctrol ssc INNER JOIN t_bd_systemstatus ss ON ss.fid =
ssc.fsystemstatusid
INNER JOIN t_bd_period period ON period.fid =
ssc.fstartperiodid
WHERE ss.fname = 14) a,
t_fa_famoncard c,
t_fa_fabakcard c2
WHERE c.ffaperiodid = a.fid
AND c.fcompanyid = a.fcompanyid
AND c2.ffacurcardid = c.ffacurcardid
AND c2.foriginflag != 0
AND c2.fbilltype = 1) k
UNION ALL
SELECT k."PREPID",k."PREPYEAR",k."PREPNUMBER",k."CURPID",k."CURPYEAR",k."CURPNUMBER",k."CARDID",k."CNUMBER",k."FREALENDBALANCEFOR",k."FDEPREENDBALANCEFOR",k."FDECVALUEENDBALANCEFOR",k."FEVALUEENDBALANCEFOR",k."FPERIODID",k."COMPANYID",
CASE
WHEN m.fevalassetvalue IS NULL
THEN bak.fevalassetvalue
ELSE m.fevalassetvalue
END frealbeginbalancefor,
CASE
WHEN m.fevaladddepr IS NULL
THEN bak.fevaladddepr
ELSE m.fevaladddepr
END fdeprebeginbalancefor,
CASE
WHEN m.fevaldecvalue IS NULL
THEN bak.fevaldecvalue
ELSE m.fevaldecvalue
END fdecvaluebeginbalancefor,
CASE
WHEN m.finitevalvalue IS NULL
THEN bak.finitevalvalue
ELSE m.finitevalvalue
END fevaluebeginbalancefor
FROM (SELECT '' prepid, 0 prepyear, 0 prepnumber, a.fid curpid,
a.fperiodyear curpyear, a.fperiodnumber curpnumber,
c.fid cardid, c.fnumber cnumber,
c.fevalassetvalue frealendbalancefor,
c.fevaladddepr fdepreendbalancefor,
c.fevaldecvalue fdecvalueendbalancefor,
c.finitevalvalue fevalueendbalancefor, c.fperiodid fperiodid,
a.fcompanyid companyid
FROM (SELECT period.fid fid, period.fperiodyear fperiodyear,
period.fperiodnumber fperiodnumber,
ssc.fcompanyid fcompanyid, period.ftypeid ftypeid,
period.fnumber minnumber
FROM t_bd_systemstatusctrol ssc INNER JOIN t_bd_systemstatus ss ON ss.fid =
ssc.fsystemstatusid
INNER JOIN t_bd_period period ON period.fid =
ssc.fcurrentperiodid
WHERE ss.fname = 14) a LEFT OUTER JOIN t_fa_facurcard c ON c.fcompanyid =
a.fcompanyid
INNER JOIN (SELECT   MIN (fnumber) fnumber, ftypeid
FROM t_bd_period
GROUP BY ftypeid) minperiod ON minperiod.fnumber =
a.minnumber
AND minperiod.ftypeid =
a.ftypeid
) k LEFT OUTER JOIN t_fa_famoncard m ON m.ffacurcardid =
k.cardid
AND (   m.ffaperiodid =
k.prepid
OR     m.ffaperiodid IS NULL
AND k.curpid =
k.fperiodid
)
LEFT OUTER JOIN t_fa_fabakcard bak ON bak.ffacurcardid = k.cardid
AND k.curpid = bak.fperiodid
AND bak.foriginflag != 0
AND bak.fbilltype = 1
)
/

