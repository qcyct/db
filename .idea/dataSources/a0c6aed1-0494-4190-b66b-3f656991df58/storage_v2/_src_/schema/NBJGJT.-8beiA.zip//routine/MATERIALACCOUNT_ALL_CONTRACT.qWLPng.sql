create procedure MaterialAccount_All_contract(
v_projectorg in varchar2 default '' ,
v_contractID in varchar2,
v_billtypeInv in varchar2,
v_transtypeAdj in varchar2,
v_endperiod in date

) is
cursor cc is    select materialid,materialname,unit,sum(qty) qty,sum(amount) amount  from (
         select f.fmaterialid materialid,o.fname_l2 materialname,m.fname_l2 unit,f.fqty qty,f.famount amount from T_EC_MaterialInvBill d
         left outer join T_EC_MaterialInvBillEntry f on d.fid=f.fparentid
         left outer join T_EC_TransactionType a on a.fid=d.ftranstypeid
         left outer join T_EC_BillType b on b.fid=a.fbilltypeid
         left outer join T_BD_MeasureUnit m on m.fid=f.fmeasureunitid
         left outer join T_EC_ResourceItem o on o.fid=f.fmaterialid
         where d.fcontractid=v_contractID
         and d.fprojectorgid=v_projectorg
         and b.fid=v_billtypeInv
         and d.fbillsate='03'
         and d.fbizdate<v_endperiod
         union all
         select h.cfmaterialid materialid,o.fname_l2 materialname,h.cfunit unit,h.cfqty qty,h.cfamount amount from CT_INV_InvAdjust g
         left outer join CT_INV_InvAdjustEntry h on g.fid= h.fparentid
         left outer join T_EC_ResourceItem o on o.fid=h.cfmaterialid
         where g.cfcontractid=v_contractID
         and g.cfprojectorgid=v_projectorg
         and g.cftranstypeid=v_transtypeAdj
         and g.cfbillsate='03'
         and g.fbizdate<v_endperiod
         ) group by  materialid,materialname,unit
         order by materialname
;
tt cc%rowtype;
tot_matBalQty number(28,10);--累计对账数量
tot_matBalAmount number(28,10);--累计对账金额
tot_matBalCheckQty number(28,10);--累计对账审核数量
tot_matBalCheckAmount  number(28,10);--累计对账审核
i integer;

begin
  open cc;
  loop
  fetch cc into tt;
  exit when cc% notfound;

  tot_matBalQty:= 0;--累计对账数量
  tot_matBalAmount:= 0;--累计对账金额
  tot_matBalCheckQty:= 0;--累计对账审核数量
  tot_matBalCheckAmount:= 0;--累计对账审核

  --累计对账
  select count(*) into i
  from  ct_set_mtbalancebill mtb,ct_set_mtbalancebillentry mtbe
      where mtb.fid=mtbe.fparentid
       and mtb.cfbillsate in ('03','11')
       and mtb.cfprojectorgid= v_projectorg
       and mtb.cfcontractid=v_contractID
       and mtbe.cfmaterialid=tt.materialid
       and mtb.fbizdate<v_endperiod ;
  if i>0 then
    select sum(mtbe.cfqty),sum(mtbe.cfamount)  into tot_matBalQty,tot_matBalAmount
      from  ct_set_mtbalancebill mtb,ct_set_mtbalancebillentry mtbe
      where mtb.fid=mtbe.fparentid
       and mtb.cfbillsate in ('03','11')
       and mtb.cfprojectorgid= v_projectorg
       and mtb.cfcontractid=v_contractID
       and mtbe.cfmaterialid=tt.materialid
       and mtb.fbizdate<v_endperiod
       group by  mtbe.cfmaterialid;
  end if;

  --累计对账审核
  select count(*) into i
  from CT_SET_MaterialAccountBill ba,Ct_Set_Materialabie baie
           where ba.fid=baie.fparentid
           and ba.cfprojectorgid=v_projectorg
           and ba.cfcontractid=v_contractID
           and baie.cfmaterialid =tt.Materialid
           and ba.cfbillstate in ('03','04','05','10')
           and ba.fbizdate<v_endperiod ;
  if i>0 then
   select sum(baie.cfqty),sum(baie.cfamount)  into   tot_matBalCheckQty,tot_matBalCheckAmount
  from CT_SET_MaterialAccountBill ba,Ct_Set_Materialabie baie
           where ba.fid=baie.fparentid
           and ba.cfprojectorgid=v_projectorg
           and ba.cfcontractid=v_contractID
           and baie.cfmaterialid =tt.Materialid
           and ba.cfbillstate in ('03','04','05','10')
           and ba.fbizdate<v_endperiod
           group by  baie.cfmaterialid;
  end if;

  tot_matBalQty:= nvl(tot_matBalQty,0);--累计对账数量
  tot_matBalAmount:= nvl(tot_matBalAmount,0);--累计对账金额
  tot_matBalCheckQty:= nvl(tot_matBalCheckQty,0);--累计对账数量
  tot_matBalCheckAmount:= nvl(tot_matBalCheckAmount,0);--累计对账金额

  insert into MaterialAccount_all_temp(materialid ,Materialname,Unit,Mtqty,Mtamount,Balqty,Balamount,Accqty,Accamount)
  values (tt.materialid,tt.materialname,tt.unit,tt.qty,tt.amount,tot_matBalQty,tot_matBalAmount,tot_matBalCheckQty,tot_matBalCheckAmount);

  end loop;
  close cc;
end MaterialAccount_All_contract;
/

