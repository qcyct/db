create view v_spl_multiapprove as
select `a`.`id` AS `id`, `b`.`depart_name` AS `departname`
from (`jeecgboot2`.`spl_multiapprove` `a`
         left join `jeecgboot2`.`sys_depart` `b` on ((convert(`b`.`id` using utf8mb4) = `a`.`admin`)))
where (`a`.`level` = 1);

-- comment on column v_spl_multiapprove.departname not supported: 机构/部门名称

