create definer = root@`%` view v_panda as
select `t1`.`id` AS `id`, `t1`.`name` AS `name`, `t1`.`number` AS `number`
from `jeecgboot`.`bd_project_register` `t1`
where ((`t1`.`bills_state` = '3') and (`t1`.`is_referenced` = '0'));

-- comment on column v_panda.id not supported: 主键

-- comment on column v_panda.name not supported: 项目名称

-- comment on column v_panda.number not supported: 单据编号

