create definer = root@`%` view v_contracttotalamount as
select `a`.`id` AS `id`,
       100      AS `accumulativeTotalPrice`,
       80       AS `accumulativeMakePrice`,
       60       AS `accumulativeApplyPrice`,
       45       AS `accumulativePaymentPrice`,
       15       AS `accumulativeUnpaidPrice`
from `jeecgboot`.`ims_contract` `a`;

-- comment on column v_contracttotalamount.id not supported: 主键

