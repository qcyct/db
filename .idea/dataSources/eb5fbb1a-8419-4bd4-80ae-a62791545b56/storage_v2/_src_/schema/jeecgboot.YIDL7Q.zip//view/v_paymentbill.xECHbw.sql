create definer = root@`%` view v_paymentbill as
select `a`.`id`                                                   AS `id`,
       `a`.`documents_state`                                      AS `bizStatus`,
       `a`.`name`                                                 AS `billName`,
       `a`.`number`                                               AS `number`,
       date_format(`a`.`create_time`, '%Y-%m-%d')                 AS `bizDate`,
       `b`.`easnumber`                                            AS `company`,
       `d`.`projectorgid`                                         AS `projectOrgId`,
       `d`.`id`                                                   AS `projectId`,
       `a`.`contract_item_expenditure`                            AS `feeType`,
       '999'                                                      AS `payBillType`,
       'BB01'                                                     AS `currency`,
       1                                                          AS `exchangeRate`,
       ''                                                         AS `payerAccountBank`,
       ''                                                         AS `bizType`,
       '31'                                                       AS `settlementType`,
       `a`.`payment_digest`                                       AS `remark`,
       ''                                                         AS `payeeType`,
       ''                                                         AS `payeeNumber`,
       `a`.`dealings_name`                                        AS `payeeName`,
       `a`.`dealings_account`                                     AS `payeeAccountBank`,
       `a`.`proceeds_bank`                                        AS `payeeBank`,
       `a`.`proceeds_bank_account`                                AS `bankNumber`,
       0                                                          AS `paytype`,
       '货币资金业务支出'                                                 AS `payrem`,
       'C01'                                                      AS `country`,
       ''                                                         AS `recProvince`,
       ''                                                         AS `recCity`,
       1                                                          AS `isEmergency`,
       `a`.`purpose`                                              AS `usage`,
       `a`.`current_applied_amount`                               AS `amount`,
       (`a`.`current_applied_amount` - `a`.`current_real_amount`) AS `currAmount`
from (((`jeecgboot`.`cm_payment_request` `a` left join `jeecgboot`.`sys_depart` `b` on ((`a`.`company` = convert(`b`.`id` using utf8mb4)))) left join `jeecgboot`.`bd_project` `c` on ((`a`.`project_id` = `c`.`id`)))
         left join `jeecgboot`.`eas_ec_project` `d` on ((`c`.`id` = `d`.`project_id`)));

-- comment on column v_paymentbill.id not supported: 主键

-- comment on column v_paymentbill.bizStatus not supported: 单据状态

-- comment on column v_paymentbill.billName not supported: 单据名称

-- comment on column v_paymentbill.number not supported: 单据编号

-- comment on column v_paymentbill.company not supported: EAS编号

-- comment on column v_paymentbill.projectOrgId not supported: 工程项目组织ID

-- comment on column v_paymentbill.feeType not supported: 合同收支项

-- comment on column v_paymentbill.remark not supported: 付款摘要

-- comment on column v_paymentbill.payeeName not supported: 往来户名称

-- comment on column v_paymentbill.payeeAccountBank not supported: 收款账号

-- comment on column v_paymentbill.payeeBank not supported: 收款银行

-- comment on column v_paymentbill.bankNumber not supported: 收款银行行号

-- comment on column v_paymentbill.`usage` not supported: 用途

-- comment on column v_paymentbill.amount not supported: 本次申请金额

