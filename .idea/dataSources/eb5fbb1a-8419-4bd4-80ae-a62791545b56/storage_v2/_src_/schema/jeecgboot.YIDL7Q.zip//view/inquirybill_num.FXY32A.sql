create definer = root@`%` view inquirybill_num as
select `o`.`depart_name` AS `V_name`, count(0) AS `V_num`
from (`jeecgboot`.`bd_inquirybill` `c`
         join `jeecgboot`.`sys_depart` `o`)
where (`c`.`sys_org_code` = convert(`o`.`org_code` using utf8mb4))
group by `o`.`depart_name`;

-- comment on column inquirybill_num.V_name not supported: 机构/部门名称

