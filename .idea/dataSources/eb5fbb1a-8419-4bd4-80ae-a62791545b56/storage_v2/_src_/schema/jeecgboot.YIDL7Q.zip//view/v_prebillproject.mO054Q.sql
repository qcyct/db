create definer = root@`%` view v_prebillproject as
select `a`.`id`                                   AS `id`,
       `a`.`documents_state`                      AS `bizStatus`,
       `a`.`number`                               AS `number`,
       date_format(`a`.`create_time`, '%Y-%m-%d') AS `bizDate`,
       `b`.`easnumber`                            AS `company`,
       `d`.`projectorgid`                         AS `projectOrgId`,
       `d`.`id`                                   AS `projectId`,
       `a`.`contract_num`                         AS `contractNumber`,
       `a`.`name_a`                               AS `name`,
       '01'                                       AS `invoiceType`,
       '01'                                       AS `projcopType`,
       `g`.`number`                               AS `pDutyCode`,
       `e`.`sales_taxpayer_num`                   AS `sDutyCode`,
       `e`.`remark_project_name`                  AS `remark1`,
       `e`.`remark_project_address`               AS `remark2`,
       `f`.`goods_name`                           AS `goodsName`,
       `h`.`easid`                                AS `goodsNameId`,
       `f`.`number`                               AS `qty`,
       `f`.`unit_price`                           AS `price`,
       `f`.`money`                                AS `amount`,
       `f`.`tax_rate`                             AS `raxRate`,
       `f`.`total_money`                          AS `taxInAmount`,
       (`f`.`total_money` - `f`.`money`)          AS `tax`
from (((((((`jeecgboot`.`pm_invoice_apply` `a` left join `jeecgboot`.`sys_depart` `b` on ((`a`.`company` = convert(`b`.`id` using utf8mb4)))) left join `jeecgboot`.`bd_project` `c` on ((`a`.`project_id` = `c`.`id`))) left join `jeecgboot`.`eas_ec_project` `d` on ((`c`.`id` = `d`.`project_id`))) left join `jeecgboot`.`pm_invoice_apply_detail` `e` on ((`e`.`head_id` = `a`.`id`))) left join `jeecgboot`.`pm_purchase_sheet` `f` on ((`f`.`head_id` = `a`.`id`))) left join `jeecgboot`.`bd_customer` `g` on ((`g`.`id` = `e`.`purchase_id`)))
         left join `jeecgboot`.`bd_goods_name` `h` on ((`h`.`id` = `f`.`goods_id`)));

-- comment on column v_prebillproject.id not supported: 主键

-- comment on column v_prebillproject.bizStatus not supported: 单据状态

-- comment on column v_prebillproject.number not supported: 单据编号

-- comment on column v_prebillproject.company not supported: EAS编号

-- comment on column v_prebillproject.projectOrgId not supported: 工程项目组织ID

-- comment on column v_prebillproject.contractNumber not supported: 合同编号

-- comment on column v_prebillproject.name not supported: 购方名称

-- comment on column v_prebillproject.pDutyCode not supported: 编号

-- comment on column v_prebillproject.sDutyCode not supported: 销方纳税人识别号

-- comment on column v_prebillproject.remark1 not supported: 备注（项目名称）

-- comment on column v_prebillproject.remark2 not supported: 备注（项目所在地）

-- comment on column v_prebillproject.goodsName not supported: 货物或应税劳务名称

-- comment on column v_prebillproject.goodsNameId not supported: EASID

-- comment on column v_prebillproject.qty not supported: 数量

-- comment on column v_prebillproject.price not supported: 单价（不含税）

-- comment on column v_prebillproject.amount not supported: 金额（不含税）

-- comment on column v_prebillproject.raxRate not supported: 税率

-- comment on column v_prebillproject.taxInAmount not supported: 含税总金额

