create definer = root@`%` view v_notextcontract as
select `a`.`id`                                         AS `id`,
       `a`.`documents_state`                            AS `bizStatus`,
       `a`.`name`                                       AS `name`,
       `a`.`number`                                     AS `number`,
       date_format(`a`.`registration_time`, '%Y-%m-%d') AS `bizDate`,
       `b`.`easnumber`                                  AS `company`,
       `d`.`projectorgid`                               AS `projectOrgId`,
       `d`.`id`                                         AS `projectId`,
       '00-02-000024'                                   AS `supplier`,
       `a`.`supplier_name`                              AS `supplierName`,
       `a`.`remarks_column`                             AS `reamarks`,
       `a`.`contract_total_price`                       AS `amount`,
       `e`.`number`                                     AS `taxRateType`,
       `e`.`value`                                      AS `taxRate`,
       `a`.`expense_type`                               AS `expenseType`,
       `h`.`name`                                       AS `materialName`,
       '98010000001'                                    AS `material`,
       `i`.`expense`                                    AS `expense`,
       '1000.01.01.01.01'                               AS `costAccount`,
       '1000.01.01'                                     AS `costStructure`
from ((((((((`jeecgboot`.`contract_registration_without_text` `a` left join `jeecgboot`.`sys_depart` `b` on ((`a`.`company` = convert(`b`.`id` using utf8mb4)))) left join `jeecgboot`.`bd_project` `c` on ((`a`.`project_id` = `c`.`id`))) left join `jeecgboot`.`eas_ec_project` `d` on ((`c`.`id` = `d`.`project_id`))) left join `jeecgboot`.`bd_taxation` `e` on ((`e`.`id` = `a`.`tax_rate_id`))) left join `jeecgboot`.`bd_supplier` `f` on ((`f`.`id` = `a`.`supplier`))) left join (select `jeecgboot`.`cm_material`.`heard_id`         AS `heard_id`,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    max(`jeecgboot`.`cm_material`.`material_id`) AS `material_id`
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             from `jeecgboot`.`cm_material`
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             group by `jeecgboot`.`cm_material`.`heard_id`) `g` on ((`g`.`heard_id` = `a`.`id`))) left join `jeecgboot`.`bd_material` `h` on ((`h`.`id` = `g`.`material_id`)))
         left join (select `jeecgboot`.`cm_without_text_list`.`heard_id`     AS `heard_id`,
                           max(`jeecgboot`.`cm_without_text_list`.`expense`) AS `expense`
                    from `jeecgboot`.`cm_without_text_list`
                    group by `jeecgboot`.`cm_without_text_list`.`heard_id`) `i` on ((`i`.`heard_id` = `a`.`id`)));

