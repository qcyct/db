create definer = root@`%` view v_agentpaybill as
select `a`.`id`                                       AS `id`,
       `a`.`documents_state`                          AS `bizStatus`,
       `a`.`number`                                   AS `number`,
       date_format(`a`.`settlement_time`, '%Y-%m-%d') AS `bizDate`,
       `b`.`easnumber`                                AS `company`,
       '09'                                           AS `feeType`,
       ''                                             AS `payBankAccount`,
       `d`.`projectorgid`                             AS `projectOrgId`,
       `d`.`id`                                       AS `projectId`,
       '31'                                           AS `settlementType`,
       `a`.`expense_explain`                          AS `remark`,
       `e`.`realname`                                 AS `person`,
       `a`.`due_bank`                                 AS `recBankName`,
       `a`.`due_bank_account`                         AS `recBankAccount`,
       `a`.`expense_amount`                           AS `amount`
from ((((`jeecgboot`.`cm_expense_account` `a` left join `jeecgboot`.`sys_depart` `b` on ((`a`.`company` = convert(`b`.`id` using utf8mb4)))) left join `jeecgboot`.`bd_project` `c` on ((`a`.`project_id` = `c`.`id`))) left join `jeecgboot`.`eas_ec_project` `d` on ((`c`.`id` = `d`.`project_id`)))
         left join `jeecgboot`.`sys_user` `e` on ((convert(`e`.`realname` using utf8mb4) = `a`.`expense_person`)));

-- comment on column v_agentpaybill.id not supported: 主键

-- comment on column v_agentpaybill.bizStatus not supported: 单据状态

-- comment on column v_agentpaybill.number not supported: 单据编号

-- comment on column v_agentpaybill.company not supported: EAS编号

-- comment on column v_agentpaybill.projectOrgId not supported: 工程项目组织ID

-- comment on column v_agentpaybill.remark not supported: 报销说明

-- comment on column v_agentpaybill.person not supported: 真实姓名

-- comment on column v_agentpaybill.recBankName not supported: 收款银行

-- comment on column v_agentpaybill.recBankAccount not supported: 收款银行账号

-- comment on column v_agentpaybill.amount not supported: 报销总金额

